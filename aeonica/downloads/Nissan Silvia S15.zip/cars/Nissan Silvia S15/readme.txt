Car information
================================================================
Car name                : Nissan Silvia S15
Car Type  		: Repaint (with original params)
Top speed 		: ~28.6 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Nissan Silvia S15
Description             : Nissan Silvia S15 drift car with a gun metal paint job and decals from Modern Image. This car has been lowered and features custom body kit, a carbon-fiber hood from Siebon, custom rear wing and a set of XXR 941 rims.

Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org
			  rv-sizer, rvshade, rv-dblsd, 
                          zmodeler1, TMVfR
 
Additional Credits 
================================================================
Thanks to Adamodell and Ryuji Kainoh for making this car available.
 
Copyright / Permissions
================================================================
Authors may _NOT_ use this Car as a base to build additional cars.  

You MAY distribute this car, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.