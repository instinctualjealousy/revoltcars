Car information
================================================================
Car name                : Toyota Supra
Car Type  		: Repaint (with original params)
Top speed 		: ~29.2 mph
Rating/Class   		: Advanced
Install folder       	: ...\cars\Toyota Supra
Description             : A heavily modified Toyota Supra featuring a full body kit, including new intercoolers and a more aerodynamic front. The custom green paint job gives this car a stunning, intimidating look, along with a custom interior and 5zigen Hyper 5zr silver rims.

Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org, rv-sizer, rv-dblsd
 
Additional Credits 
================================================================
Thanks to BurnRubr and Ryuji KAINOH for making this car available.
 
Copyright / Permissions
================================================================
Authors may NOT use this Car as a base to build additional cars.  

You MAY distribute this CAR, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.