Car information
================================================================
Car name                : Mitsubishi Lancer Evolution RWD
Car Type  		: Repaint (with original params)
Top speed 		: ~31 mph
Rating/Class   		: Advanced
Install folder       	: ...\cars\Lancer Evo RWD
Description             : Disconnecting the front wheels from the
drivetrain has turned this Lancer Evolution into a real-wheel-drive
monstrosity - but at the same time makes it insanely maneuverable,
if you can handle it. Beyond this incredible newfound drifting
performance, this Lancer also sports a custom paint job, new rims,
and new tail lights.

Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org, rv-sizer, rv-dblsd
 
Additional Credits 
================================================================
Thanks to The Me and Me and Ryuji Kainoh for making this car available.
 
Copyright / Permissions
================================================================
Authors may NOT use this Car as a base to build additional cars.  
(One of the following)

You MAY distribute this CAR, provided you include this file, with no 
modifications.  You may distribute this file in any electronic format 
(BBS, Diskette, CD, etc) as long as you include this file intact.