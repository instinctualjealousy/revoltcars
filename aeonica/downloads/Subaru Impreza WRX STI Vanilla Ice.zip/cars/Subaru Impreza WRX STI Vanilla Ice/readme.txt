Car information
================================================================
Car name                : Subaru Impreza WRX STI, "Vanilla Ice"
Car Type  		: Repaint (with original params)
Top speed 		: ~29.7 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Subaru Impreza WRX STI Vanilla Ice
Description             : This Subaru WRX STI, known as "Vanilla Ice", hosts a frosty blue and silver color scheme, inside and out, while featuring some silver Enkei Rsv Rims.
 
Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org, rv-sizer, rv-dblsd
 
Additional Credits 
================================================================
Thanks to RevKev and Justin Townson (wrx_freak) for making this car available.
 
Copyright / Permissions
================================================================
Authors may NOT use this Car as a base to build additional cars.  
(One of the following)

You MAY distribute this CAR, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.