Car information
================================================================
Car name                : Acura Integra Type-R, "Kiwi"
Car Type  		: Repaint (with original params)
Top speed 		: ~29.1 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Acura Integra Type-R Kiwi
Description             :An Acura Integra Type-R with an extra-wide body kit providing enough room for it to mount a set of 225/40 18" custom-made rims, along with a custom high-downforce spoiler for maximum control. In addition to its stunning blue and green paint job and Modern Image decals, this Integra also has a carbon-fiber hood and 405 bhp of asphalt shreading muscle. The interior has been redone in blue, with blue steering wheel and neon blue dash lights.

Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org, rv-sizer, 
                          rvshade, ZModeler1
 
Additional Credits 
================================================================
Thanks to whoever it was that made this! (No original readme.txt was included.)
 
Copyright / Permissions
================================================================
Authors may NOT use this Car as a base to build additional cars.  

You MAY distribute this CAR, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.