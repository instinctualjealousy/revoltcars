Car information
================================================================
Car name                : Ford Puma Racing Edition
Car Type  		: Repaint (new params and modified PRMs)
Top speed 		: ~25.3 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Ford Puma Racing
Description             : An extensive remodel of the Ford Puma, this version includes a powerful Duratec engine, further enhanced by upgrades by Milltek Sport and Ford Racing Puma for a total power output of 253 bhp at the front wheels. A new body kit creates the flare for this wildcat, along with a Seibon carbon fiber hood, custom spoiler, and a set of Sportmax rims and decals by Modern Image. The overall weight has been increased by over 550 lbs, but this car still throw you back in your seat when its time to move.

Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org
			  rv-sizer, rvshade, rv-dblsd, 
                          zmodeler1, TMVfR
 
Additional Credits 
================================================================
Thanks to Adamodell and Ryuji Kainoh for making this car available.
 
COPYRIGHT & PERMISSIONS
================================================================
Authors may _NOT_ use this Car as a base to build additional cars.  

You MAY distribute this car, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.