Car information
================================================================
Car name                : Toyota Supra, "Mark 4"
Car Type  		: Repaint (with original params)
Top speed 		: ~30.0 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Toyota Supra Mark4
Description             : This heavily modified Toyota Supra features a full custom body kit, including new inter-coolers and a more aerodynamic front. This low rider sports 225/40/17 and 275/40/17 XXR hyper 925 rims and silver paint job while the rear spoiler has been removed and downforce is achieved through the sophisticated body kit. The low profile appearance hides a stunning 444 BHP twin turbo engine as well as a rockin' sound system.

Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org, 
			  zmodeler1, rv-sizer, rv-dblsd
 
Additional Credits 
================================================================
Thanks to BurnRubr and Ryuji KAINOH for making this car available.
Thanks to Damien Hornick for inspiration based on the real-life Supra.
 
Copyright / Permissions
================================================================
Authors may NOT use this Car as a base to build additional cars.  

You MAY distribute this CAR, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.