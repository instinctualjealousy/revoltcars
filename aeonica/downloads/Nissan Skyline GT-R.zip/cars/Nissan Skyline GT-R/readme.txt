Car information
================================================================
Car name                : Nissan Skyline GT-R
Car Type  		: Repaint (with original params)
Top speed 		: ~29.4 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Nissan Skyline GT-R
Description             : A decked out Nissan Skyline with a new, more aerodynamic front body kit. New intakes on the sides and hood also provide more cooling and power to the engine. The striped bronze paint job features numerous Japanese racing insignias and other decals, while dark colors fill the interior and the wheels house a set of bronze 5zigen rims.

Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org, rv-sizer, rv-dblsd
 
Additional Credits 
================================================================
Thanks to The Me and Me and Ryuji Kainoh for making this car available.
 
Copyright / Permissions
================================================================
Authors may NOT use this Car as a base to build additional cars.  

You MAY distribute this CAR, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.