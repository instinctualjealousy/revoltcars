Car information
================================================================
Car name                : Subaru Impreza WRX STI, "Shadow"
Car Type  		: Repaint (new params and modified PRMs)
Top speed 		: 31.5 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Subaru Impreza WRX STI Shadow
Description             : A heavily modified WRX STI with a bolt-on turbo kit that awards it with 440 bhp of accessable power. The stock suspension has been replaced by a set of Tein Coilovers, and the standard wheels swapped out for a set of huge 265/35/18s with Enkei Nt03 M (gold) rims. Wheels this size are only made possible (and visually appealing) by the custom wide body kit installed on this Impreza. The "look" is completed by a black paint job and phantom flame decals from Modern Image and a custom spoiler. The interior has also been enhanced with leather seat covers and a Momo steering wheel.
 
Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org
			  rv-sizer, rvshade, rv-dblsd, 
                          zmodeler1, TMVfR
 
Additional Credits 
================================================================
Thanks to RevKev and Justin Townson (wrx_freak) for making this car available. Thanks to Daniel Ivancic for the cool car concept!
 
COPYRIGHT & PERMISSIONS
================================================================
Authors may _NOT_ use this Car as a base to build additional cars, at least not without permission..  

You MAY distribute this car, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.