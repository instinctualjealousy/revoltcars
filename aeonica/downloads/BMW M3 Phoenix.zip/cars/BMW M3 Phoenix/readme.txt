Car information
================================================================
Car name                : BMW M3, "Phoenix"
Car Type  		: Repaint (with original params)
Top speed 		: ~29.4 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\BMW M3 Phoenix
Description             : This BMW M3 has acquired a blazing orange paint job and some phoenix bird of prey and flame decals. The interior has been intricately reworked with red and black details and a custom steering wheel. This burning Beamer also boasts a huge rear wing for massive downforce and flashy Rs4 rims from Ace.
 
Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org, rv-sizer, 
                          rv-dblsd, zmodeler1, rvshade, rvcenter
 
Additional Credits 
================================================================
Thanks to Ryuji Kainoh for making this car available to Re-Volt.
 
Copyright / Permissions
================================================================
Authors may NOT use this Car as a base to build additional cars.  

You MAY distribute this CAR, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.