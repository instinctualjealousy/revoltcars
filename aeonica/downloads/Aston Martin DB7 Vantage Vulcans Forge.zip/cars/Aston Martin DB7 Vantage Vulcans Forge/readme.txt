CAR INFORMATION
================================================================
Car name                : Aston Martin DB7 Vantage, "Vulcan's Forge"
Car Type  		: Repaint (with original params)
Top speed 		: 32.4 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Aston Martin DB7 Vantage Vulcans Forge
Description             : This extreme Aston Martin DB7 Vantage has taken on some gothic overtones, with a full black paint job and silver filigree decals across the sides. The front grill has been modified and the headlights have been opened up, while the back end features a spoiler straight from a McLaren F1. The springs and dampers have been tightened and the ride height has been lowered, while the contrasting deep red and black interior completes the look. This Aston Martin is powered by a 450 BHP naturally aspired engine.

AUTHOR INFORMATION
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
CONSTRUCTION
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org
			  rv-sizer, rvshade, rv-dblsd, 
                          zmodeler1, TMVfR
 
ADDITIONAL CREDITS
================================================================
Thanks to The Me and Me and Ryuji Kainoh for making this car available.
 
COPYRIGHT & PERMISSIONS
================================================================
Authors may _NOT_ use this Car as a base to build additional cars.  

You MAY distribute this car, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.