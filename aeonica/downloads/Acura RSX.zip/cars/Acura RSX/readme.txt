CAR INFORMATION
================================================================
Car name                : Acura RSX
Car Type  		: Repaint (with original params)
Top speed 		: ~30.0 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Acura RSX
Description             : An Acura RSX which includes realistic parameters based on the specifications of the real life Acura RSX. The model has been adjusted to match the car's dimensions in real life as well. This version includes a custom paint job (decals by Modern Image and DecalSore), a slightly modified rear bumper, Enkei Rs7 anthracite rims and a custom spoiler.

AUTHOR INFORMATION
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
CONSTRUCTION
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org
			  rv-sizer, rvshade, rv-dblsd, 
                          zmodeler1, TMVfR
 
ADDITIONAL CREDITS
================================================================
Thanks to Adamodell and SYC for making this car available.
 
COPYRIGHT & PERMISSIONS
================================================================
Authors may _NOT_ use this Car as a base to build additional cars.  

You MAY distribute this car, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.