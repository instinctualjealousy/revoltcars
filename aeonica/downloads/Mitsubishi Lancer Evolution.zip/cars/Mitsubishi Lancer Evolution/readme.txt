Car information
================================================================
Car name                : Mitsubishi Lancer Evolution
Car Type  		: Repaint (with original params)
Top speed 		: ~27.0 mph
Rating/Class   		: Rookie
Install folder       	: ...\cars\Mitsubishi Lancer Evolution
Description             : The famous Lancer Evolution with a custom purple paint job and yellow filigree decals on the hood and translucent dragons on the sides. Some body work has been done and the car has a new front grill and tail lights, as well as some cool blue neons below. The interior has been decked out in black and gray and the wheels are displaying some silver Concept 5 rims from Ace.

Author Information
================================================================
Author Name 		: Aeon
Email Address           : archakelon@gmail.com
 
Construction
================================================================
Poly Count     		: (See original.txt)
Editor(s) used 		: Paint Shop Pro 7, OpenOffice.org,
			  rv-sizer, rv-dblsd
 
Additional Credits 
================================================================
Thanks to The Me and Me and Ryuji Kainoh for making this car available.
 
Copyright / Permissions
================================================================
Authors may NOT use this Car as a base to build additional cars.  

You MAY distribute this CAR, provided you include this file, with no modifications.  You may distribute this file in any electronic format (BBS, Diskette, CD, etc) as long as you include this file intact.