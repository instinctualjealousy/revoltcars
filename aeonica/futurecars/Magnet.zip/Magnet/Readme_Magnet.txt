This track is "Magnet". It is something I built to try out, and ran with it.

Unzip into your main Re-Volt directory to install.

The track ended up a lot longer than I intended, but I still like it.
There isnt much to look at, there isnt any sort of theme to follow, its just me getting wierd in 3dsmax.

Framerates are good, mostly because there arent many polygons being rendered at one time. There is no skymap, this is on purpose.

There are 2 Farce Feilds, both Linear types used in the lift. Youll know it when you get there.

Visiboxs were used for custom direction indicators. I only used directions indicators when it was truly needed. You really cant get lost on this track, its mostly like driving in a hallway, with curves.

----

Performance of the slower cars is pretty good, they are able to follow the AI with little trouble. Faster cars will have more trouble, but still give some challenge. Run this one in Carnage mode for fun. Framerates are good, which makes it a lot easier.
As far as I know, there arent any places left for the cars to get stuck. I did have to fix some places more than once. But 20 carnage races in a row, all 30 cars finished in pretty close times.

----

There is one place, there are large spiders on the track. Remember, I didnt follow any sort of theme so they are there just because. Ok?

----

MESH NOTES:

This mesh is very basic, just square tunnels. Some ceiling and walls are see thru, done with textures only. There is no neat meshwork involved.
As I said before, there is little eye-candy, as it was just a distraction and caused the framerate to fall. I average over 100 fps just about everywhere, except the starting line with all the cars. 

The track is quite long, average Toyeca run is over 5 minutes for 3 laps.

The lift has a secret, enter it at just the right speed and you will find you get thru it faster, and maybe even find the star. (one of 3)

----

Hopefully you wont find any more bugs. I squashed quite a few. You will notice in places during a replay, the view is bad. Hopefully this isnt a real issue as I cant make it better.

Well have fun with it.

RiffRaff
4-3-01

