================================================================
VULTURE
Created by Aeon (archakelon@gmail.com)
Class 4 (Pro)
Place in: /cars/Vulture
================================================================
Custom mesh created by Aeon.
Wheels modified from RiffRaff's SHIVAN car.
Textures customized with parts from FreeSpace II.

983 polygons, including wheels.
================================================================
Thanks for RiffRaff for his other POD conversions and the
wheels that he converted and which I am borrowing and modifying.
================================================================
You may use this car however you like and distribute it anywhere,
but please give credit where its due.