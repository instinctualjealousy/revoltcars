***************ZONIC***************

Car Name : Zonic
Top speed: 65mph
Class    : Pro
Type     : Originial

***********************************

Author : Volt General
Email  : voltrevolt@hotmail.com

***********************************
Description:
------------

The red arrow. Zonic. The lowest car you 
ever drove for Re-Volt. And that makes 
Zonic afraid of rough terrains. But on 
roads it flies. The thing has some rough 
spikes on it, cool isn't it?? It also is
my second RED car, other is the RTI Coupe.

**********************************
Tools used:
-----------

Painter Classic, Notepad, and lots of
fun.. :)

**********************************
Copyright:
----------

Authors MAY use this car as base to build
additional cars, BUT you have to give 
CREDIT to me, in your Readme.txt included
with the car or so. When you want to convert 
it, you must have my permission. Ask me via
email (voltrevolt@hotmail.com).

**********************************

Have fun w/this rough on-roader...