I think this gets pretty close to the real thing. Hope you guys like it and thanks a million to LB for helping
me out with my first car(s). Scorp is soon to follow.

The tools used to make this car are

1) 3dsmax R2.0 - Model is from the original lineup of Pod. Downloaded it at the UbiSoft site.

2) Adobe Photoshop 5 - To make the skin.

3) RHQ Car Manager - To make this compilation a little easier.

4) Help my LB (RiffRaff) - lot's of it ;-)

And yet another Pod car is re-created for Re-Volt


-Vortex
