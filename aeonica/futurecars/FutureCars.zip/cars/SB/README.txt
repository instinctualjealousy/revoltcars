On special request by Norrit from the X-Podder's Re-Volt Site, I've converted "Saber" from
the original Pod lineup.

The tools used to make this car are

1) 3dsmax R2.0 - Used to make the body.

2) Adobe Photoshop 5 - To make the skin.

3) RHQ Car Manager - To make this compilation a little easier.

Hope you guys like this one ;-)


-Vortex
