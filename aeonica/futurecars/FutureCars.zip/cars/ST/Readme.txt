Stinger is a car from the game Pod. This car is one of the more successful cars in Pod. It is actually my favorite Pod car. This particular model was designed by Desiato, and the car is skinned using his original texture. The car in Pod is skinned totally different, and I think Desi was dissappointed so this one is close to his original. This cars mesh was modified to make the wheels fit the car. Imagine this car with no tires, and the two outer points curving in tighter to the main body, then you have the original.

Unzip to cars\Stinger



The tools used to make this car are

1) 3dsmax R2.5 - To make the car body. Used the Stinger.3ds mesh provided by Desiato. 
                 The wheels are made custom. 

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.

4) Caffiene- Lots of it.

Thank you Desiato for the mesh. The legend lives on.


Have fun!  

RiffRaff
