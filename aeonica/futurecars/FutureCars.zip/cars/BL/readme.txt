================================================================
BLADE
Created by Aeon (archakelon@gmail.com)
Class 4 (Pro)
Place in: /cars/Blade
================================================================
Mesh heavily modified from RiffRaff's SHARK car.
Wheels borrowed from RiffRaff's SHIVAN car.
Axle borrowed from RiffRaff's SHIVAN car.
Texture created by Aeon, based on Quake textures off the web.

2038 polygons, including wheels.
================================================================
THANKS to RiffRaff for creating the base models, as well as
all of his other cool POD-style cars.
================================================================
You may use this car however you like and distribute it anywhere,
but please give credit where its due.