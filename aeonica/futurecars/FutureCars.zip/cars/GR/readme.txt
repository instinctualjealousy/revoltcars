================================================================
GREMLIN
Created by Aeon (archakelon@gmail.com)
Class 4 (Pro)
Place in: /cars/Gremlin
================================================================
Mesh heavily modified from RiffRaff's ALIEN car.
Wheels borrowed from RiffRaff's SHIVAN car.
Axles borrowed from RiffRaff's TALON car.
Texture created by Aeon, based on Quake textures off the web.

1904 polygons, including wheels.
================================================================
THANKS to RiffRaff for creating the base models, as well as
all of his other cool POD-style cars.
================================================================
You may use this car however you like and distribute it anywhere,
but please give credit where its due.