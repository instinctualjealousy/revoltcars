And here is the new Pod car conversion. This time it's Catamax. I had to model the body myself
this time, but I think I've done pretty good job at it. The Skin of course is from UbiSoft

Credit goes to Phoenix~ for the skin. Once again, thanks for your help.


The tools used to make this car are

1) Rhino 3D 1.0 - Used to model the body.

2) 3dsmax R2.0 - Used to skin to the body and make minor adjustments to the mesh.

3) Adobe Photoshop 5 - To make the skin.

4) RHQ Car Manager - To make this compilation a little easier.

And yet another Pod car is re-created for Re-Volt


-Vortex
