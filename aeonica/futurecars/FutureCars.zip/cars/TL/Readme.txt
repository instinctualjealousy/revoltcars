Talon my first totally custom car. There is not a peice on it that I did not make myself.

The textures are from a Pod car. It will take some old school Pod player to notice which car they are from. I try but just cant seem to make nice textures myself.

Unzip to cars\Talon.



The tools used to make this car are

1) 3dsmax R2.5 - To make the car body, axles, and wheels-tires.

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.

This car is setup for racing. You will find it runs better in race, in battle tag it doesnt like to jump when you hit the flip button. In fact, all it does is wheely when you hit the flip button, kinda cool in its own way, hehe.

I have gotten feedback that some of my latest cars have a tendency to roll up the walls if you brush against them. It seems the game compiles the car differently each time it starts up. Sometimes the cars will act wierd, other times they are perfect. Every player complaining of this problem are running the warez version of ReVolt.
Go buy the CD if you are having problems. In fact, go buy it anyway.

Having said that...

Have fun!  

RiffRaff
