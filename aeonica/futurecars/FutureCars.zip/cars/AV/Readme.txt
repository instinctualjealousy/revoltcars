This car Av1 is a car from the game Pod. Original Av1 body, using custom wheels.

Unzip to cars\Av1, this will replace the old Av1. No loss trust me.



The tools used to make this car are

1) 3dsmax R2.5 - To make the car body. Used the Av1.dxf available from Ubisoft.
                 The wheels are made custom. 

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.

4) Caffiene- Lots of it.

This is the 3rd of the Pod Cars I wish to create. More to come.

This skin is close to the original, needs creativity by you players.
Thanks go out to Phoenix~ for the textures.


Have fun!  

RiffRaff
