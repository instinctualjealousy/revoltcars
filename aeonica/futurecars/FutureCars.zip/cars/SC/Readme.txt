Body is from the it's original game "POD". The textures were supplied by Phoenix.

The tools used to make this car are

1) 3dsmax R2.0 - Used for the body and wheels 

2) Adobe Photoshop 5 - To make the skin.

3) RHQ Car Manager - To make this compilation a little easier.

Once again, I'd like to thank RiffRaff (LB) for teaching me how to create custom cars in 3dsMax. Thanks Bud!


Have fun with Scorp!  

-Vortex
