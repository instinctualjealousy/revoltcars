Alien is actually Bakar from pod. But the Bakar skin was so poor I couldnt help myself.
What you are seeing is the art from H. Giger.

This download was a little large because of the tires-wheels. Look at them closely, they have a different look and build than all the rest.

Please ask me first if you are going to copy my car and call it your own, its just common courtesy. Thanks.



Unzip to cars\Alien.



The tools used to make this car are

1) 3dsmax R2.5 - To make the car body, and wheels-tires.

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.

This car, like most of mine, are made for racing only. I dont think the car is suitable for Battle Tag.

Have fun!  

RiffRaff
