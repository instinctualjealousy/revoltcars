This is the track "Newk". It is a Pod track conversion. The track mesh is copyrighted by UBISOFT. In Pod, it is called "Nuke".

All textures are copyrighted by UBISOFT, but I have changed a few of them around. The track itself is textured close to, but not exactly like the original.

The path has been changed, and there has been a modification to the original track. So if you have played Nuke, you will have to learn a couple new lines. This track is well suited to modified cars. For the beginner class cars, it is pretty easy to get around the track. There are a few sections where traction is limited, to offer up a bit more challenge.
Powerups are here and there, enough to keep it interesting for those who use them.

As this is my first track, ever, you probably will find a few mistakes here and there. If you do find anything MAJOR that effects gameplay, email me at leadbest@gorge.net. Minor issues will not be addressed.

Thanks, and I hope you like it.

RiffRaff
3-17-2001