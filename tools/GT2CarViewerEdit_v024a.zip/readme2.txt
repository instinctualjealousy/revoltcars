          GT2CarViewer v0.2.3a
=================================================================

This is a quick fork / hack of GT2CarViewer v0.2b by Leo2236, in
order to implement some UI and usability tweaks to make life
easier for GT2 modders and researchers.

=================================================================

Changelog:

v0.2.4a
* Fix UV maps retaining old geometry when a car with fewer vertices
  is loaded after a larger car.

v0.2.3a
* Fix UV map drawing breaking when a model uses a UV Y coordinate
  of 224.

v0.2.2a

* Port to a newer version of Delphi, to replace an unlicensed
  gzip component with the built-in gzip library. Rewrite use of
  gzip to use this library, which conveniently also fixes crashes
  when scrolling quickly through cars.

v0.2.1a

* Reorganise the UI to maximise the size of the render window.
* Store the last selected path, checkbox state, and render
  background colour in the config file.
* Resize the texture preview to the correct 256x224.
* Change the vertex colour to magenta rather than yellow, and
  shrink the size on the texture preview from 2x2 to 1x1 to trade
  visibility for accuracy.
* Remove the gradient and vignette from the render, as well as
  the FPS counter.

=================================================================

Credits:

Original tool: Leo2236
Hacks & edits: pez2k & TheAdmiester

=================================================================

THE END