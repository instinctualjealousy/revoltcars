|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
|                NFS4-Editor                
|              FCE Finish v2.00        
|               ++++++++++++                
|          Download from nfs2000.de         
|           URL: www.nfs2000.de           
|        e-mail: support@nfs2000.de       
|             Release: 02/2002              
|               ++++++++++++                
|        Author of Tool: Klaus Heyne
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~




FCE Finish V 2.00.01 � 2001-2003 by Klaus Heyne, www.heyne-multimedia.de/nfs

Installation------------------------------------------------------------------------------------------

Extract the zip archive to any place on your harddisk and run "setup.exe". 




Installation------------------------------------------------------------------------------------------

Das ZIP-Archiv extrahieren und "setup.exe" starten. 




Conditions of use-------------------------------------------------------------------------------------

This program is copyright � 2001-2003 by Klaus Heyne. You are authorised to use the program for your own private use but you may not sell the program or remove any copyright information from it. It is strictly prohibited to distrube this program by other means than the internet without prior permission from the author.

The author cannot and does not warrant that any functions contained in the soft- or hardware will meet your requirements, or that its operations will be error free. The entire risk as to the soft- or hardware performance or quality, or both, is solely with the user and not the author. You assume responsibility for the selection of the soft- or hardware to achieve your intended results, and for the installation, use, and results obtained from the soft- or hardware. The author makes no warranty, either implied or expressed, including without limitation any warranty with respect to this soft- or hardware documented here, its quality, performance, or fitness for a particular purpose. In no event shall the author be liable to you for damages, whether direct or indirect, incidental, special, or consequential arising out the use of or any defect in the soft- or hardware, even if the author has been advised of the possibility of such damages, or for any claim by any other party. 

All other warranties of any kind, either express or implied, including but not limited to the implied warranties of merchantability and fitness for a particular purpose, are expressly excluded. 

The author is not connected or affiliated with any mentioned company in any way. The opinions of the author do not reflect the views of the various companies mentioned here. Companies and all products pertaining to that company are trademarks of that company. Please contact that company for trademark and copyright information.
======================================================================================================

Version History---------------------------------------------------------------------------------------

V 1.00 (02-27-01)

First Release



V 1.01 (03-01-01)

Bugfixes:
* Edited colors were not saved: Fixed.
* Part Import/Export didn't support driver movements: See "New Features".
* Minor bugfixes to the part list.

New Features:
* Additional file format (*.ffp) for Part Import/Export. It's recommended to use this format for exchanging parts with FCE Finish. In opposite to the Wavefront and DXF formats, the ffp-format supports all data including damaged vertices and driver movements.
* The Part Editor displays the number of vertices and polygons of the selected part.
* When loading a FCE file, the model will be centered, so that the wheels will correctly stand on the ground!

V 1.02 (07-15-01)

Bugfix:
* Centering model on loading didn't consider dummies: Fixed.

New Feature:
* Centering model on loading is now optional. You'll find a checkbox menu entry in the file menu.

V 2.00 (11-11-01)

New Features:
* Texture mapping added. A new editor enables you to map selected polygons. You may create new texture coordinates or edit the current ones. All changes are displayed in real time on the 3d model.

* Optional Context Help. Moving the mouse cursor over certain buttons displays help texts. The Context Help can be switched off and on in the Info menu.

V 2.00.01 (01-30-02)

Bugfix:

* Functions to manipulate borders of polygon groups didn't work correctly: Fixed. Note: The handling of the tools for smoothing/sharping single edges has changed. See online help chapter "surfaces".

======================================================================================================

Versions-�berblick------------------------------------------------------------------------------------

V 1.00 (27.02.01)

Erstes Release



V 1.01 (01.03.01)

Bugfixes:
* Editierte Farben wurden nicht gespeichert: Behoben.
* Part-Import/Export unterst�tzte keine "Driver Movement"-Daten: Siehe "Neue Features".
* Kleinere Fehler in der Part Liste behoben.

Neue Features:
* Zus�tzliches Dateiformat (*.ffp) f�r den Part-Import/Export. Dieses Format sollte ab jetzt zum Austausch von Parts mit "FCE Finish" verwendet werden. Im Gegensatz zum Wavefront- und DXF-Format, werden beim ffp-Format alle Daten unterst�tzt, inklusive "Damaged Vertices" und "Driver Movements".
* Im Part-Editor werden jetzt die Anzahl der Punkte und Polygone des selektierten Parts angezeigt.
* Beim Laden einer FCE-Datei wird das ganze Modell neu zentriert, damit auf jeden Fall die R�der auf dem Boden stehen!

V 1.02 (15.07.01)

Bugfix:
* Das automatische Zentrieren des Modells beim Laden verga� leider die Dummies: Behoben.

New Feature:
* Das automatische Zentrieren des Modells beim Laden ist jetzt optional. Es gibt einen entsprechenden Checkbox-Men�eitrag im File-Men�.

V 2.00 (11.11.01)

Neue Features:
* Texture mapping hinzugef�gt. Ein neuer Editor erm�glicht, ausgew�hlte Polygone zu mappen. Es k�nnen neue Textur-Koordinaten erzeugt oder die aktuellen bearbeitet werden. Alle Ver�nderungen werden in Realtime am 3D-Modell dargestellt. 

* Optionale Kontext-Hilfe. Wenn der Mauszeiger �ber einem Button steht, wird ein Hilfetext eingeblendet. Die Hilfe kann im Info-Men� ein- und ausgeschaltet werden.
 
V 2.00.01 (30.01.02)

Bugfix:

* Die Funktionen zur Manipulation der Grenzen der Polygon-Gruppen arbeiteten nicht korrekt: Behoben. Bitte beachten: Die Bedienung der Tools zum Gl�tten/Sch�rfen einzelner Kanten hat sich etwas ge�ndert. Siehe Online-Hilfe Kapitel "Surfaces".
 