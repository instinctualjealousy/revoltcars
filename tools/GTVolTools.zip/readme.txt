There are six tools in this download. 

Requirements
---------------
.Net 2/3.5 is required to run these apps. This should automatically be installed by Windows if you don't have it installed. GMCreator and GT2ImageConverter may run on Mono, the others will not.

The tools
---------------

GTVolToolGui - Most will want to use this. It allows you to rebuild* and extract from GT2, GT2000 & GT3 VOL files, including GT Concept (including demos of all these games) with a relatively simple Windows interface.

GTVolTool - This is a command line version of the above. It does the same but can also list the file size and locations of contents in GT2 and GT3 vols. These lists can help when you only want to replace single files without having to explode and rebuild an entire file.

GT2DataExploder - This is another command line tool that extracts data from an extracted GT2 VOL (final game only, doesn't work on demos) and transforms most of the car and race data into tabbed text files. Most of the useful extracted data is already on my GT2 website at http://gt2.airesoft.co.uk. Most people will not need to use this tool, but I included it anyway. 

GMCreator - A GUI that creates and edits Gran Turismo 2 foreground menu files. It can also extract from and create the VOL/gtmenu/CommonPic.dat and VOL/gtmenu/<language>/gtmenudat.dat files that contain the background menu graphics and foreground graphics respectively.

GT2ImageConverter - A command line tool to convert JPG, PNG, and BMP files to GT2 compatible background and foreground  menu images.

ISOFileReplace - A simple GUI around a Spanish command line tool that can replace files in Iso and bin images with new ones. It only works with Mode2/2352 Playstation iso and bin images, which means it doesn't work with every bin/iso in existance.

The src directory also includes a GTMP project that includes C# code to display GT2 GM & GTMP files (final game only), most GT3/4 Tex1 images (inc demos), and to parse out info from the db files from the database folder in GT3 VOLs.