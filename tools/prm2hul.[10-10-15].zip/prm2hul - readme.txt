------------------------------------------------------------------------------
prm2hul - (c) jigebren - Rel.10-10-15
------------------------------------------------------------------------------
2010-10-15

  webpage:  http://jigebren.free.fr/jeux/pc/revolt/index.html
    email:  jigebren@free.fr
ORP forum:  http://z3.invisionfree.com/Our_ReVolt_Pub/index.php?showtopic=1440

==============================================================================
This utility is released as freeware.
The software is provided "AS IS" without any warranty.
You are not allowed to redistribute this archive or any of the included files.
==============================================================================

* Quick instruction


Extract the files in the archive anywhere on your harddrive.

Run "prm2hul.exe".

Select the working directory, where the .prm/.m source files are located, and 
also where the .hul file will be created/written.

You don't have to modify the "Advanced engine parameters". Using the default 
values should be ok in most cases.
Just set the number of spheres that will be used to fill the hull (don't set 
it to a too high value as it will increase the load of calculation for Re-Volt 
without a real interest). Using a balanced value, between 3 and 20 should be 
enough. 
This trick can be used:
Run it with a high value (like 30 spheres) and look at the log infos. You can 
then estimate the efficiency of each new added spheres, and use the number of 
sphere above which there is real difference anymore (in the returned values 
like "BBox is covering..." or the remaining volume). I'll try to explain this 
in more details eventually...


You can ask for clarification and report feedback on ORP forum (see the link 
in the header of this file).

Hope you will enjoy this tool.


jigebren.

------------------------------------------------------------------------------

* Notice

qconvex:
The external tool qconvex.exe is provided to compute the convex hull part of 
the model. Prm2hul can work without qconvex, but it will be less efficient and 
way slower...
To get more information about this tool, see: http://www.qhull.org/

==============================================================================

* Changelog


* Rel.10-10-15
Mod: The log layout now include each sphere coordinates and radius.
Add: Allow overshot: (experimental, mostly intended for thin objects)
     Allows spheres to go over the CHull limits by a given percentage (100% 
     corresponds to the smaller side of the convex hull's bouding box).
     Default value of 0% should be appropriate in most case. 
Add: Copy result to clipboard:
     Fills clipboard with the tabulated log data. It can then be easily 
     imported in any spreadsheet program (like eg. OOo's Calc or Excel), so 
     that curves can be drawn to visualize the progression of parameters versus 
     the number of spheres (it can be used to determine the optimal number of 
     spheres to use for a given model).


* Rel.10-09-11
First release, probably still in beta stage.

==============================================================================
jigebren.
