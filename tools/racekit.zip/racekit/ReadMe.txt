RACE CAR KIT 1.0
================================================================
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This kit is meant to sport up your cars.
You can finally have huuge rear and front wings without making them all
by yourselves. There are two wayz to use the things in this kit.

1. You take one .prm out of the whole pack and set it up in your
parameters.txt as the spinner. You'll have to adjust the offset, then
and you can only use one prm at a time. And make sure you put ONE
axis to 1.000000.
2. If you are a bit skilled in 3d modelling, then open the car you
want to use this kit on and then put the wings or the intake where
you want to have them.

The only real problem with using this kit is the way they use the bmp.
They are mapped to certain parts of the bmp and that may cause that
they can't work on sum cars bcuz it'll just look dumb. But on most of
the cars you should at least be able to use the wings wothout any problems.

Info files		:
There's a template .bmp which shows where what is mapped on the .bmp.

There's example1.jpg which shows the usage of the kit with first way
on our Ferrari 360 Modena. This car won't be released.

There's example2.jpg which shows the usage of the kit with the second
way on the Sprinter XL. That CAT-car will be released. 


Additional Credits to   : You for downloading this kit; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and KillUncle for makin the parts of
this kit.
================================================================


Poly Count              : 16 polies for front wing (fronwing.prm)
			: 16 polies for rear wing  (rearwing.prm)
			: 12 polies for air intake (intake.prm)
Editor(s) used          : PSP 5.1; ZMod; RVShade 
Known Bugs              : none

* Copyright / Permissions *

This KIT is made for authors to use on their cars, so you are
allowed to USE it, to resize it and to overwork it in every way!
Just make sure you credit us in your ReadMe, please.

You MAY distribute this KIT, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this KIT *

Websites : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/uploads/racekit.zip
