@echo off
ECHO This backs up the old textures....
pause
copy envroll.bm* envrollbak\envroll.bm*
ECHO This copies the new textures...
pause
copy envroll\envroll.bm* envroll.bm*
cls
ECHO Custom ENVroll is now installed. Run "Custom ENVroll Uninstall.bat" to uninstall!
pause