@echo off
ECHO This restores the original ENVroll textures...
pause
copy envrollbak\envroll.bm* envroll.bm*
ECHO Deleting backed-up textures...
pause
del envrollbak\envroll.bm*
cls
ECHO Custom ENVroll uninstalled!
pause