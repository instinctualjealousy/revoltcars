@echo off
ECHO This restores the original tread textures...
pause
copy originaltread\Shadow.BM* Shadow.BM*
ECHO Deleting backed-up textures...
pause
del originaltread\Shadow.BM*
cls
ECHO Custom treads uninstalled!
pause