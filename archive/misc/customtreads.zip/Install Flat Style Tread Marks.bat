@echo off
ECHO This backs up the old textures....
pause
copy Shadow.BM* originaltread\Shadow.BM*
ECHO This copies the new textures...
pause
copy customtread\flat\Shadow.BM* Shadow.BM*
cls
ECHO Flat style tread marks are now installed. uninstalltreads.bat to uninstall!
pause