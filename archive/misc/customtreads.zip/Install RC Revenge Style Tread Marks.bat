@echo off
ECHO This backs up the old textures....
pause
copy Shadow.BM* originaltread\Shadow.BM*
ECHO This copies the new textures...
pause
copy customtread\rcrevenge\Shadow.BM* Shadow.BM*
cls
ECHO RC Revenge PSX style tread marks are now installed. uninstalltreads.bat to uninstall!
pause