PLEASE READ THIS!:

Put all files in \gfx directory.
Please uninstall the treads before you install new ones, or you'll find that the original treads will be missing! 
So please, uninstall before installing a different style.

These batch files aren't in any way viral.

Yours Truly,
Adamodell

P.S. To install, click on the install button, it wlll back up the original files and copy the new corresponding ones. RC Revenge style is my favorite.