@echo off
ECHO This restores the original tread textures...
pause
copy originaltread\Shadow.bm* Shadow.bm*
ECHO Deleting backed-up textures...
pause
del originaltread\Shadow.bm*
cls
ECHO Custom treads uninstalled!
pause