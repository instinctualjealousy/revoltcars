@echo off
ECHO This backs up the old textures....
pause
copy Shadow.bm* originaltread\Shadow.bm*
ECHO This copies the new textures...
pause
copy customtread1.2\slicks\Shadow.bm* Shadow.bm*
cls
ECHO SLICK tire tread marks are now installed. uninstalltreads.bat to uninstall!
pause