================================================================
Car Information
================================================================
Car Name  : Chevrolet Cavalier v2
Car Type  : Conversion/Repaint
Folder	  : ...\cars\c-cavalierv2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 43 mph I think...
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (newly updated again as of Dec. 23rd!)

================================================================
Car Description
================================================================
Original: Conversion of SYC's Chevy Cavalier, didn't come with a readme or contact info, sadly enough!
I made MANY, MANY texture edits to make the car appear its best, included original texture for proof. (Although it ain't tuned for the car so to speak!, and also it won't be included in the RVZT release)
As you can see, this guy was a good modeler, but not a good texturer. I even put shadow under the spoiler!
Wheels mesh is from a BMW, and the wheel texture is my own.

Additions: New wheels! taken from TMAM's V8 Star conversion, wheel texture from Ryuji's Silvia S15 that I converted. Parameters slightly edited, textures edited slightly for quality also! Also fixed "black boxed" steering wheel, now pureblack where it should be!

================================================================
Construction
================================================================
Base           : NFS4 model (SYC) converted by me
Poly Count     : Methinks 2000-2500 with wheels more like 3000-3500
               : 
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) ntdll.dll gotta love it
Known Bugs     : Absolutely none ATM (as always)

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to SYC, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: I already repainted it B%TCHES!
Although I'm sure you can come up with something!
================================================================
Where to get this CAR
Websites: RVZT and my site...
