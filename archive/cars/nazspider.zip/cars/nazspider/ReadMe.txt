================================================================
Car Information
================================================================
Car Name  : Nazca C2 Spider
Car Type  : Conversion
Folder	  : ...\cars\nazspider
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Same speed as nearly 80% of my cars, peaks at around 42
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (myatsoe's and EA's model)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : NOW AT: http://fallingupward.net/adamodell

================================================================
Car Description
================================================================
Car by myatsoe. You can tell it was based on the original Nazca C2. I actually used scloink's rims on this one. I moved the UV map to the new wheel position. Then I flipped the wheel around and repeated the process. I hope you enjoy my work. Will make it on RVZT WHEN it is back up :P
Also, I used RST's R3-DCP to view the car for errors. I adjusted some params with it.
I also deleted the window polies instead of remapping them. You won't care.

I made the wheel texture from a heavily modified version of the original.

================================================================
Construction
================================================================
Base           : NFS4 car by myatsoe
Poly Count     : You really shouldn't care... 2600 is a good estimation
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : Umm, umm, can't really come up with any.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to myatsoe, for the whole car body, and scloink for his awesome wheels.
I don't really care to list everybody I thank this time, it's on all of my older readme's :P

================================================================
Copyright / Permissions
================================================================
Authors MAY NOT (hmm, maybe you can if you're nice) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net (if or when it is up)
          http://fallingupward.net/adamodell