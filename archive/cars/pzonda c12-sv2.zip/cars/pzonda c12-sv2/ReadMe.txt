================================================================
Car Information
================================================================
Car Name  : Pagani Zonda C12-S v2
Car Type  : Conversion
Folder	  : ...\cars\pzonda c12-sv2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 42 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated as always)

================================================================
Car Description
================================================================
A conversion of Fivespeed's Pagani Zonda C12-S that was originally for Need for Speed 4
Repainted black because I like black, made it a shade brighter on version 2.
Changed the interior colors to shades of blue or grey, updated wheel positions to be WAY more realistic, rear wheels slightly larger, removed shininess, centered.

Pretty much standard fare.

================================================================
Construction
================================================================
Base           : NFS4 model (Fivespeed) converted by me
Poly Count     : 6027 for body, maybe 1000 for each wheel, check original readme)
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : It didn't shine perfect upon looking at it further. Removed shine, no more known graphical glitches.
================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
Fivespeed (Whole mesh, wheels and body, textures)
Me (making it black/grey)
================================================================
Copyright / Permissions
================================================================
Authors MAY NOT use this car as a base to build additional cars.
(It's not one of those cars that is good for repainting)
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
