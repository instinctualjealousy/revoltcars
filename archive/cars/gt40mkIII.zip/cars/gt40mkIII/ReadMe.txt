================================================================
Car Information
================================================================
Car Name  : Ford GT40 MKIII
Car Type  : Conversion
Folder	  : ...\cars\gt40mkIII
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Really fast is all that you need to know :P
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell (newly updated again)

================================================================
Car Description
================================================================
GT40 MK1's pretty sweet GT40 MKIII model. Is highpoly, removed ENV and deleted light polygons. Parameters by Manmountain. Also, my last 3 conversions (Koenigsegg CC, Volkswagen W12 Coupe, and Spyker C8 Laviolette) have screwed up readme's. They say Ryuji Kainoh under "Individual Thanks..." even though they say DaiN elsewhere. Sorry for this error, but I am not fixing a car over a readme error.

================================================================
Construction
================================================================
Base           : NFS4 model (GT40 MK1) converted by me
Poly Count     : Body: 5652 Polygons  Wheels: 1012 Polygons each
               : 
Editor(s) used : Paint.NET, RV Minis 5, Chaos Tools, Zmodeler 1.07b
Known Bugs     : Absolutely none to what I know.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to GT40 MK1, but here is other thanks:
Manmountain: The parameters of this car
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools
Rocket for NFSFCEConverter

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: NOT GREY.

================================================================
Where to get this CAR
Websites: RVZT and my site, as always, never will change
