Version 2- This is a quick revision that fixes many naming scheme errors, and now the custom shadow appears.
I also edited the headlights and rear lights a bit further, but it's essentially the same car.

I've released this car for Re-Volt. As a test of my converting abilities I re-converted it to MM2. Thanks to robenue for helping give me the strength to do this.

I'm not sure if I have my heart in this though.