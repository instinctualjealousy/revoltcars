﻿Serial Number 38.
Body mesh converted from:                                                                  
                                                                                      
                                   ░░▒▒▒▒▒▒▒▒▒▒         ░▒▒▒▒▒▒▒▒▒▒▒▒░                
                              ░▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓░         ▓▓▓▓▓▓▓▓▓▓▓▓▓                 
                           ░▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓         ░▓▓▓▓▓▓▓▓▓▓▓▓▒                 
                         ▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░         ▓▓▓▓▓▓▓▓▓▓▓▓▓                  
                       ▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓         ░▓▓▓▓▓▓▓▓▓▓▓▓░                  
                     ░▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░         ▓▓▓▓▓▓▓▓▓▓▓▓▓                   
                    ░▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░        ░▒▓▓▓▓▓▓▓▓▓▓▓▓▒                   
                   ▒▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒░░       ░▓▓▓▓▓▓▓▓▒░░░░░░░░░░░░                    
                  ░▓▓▓▓▓▓▓▓▓▓▒░             ▒▓▓▓▓▓▓▓▓                                 
                  ▓▓▓▓▓▓▓▓▒                ░▓▓▓▓▓▓▓▓░                                 
                 ▒▓▓▓▓▓▓▒                  ▒▓▓▓▓▓▓▓▓                                  
                 ▓▓▓▓▓▓░         ░▒▒▒▒▒▒░ ░▓▓▓▓▓▓▓▓░                                  
                ░▓▓▓▓▓         ░▓▓▓▓▓▓▓▓░ ▒▓▓▓▓▓▓▓▓                                   
                ▒▓▓▓▓░         ▓▓▓▓▓▓▓▓▓  ▓▓▓▓▓▓▓▓░                                   
                ▒▓▓▓▓         ▒▓▓▓▓▓▓▓▓░ ▒▓▓▓▓▓▓▓▓                                    
                ▒▓▓▓▒         ▓▓▓▓▓▓▓▓▓  ▓▓▓▓▓▓▓▓▒                                    
                 ▓▓▓▒        ▒▓▓▓▓▓▓▓▓░ ▒▓▓▓▓▓▓▓▓                                     
                 ▒▓▓▓        ▓▓▓▓▓▓▓▓▓  ▓▓▓▓▓▓▓▓▒                                     
                  ▓▓▓▒      ░▓▓▓▓▓▓▓▓░ ▒▓▓▓▓▓▓▓▓                                      
                   ▓▓▓▒                                                               
                    ▒▓▓▓░                                                             
                      ▒▓▓▓░                                                           
                        ░▒▒                                                           
                                                                                      
          ░▓▓▓░ ▓▓▓▓░   ▒▓░  ▒▓░ ▓░   ▒▓▓▓▓░▓▒ ▒▓ ▒▓▓▓▒ ▒▓  ▒▓▓▒ ▒▓▓  ▓▓░ ▒▓▓▓  ®  
         ▒█░░█▒░█▒░█▓  ▓▓█▒ ░██░▒█    ░▓█░░▒█░░█▒░█▒░█▓ █▓ █▓ ▓▓ ██▓ ▓██░▓█░▒█▒    
        ░█▓    ▓█░▓▓░ ▒▓░█░ ▓▓▓░█▒     █▒  █▓ ▒█ ▓█▒▒▓░▒█░░█▓▒  ▒█▓▒▒▓▓▓░█▒ ▓█        
        ▓█░▒█▒░█▓▒█▒ ░█▒▒█░░█░█▓█     ▒█░ ▒█░ █▓ █▓▒█▒ ▓▓  ░▓██ █▒▓▓▓▒█░▓█  █▓        
        █▓ ▒█░▓█ ░█░░█▓▓▓█ ▓▓ ██▓     █▓  ▓▓ ▒█░▒█ ░█▒░█▒▒▓  █▓▒█ ██░▓▓ █▓ ▓█         
        ▓█▓▓▒ ▓▒ ▒▓ ▓▓  ▓▓░▓░ ▓▓░    ░▓░  ▒▓▓▓░ ▓▒ ▒▓░▓▓ ░▓▓▓▒ ▓▒ ▓▒░▓░ ▓▓▓▓    2      

                               THE REAL DRIVING SIMULATOR

This car was originally converted from GT2 for the RC racing game Re-Volt that has been dwindling in popularity in recent years. This was an advancement in my abilities as the whole car was UV mapped from scratch, which is something I am not well versed in. You can get the Re-Volt version here:

http://fallingupward.net/adamodell/zzIIminisite

Well, I really wanted to test myself in converting it to NFS4 with only the limited knowledge of the innards of cars based on my NFS4 to RV conversions. This is the anti of that. This car's history would be GT2 to Re-Volt to NFS4.

The parts:

:HB (converted and UV mapped from GT2)
:H*** Made myself, perfectly symmetrical, to the point of the Dunlop logos being flipped on the right side (don't feel like fixing!).
Dummy:* All pretty much ripped from other cars, tweaked one half, and copied, and then mirrored it, positioning perfect!

The car has all the working dummies and such. License plates, front lights, brake lights, reverse lights, you name it. They were mirrored in ZModeler 2 so they are perfectly positioned.

I used nearly all the programs in the NFS4 car making/converting arsenal, including:
NFS Wizard
CarCad
VIV Editor
FCE Finish
FCE Center
QFSSuite
ZModeler 1 and 2 for different functions
...and who knows what else.

As for the soudns... I used Audacity to edit, and convert the sounds from GT2. I only had one source for the engine, a recording of the ZZII going full speed. I lowered it down based on a scale set by Zpectre, who's tutorial on sounds was spectacularly easy to understand.

As for the history of the car in RV, the body was converted from GT2 with no textures included (thanks to Oleg, *cough*), so I ran GT2 in ePSXe at 800x600 resolution and printscreened the car at all rotations. I then used Rick Brewster's underappreciated Paint.NET to make a texture sheet out of all my captures. I then did some not-so-professional UV mapping. But the car still looks excellent, nonetheless. (btw, the carp.txt was modified from the Porche 911's version!)

The VidWall is from an actual capture of GT2 (filtered about 500 times ftw), as it seems there are no documented "real" pictures of this car, must of just been a prototype model leaked to Polyphony Digital. As the ZZII in GT3 and 4 (and real life) looks much much different.

The changes to the car for NFS4 exclusively:
1. A dash from the Nissan Skyline GT-R V-Spec (right side steering wheel ftw), with a modified texture for the wheel and a replacement of the original spoiler of the Skyline dash with the actual car's spoiler. Put it in dash view and look back, and you'll see.

2. Very difficult modification of the source textures (made from GT2 printscreening) to a transparent version that allows NFS4 to filter colors through it. Much layering and copying/pasting was to be had here. Now everything has alpha value 224 where it should be.

4. A mixture of two of my texture sets in the Re-Volt version... this is the stock version except for the bottom of the back and the spoiler's GT2 graphic.

5. Textual engine, power, and other details converted from GT2 values. I converted the millemeter values to inches for the frontend.

6. Custom engine sound effects, exterior and interior, modified shift sound (for interior), and higher pitched horn.



Limitations of this version:

Only an Fedata.eng, no other languages!
No dash.fsh, doesn't seem to affect me.


Please convert to NFS3 if you wish. No need to contact me, just give me credits. And, I made the wheels myself in ZModeler 1.07b, so if you'd like to use them on your own cars (they fit Ryuji Kainoh cars with the current UV), drop a line, please.


I'm not going to be really strict like most people here. Just give me credits and you can do whatever the everloving hell you want to do with it. If you must rice it, rice it good. I better end this huge essay before I blow your heads off with too much data.
