================================================================
Car Information
================================================================
Car Name  : Alfa Romeo GT
Car Type  : Conversion
Folder	  : ...\cars\alfagt
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 40~ mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.fallingupward.net/adamodell/ (down right now, wait a few days, as 
of 3/22/08, or 22/3/08 for you Brits...)

================================================================
Car Description
================================================================
Conversion of Power^Steer|nG's Alfa GT.

This car was held off for a half year, awaiting a fix. I ended up deleting the window and 
light polies, and all is good.

Flaws: Little crack on front window, you can see through car, although insanely small and 
not obvious. It is a modeling flaw, the car isn't perfectly symmetrical.
Also, the driver's seat is black on the rear of it, don't know why. All is good otherwise, 
with some very unique params unlike all of my cars, the closest would be that horrible 
Lambo Gallardo.

================================================================
Construction
================================================================
Base           : NFS4 model (Power^Steer|nG) converted by me
Poly Count     : 3000ish
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) 
ntdll.dll gotta love it
Known Bugs     : Fixed all that were known

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this 
car (and many other way better ones I might add) is what is keeping the community alive even
 through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes Power^Steer|nG, but here's other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model, now for making me create a multi-color car!
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site, when it is back up!