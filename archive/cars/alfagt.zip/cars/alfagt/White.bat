@echo off
copy white.bmp car.bmp