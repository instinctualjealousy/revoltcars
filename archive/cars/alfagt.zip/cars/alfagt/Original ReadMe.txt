Alfa Romeo GT 2004

Features:
-----------------
3d rims
3d lights
Interior
NOS Boost
Polies: 4000
-------------------

Do not edit or upload car for public purposes without
my permission. You can edit the car for your personal use only.

=============================
End of original readme
=============================

Adamodell:

P.S.: I don't really know if conversions count in this readme or not.

So, Power^Steer|nG, don't kill me.
