@echo off
copy silver.bmp car.bmp