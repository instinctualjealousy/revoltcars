================================================================
Car Information
================================================================
Car Name  : Lambo Gallardo v2
Car Type  : Conversion
Folder	  : ...\cars\lamgallardov2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 44ish mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (VSO's model)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell (updated daily lol)

================================================================
Car Description
================================================================
This car is also quite a performance hit on DINO PC's :)

This car is by VSO but I also couldn't contact him to ask him to convert it, so respect goes to him.

I fixed it, I didn't doubleside it this time, and removed the shininess, so there aren't any weird shine artifacts when you get real close to the body with the camera. It now comes in more colors, with the fixed body I was talking about. The parameters were tweaked to be less grippy.
================================================================
Construction
================================================================
Base           : NFS model (VSO) converted by me
Poly Count     : 9000ish
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : None, now correctly matte (no shine AT ALL now, at any distance) using TMAM techniques.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to VSO. 
All I needed was to waste my time converting it, Zmodeler 1.07b keeps crashing...
They really need to make a Zmodeler2 filter for Re-Volt.

================================================================
Copyright / Permissions
================================================================
Authors MAY NOT (I guess) use this car as a base to build additional cars.
You can't repaint it, lol. The texturing is too horrible for repaints.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.
Any way you can't really repaint it (except for the color).

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
