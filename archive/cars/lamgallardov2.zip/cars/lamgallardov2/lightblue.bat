@echo off
copy lightblue.bmp car.bmp