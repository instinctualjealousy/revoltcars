================================================================
Car Information
================================================================
Car Name  : Honda CRX v2
Car Type  : Conversion\Repaint
Folder	  : ...\cars\crxv2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 39 mph I think... I really need to change that...
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell (won't ever die, I promise [not really])

================================================================
Car Description
================================================================
Conversion of Ryuji Kainoh's CRX.
This is a major overhaul. I remapped the windows so there is no mirror/window conflict(little black square on upper right hand side is the window mapping), RV-Centered the body, resized body by 0.97 with RV-SIZER, kept model undoublesided due to errors, and is now using my new rims. I made a paintjob.pdn (Paint.NET format) that allows you to quickly make new colors of the car.

================================================================
Construction
================================================================
Base           : NFS4 model (Ryuji Kainoh) converted by me
Poly Count     : Below 1000, now with 258 (x4) poly wheels
               : 
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : Closest thing to a bug is that I forgot to remap the two farthest polygons (left and right sides, symmetrical) on the rear window. Look at the far side and you'll see a black polygon on the rear window. Pretty dumb mistake. Unnoticeable, for the most part.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh, but here's other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model (but those wheels are the farthest thing from low-poly)
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools....

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site...
