================================================================
Car Information
================================================================
Car Name  : Chaparral 2F v2
Car Type  : Conversion\Repaint
Folder	  : ...\cars\chaparral2fv2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : ...not 39! 64 mph (yes, that is fast)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell (just check it)

================================================================
Car Description
================================================================
Conversion of Fivespeed's custom scratch built Chaparral 2F.
I centered it, and now removed the shine (due to those lovely errors). I also fixed the 
CoM so that the car won't flip over as much. I have a feeling some TMAM conversions have 
no shine for a reason, due to the errors I experienced.

================================================================
Construction
================================================================
Base           : NFS4 model (Fivespeed) converted by me
Poly Count     : Unknown (Check original readme maybe)
               : 
Editor(s) used : Paint.NET, RV Minis 5, Chaos Tools, Zmodeler 1.07b=(crashes so DAMN much 
on XP!!!!) ntdll.dll!!?!?!
Known Bugs     : Absolutely none ATM, especially now that I fixed (removed) the shine and 
centered it.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this 
car (and many other way better ones I might add) is what is keeping the community alive even
 through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Fivespeed, but here is other thanks:
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model (even though this is highpoly)
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools
And also thanks to TM&M for their Actros conversion's hull file (because I'm just that lazy)

================================================================
Copyright / Permissions
================================================================
Authors MAY NOT use this car as a base to build additional cars.
BUT you can repaint it...
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: Maybe a special black version... (I just did it, you can do better)

================================================================
Where to get this CAR
Websites: RVZT and my site...
