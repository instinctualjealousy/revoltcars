================================================================
Car Information
================================================================
Car Name  : Nissan 240sx
Car Type  : Conversion
Folder	  : ...\cars\240sx
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 43 mph I think...
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (stopped updating my site, all uploads to RVZT)

================================================================
Car Description
================================================================
Conversion of SYC's 240sx (1994).
Hardly any texture edits on this 'un.
I wasted my time making it blue based on Aeon's ideas.

================================================================
Construction
================================================================
Base           : NFS4 model (SYC) converted by me
Poly Count     : Methinks 2000ish
               : 
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) ntdll.dll gotta love it
Known Bugs     : Absolutely none that I know of ATM.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.


The community feels dead right now, do your part and keep it alive!
================================================================
Individual Thanks On This Car
================================================================
All credit goes to SYC, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Corel for PSP 10.03 (for the Red/Green/Blue color edit)

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: uh, yeah.... It's repaintable at least
================================================================
Where to get this CAR
Websites: RVZT
