Car information
================================================================
Car name                : Eclipse Tuner
Car Type  		: Repaint (Eclipse GSX)
Top speed 		: Roughly 80 mph
Rating/Class   		: 4 (Pro)
Install folder       	: ...\cars\eclipse_tuner
Install procedure	: I have a Metallica logo bmp. Just click on "metalliclipse.bat" to replace.
                          Click tuner.bat to switch it back to the normal bmp.
Description             : Set the mood here.
 
Author Information
================================================================
Author Name 		: Adam O'Dell (Adamodell)
Email Address           : metallicafan128@gmail.com
Misc. Author Info       : 
 
Construction
================================================================
Base           		: Modified car "Eclipse GSX" by Scloink
Poly Count     		: Unknown
               		: Unknown
Editor(s) used 		: Corel Paint Shop Pro X, Paint.NET
Known Bugs     		: NONE at the moment
 
Additional Credits 
================================================================
I thank RK for making the model, Scloink for porting it into Re-Volt, and myself for coming up with the design and parameters.
 
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars.  
(One of the following)
You MAY distribute this CAR, provided you include this file, with no 
modifications.

 
Where else to get this CAR
================================================================
FTP sites		:
Website  		:http://revolt.speedweek.net/main/
Other			:www.freewebs.com/adamodell/