@echo off
copy metalliclipse.bmp car.bmp