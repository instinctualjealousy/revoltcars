@echo off
copy tuner.bmp car.bmp