@echo off
cls
ECHO This replaces the car texture.
pause
cls
copy spoon.bmp car.bmp
cls
ECHO This replaces the body.
pause
cls
copy spoonbody.prm body.prm