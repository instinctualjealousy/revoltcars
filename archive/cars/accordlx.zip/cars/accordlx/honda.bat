@echo off
cls
ECHO This replaces the car texture.
pause
cls
copy normal.bmp car.bmp
cls
ECHO This replaces the body.
pause
cls
copy hondabody.prm body.prm