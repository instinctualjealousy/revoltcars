================================================================
Car Information
================================================================
Car Name  : Honda Accord LX
Car Type  : Conversion
Folder	  : ...\cars\accordlx
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 43 mph I think... slightly varied depending on what params you are using
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (newly updated again, it's been a while)

================================================================
Car Description
================================================================
Conversion of SYC's Accord LX, didn't come with a readme or contact info, sadly enough!
I made MANY, MANY texture edits to make the car appear its best, included original texture for proof.
As you can see, this guy was a good modeler, but not a good texturer (again). I even put shadow under the spoiler! (again)
Wheels mesh is from a BMW, and the wheel texture is modified slightly from the original.
It also comes with a Spoon repaint.

================================================================
Construction
================================================================
Base           : NFS4 model (SYC) converted by me
Poly Count     : Methinks 1500-ish
               : 
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) ntdll.dll gotta love it
Known Bugs     : Absolutely none, wheels mapped kinda weird, but as perfect as I can get 'em.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to SYC, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: I already repainted it B%TCHES! (but a tuner model that ISN'T GREY would be cool also)

================================================================
Where to get this CAR
Websites: RVZT and my site...
