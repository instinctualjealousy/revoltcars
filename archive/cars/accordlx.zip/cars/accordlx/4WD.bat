@echo off
cls
ECHO This gives the car a four-wheel drive transmission.
pause
cls
copy 4WD.txt Parameters.txt