@echo off
cls
ECHO This gives the car a front-wheel drive transmission.
pause
cls
copy FWD.txt Parameters.txt