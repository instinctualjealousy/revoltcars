================================================================
Car Information
================================================================
Car Name  : Maserati MC12 v2
Car Type  : Conversion
Folder	  : ...\cars\mc12v2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 40ish mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (Reilsss's model)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (updated daily as of Dec. 23rd, 2007)

================================================================
Car Description
================================================================
This car is also quite a performance hit on DINO PC's :)

This car is by Reilsss but I couldn't contact him to ask him to convert it, so respect goes to him.
================================================================
Construction
================================================================
Base           : NFS model (Reilsss) converted by me
Poly Count     : Dunno
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : None, fixed the majority of texture problems on first release, all textures appear now, and the wheels don't sink into the ground as much! And the shininess is nearly amazingly perfect for such a high poly model.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Reilsss, and some to Freak-DS for converting it to NFS4. 
All I needed was to waste my time converting it, Zmodeler 1.07b keeps crashing...
They really need to make a Zmodeler2 filter for Re-Volt.

================================================================
Copyright / Permissions
================================================================
Authors MAY NOT (I guess) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.
Any way you can't really repaint it (except for the color).

================================================================
Where to get this CAR
Websites: http://www.freewebs.com/adamodell (no plans to release this to RVZT as of yet)

