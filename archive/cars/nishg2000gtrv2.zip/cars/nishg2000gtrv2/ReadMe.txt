================================================================
Car Information
================================================================
Car Name  : Sky(line) HG2000GT-R v2
Car Type  : Conversion\Repaint
Folder	  : ...\cars\nishg2000gtrv2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 39 mph I think...
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell (stillz updated)

================================================================
Car Description
================================================================
Conversion of Ryuji KAINOH's HG2000GT-R Skyline.
It now has wheels from my S351 conversion. It is now RV-DBLSD'd, RV-Centered, and just more awesome all around. Didn't change the color because no other color would look better than white on this car IMO. Free for repaints.

================================================================
Construction
================================================================
Base           : NFS4 model (Ryuji Kainoh) converted by me
Poly Count     : With the new wheels, maybe 3000
               : 
Editor(s) used : Paint.NET and PSP 10.03, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : Absolutely none, all is good.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji and scloink (for his wheels), but here's other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Corel for PSP 10.03
Manmountain for maintaining RVZT, w/ arto. Hope it will be back up soon.

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: No f-bombs for you. Just choose what you want.

================================================================
Where to get this CAR
Websites: RVZT (hopefully it is back up, soon) and my site
