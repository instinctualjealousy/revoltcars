================================================================
Car Information
================================================================
Car Name  : Mercury Cougar (Version 2)
Car Type  : Conversion
Folder	  : ...\cars\merccougarv2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 43ish mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.byethost14.com (just as old as ever!)

================================================================
Car Description
================================================================
Addition: 
Multiple colors a la Puma and Diablo. Fixed mirrors, un-doublesided. 0,0,0 body offset and hulscaled hul. New wheels. Enjoy. Also some well-tweaked params that are much better than the original car.

Original:
Ryuji Kainoh's Cougar is made available to Re-Volt by me. Enjoy it.

================================================================
Construction
================================================================
Base           : Original NFS4 model by Ryuji Kainoh
Poly Count     : You really shouldn't care...
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : Well since I said there were none on version 2, I better shut up now.
================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: I've finally figured out custom colors, so Aeon is not required! :p

================================================================
Where to get this CAR
Websites: Re-Volt Zone Tracks and my new site
