@echo off
copy Racing.txt Parameters.txt