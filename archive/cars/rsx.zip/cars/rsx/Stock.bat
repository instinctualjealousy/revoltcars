@echo off
copy Stock.txt Parameters.txt