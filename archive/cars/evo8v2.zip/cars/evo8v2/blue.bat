@echo off
copy blue.bmp car.bmp
copy blue.bmq car.bmq