@echo off
copy lightblue.bmp car.bmp
copy lightblue.bmq car.bmq