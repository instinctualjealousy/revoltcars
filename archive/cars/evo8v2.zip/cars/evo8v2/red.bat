@echo off
copy red.bmp car.bmp
copy red.bmq car.bmq