@echo off
copy yellow.bmp car.bmp
copy yellow.bmq car.bmq