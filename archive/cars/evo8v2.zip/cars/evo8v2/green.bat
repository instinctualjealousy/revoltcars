@echo off
copy green.bmp car.bmp
copy green.bmq car.bmq