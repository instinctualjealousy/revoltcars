@echo off
copy silver.bmp car.bmp
copy silver.bmq car.bmq