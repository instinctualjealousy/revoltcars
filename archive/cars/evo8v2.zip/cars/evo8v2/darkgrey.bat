@echo off
copy darkgrey.bmp car.bmp
copy darkgrey.bmq car.bmq