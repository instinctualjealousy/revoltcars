@echo off
copy purple.bmp car.bmp
copy purple.bmq car.bmq