@echo off
copy tangrey.bmp car.bmp
copy tangrey.bmq car.bmq