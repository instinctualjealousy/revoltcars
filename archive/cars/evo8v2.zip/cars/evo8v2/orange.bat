@echo off
copy orange.bmp car.bmp
copy orange.bmq car.bmq