@echo off
copy black.bmp car.bmp
copy black.bmq car.bmq