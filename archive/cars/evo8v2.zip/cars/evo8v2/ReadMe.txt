================================================================
Car Information
================================================================
Car Name  : Evolution NFSU2 (v2)
Car Type  : Conversion
Folder	  : ...\cars\evo8v2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Changed to 42 (originally 39) mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (updatez out the azz)

================================================================
Car Description
================================================================
This is a conversion of Owl's Evolution from NFSU2, converted by him for NFS4 (had to use the less
detailed model specifically for that game that he didn't want converted to ANY game) to convert to Re-Volt. But it is still too detailed for some people's computers to handle. I have a Geforce4 MX440 and it slows the game down to roughly 30 to 50 fps. Not too much of a performance hit for me :)

Added: Fixed centering of car (RVCenter), more colors (Tan Grey, Brown Sugar, Green, Dark Grey), change color with the .bat files, all in one folder.
Fixed it up to celebrate my first conversion.
Not fixed: the pureblack spots on the driver, too many colors too fix this with.

================================================================
Construction
================================================================
Base           : NFSU2 model converted to NFS4 by owl converted to Re-Volt by me
Poly Count     : Roughly 9000 polys
               : Don't even want to know...
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : None, but it has the tendency to flip over sometimes... Tapping the steering can help.
And it takes 5 seconds to load out of the white rc box for me. (you can just skip that anyway).

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Owl. All I needed was to waste my time converting it, Zmodeler 1.07b keeps crashing...
They really need to make a Zmodeler2 filter for Re-Volt.
Fixed up September 21st, 2007, originally made in early August.

================================================================
Copyright / Permissions
================================================================
Authors MAY NOT use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.
Any way you can't really repaint it (except for the color).

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://www.freewebs.com/adamodell
