@echo off
copy brownsugar.bmp car.bmp
copy brownsugar.bmq car.bmq