================================================================
Car Information
================================================================
Car Name  : Nissan S14 Drift
Car Type  : Repaint
Folder	  : ...\cars\sildrft
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 46 mph (probably higher now...)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/

================================================================
Car Description
================================================================
Me and Me's Description: Some call it Silvia, some call it S14, some call it 240SX, some
call it 200SX, some call it Kouki... One things for shizzle,
it's a Nissan. And it's pretty flippin nice, better than the S15
thats what it is. So here you go have some fun. We tried to do a
chameleon like paintjob looks quite good. Params are capable of
quite a lot, beaten our ReadMe time for El Dorado with them.
Have fun!

================================================================
Construction
================================================================
Base           : NFS4 custom model by Ryuji Kainoh
Poly Count     : 759 polies for the body
               : 150 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
incogbla:
For Touge Run 1, the real deal for this kinda car. Pretty hard
to get a decent shot on tho, but the result is good. Thanks!

scloink:
Damn, this is again a car that uses scloink's wheels. They look
great even if they have been used for a thousand times. Dunno
what to say, blabla. Thanks!

Ryuji Kainoh:
For this great looking model, which is very realistic and cool.
We were lost without him producing all these cars, and we're
lucky that he does 'em. Thanks!

The Me and Me:
For building this car from all these great people.

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars,
provided you give proper credit to the creators of the parts
from this car that were used to built the new car. E.g. if
you use the wheel models give credit to the creators and/or
converters. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
