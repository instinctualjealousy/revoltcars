================================================================
Car Information
================================================================
Car Name  : Calsonic Skyline GT
Car Type  : repaint
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 47mh
Rating    : Pro

================================================================
Author Information
================================================================
By AlexFogliani
and Adamodell

================================================================
Thanks And Accolades
================================================================
Adamodell to have converted this car;
RVZT where you can get this car
and me for the texture

09/12/11