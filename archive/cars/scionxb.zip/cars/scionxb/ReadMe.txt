================================================================
Car Information
================================================================
Car Name  : Scion xB (long delayed)
Car Type  : Conversion (with some fixed stuff)
Folder	  : ...\cars\scionxb
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 40-44 depending on how good you are
Rating    : Pro (but almost too slow for this rating)

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
I believe this is my first front-wheel drive car. Yes, it is front-wheel drive. The parameters are a cross between me and Aeon, about 70/30. The normals aren't that great, I used projection normals on it because calculated normals didn't look smooth. I think this is because of the fact that I deleted half of the exterior of the car AND mirrored it, reoriented it, and just messed up the normal calculation. I fixed the mirror lengths to something even, this is the car that I came up with the "Ryuji Kainoh mirrors" to release, so people can now add mirrors to cars that don't have mirrors (might require resizing/stretching), or delete the stock mirror polies on Ryuji cars where the mirrors make the car off center (Check S351, Cougar, and Puma, which all currently have this problem).

It is dedicated to my brother's love of this car. Uses my new wheels. It just needs to be in black now. Crap, I'll re-do this car sometime, but it needs released.

================================================================
Construction
================================================================
Base           : Toyota bB mesh from Ryuji Kainoh
Poly Count     : I don't know, I don't care, you shouldn't either. It's 2008, and it's a car courtesy of Kainoh, 'nuff said
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b
Known Bugs     : Miniscule to nothing. Some normals glitches (that's ENV if you're a 'tard), but that is Kainoh's fault for making me have to fix the car to begin with
================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

Thanks to the community for the enthusiasm that I need to continue.
Thanks to Aeon for constructive criticism, and joining my forum
Thanks to Manmountain for "just being there"
Thanks to RST for what-else am I forgetting and not banning me twice :) <--Instead, quit
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to RST in giving me permission to post my GT2 to RV tutorial elsewhere (but I won't until it is done) <--I just broke that one
Thanks to Oleg for the relatively easy UV mapper in ZModeler

================================================================
Individual Thanks On This Car
================================================================
Thanks to The Me and Me for their racekit (which I stretched and mapped into submission on this car)
Car made by Ryuji Kainoh
Myself for the wheels (wheel textures Polyphony Digital)
Thanks to Oleg for ZModeler
Rick Brewster for the awesomeness that is Paint.NET

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
