@echo off
copy carpink.bmp car.bmp