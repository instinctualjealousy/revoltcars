@echo off
copy carblack.bmp car.bmp