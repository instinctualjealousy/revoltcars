@echo off
copy carimolaorangepearl.bmp car.bmp