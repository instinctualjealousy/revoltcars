================================================================
Car Information
================================================================
Car Name  : Ford Puma v2
Car Type  : Conversion
Folder	  : ...\cars\pumav2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : ...39! ha!
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (and Aeon somewhat)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (newly updated again as of Dec. 23rd)

================================================================
Car Description
================================================================
Conversion of Ryuji Kainoh's Ford Puma with Krystoff's wheel models, but used a modified version of Ryuji's wheel textures, Custom Paintjobs.psp by Aeon, I was going to use Aeon's custom colors, but I have my own rim design, so I had to make my own colors or edit every single color :P I edited the PSP file for my new rims, otherwise credit to Aeon.

================================================================
Construction
================================================================
Base           : NFS4 model (Ryuji Kainoh) converted by me
Poly Count     : quite low...
               : 
Editor(s) used : Paint.NET, RV Minis 5, Chaos Tools, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) ntdll.dll!!?!?!
Known Bugs     : Clear mirrors fixed with rv-dblsd, so now they are the color of the car!
The car model itself is buggy though, I RV-Centered it (for sure) and it wasn't totally centered, so I changed the offset to 0.5 on the x axis.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
Aeon for PSP file...
Majority of credit goes to Ryuji Kainoh and Krystoff, but here is other thanks:
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools
Anyone else I'm forgetting....

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: DIY with the Custom Paintjobs.psp
================================================================
Where to get this CAR
Websites: RVZT and my site...

================================================================
How to use Custom Paintjobs.psp (note: this is done with PSP 10.03)
================================================================
1. Open it with Paint Shop Pro
2. Select the "Paint Job" layer
3. Goto Adjust--> Colors--> Red/Green/Blue
4. Filter it through a color you'd like that I haven't made...
5. Click OK
6. Save it as BMP, make sure both layers have "Visibility Toggle" ON!
7. Preferably name it "car*.bmp" (*=being the color of the car)
8. Make a batch file for it that reads (*=being the color of the car):
=========================================
@echo off
copy car*.bmp car.bmp
=========================================
   and save the batch file as *.bat (*=the color of the car)
9. This was probably the most picky OCD'd up tutorial thaT you have prolly seen in your life.
   But it might help it get through your thick skulls....
10. If you are too idiotic to make it on your own, tell me approximately what color you want and I'll make it for you and e-mail it to you... :P