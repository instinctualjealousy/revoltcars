@echo off
copy carwhite.bmp car.bmp