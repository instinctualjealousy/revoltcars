@echo off
copy carbluegrey.bmp car.bmp