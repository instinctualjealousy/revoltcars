@echo off
copy carpeach.bmp car.bmp