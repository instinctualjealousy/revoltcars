@echo off
copy carpurple.bmp car.bmp