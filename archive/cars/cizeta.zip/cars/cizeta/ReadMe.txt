================================================================
Car Information
================================================================
Car Name  : Cizeta-Moroder V16T
Car Type  : Conversion
Folder	  : ...\cars\cizeta
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 43 mph or around that
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (updating my site again as of Dec 23rd, 07)

================================================================
Car Description
================================================================
Yet another conversion of a Ryuji car. Didn't care to put his readme in this one 'cause it is all the same anyway.
I made many textural edits to make the car look its best (its still grey though), but it is still out of proportion to the actual car (courtesy of Ryuji)
I made some custom wheel design on scloink's wheels (that are seen on many of TMAM's cars)
Also attempted to add a simplified version of the Cizeta logo on the front (it's really just a yellow box with a smaller black box inside)...

================================================================
Construction
================================================================
Base           : NFS4 model (Ryuji Kainoh) converted by me
Poly Count     : Methinks 2000ish with the fancy wheels
               : 
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : Absolutely none that I know of ATM. (as always) But I am prepared to fix something if the need arises.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.


The community feels dead right now, do your part and keep it alive!
Ok, its completely dead now!
But I'll still release stuff :P
================================================================
Individual Thanks On This Car
================================================================
All credit goes to Mr. Kainoh, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Corel for PSP 10.03
et cetera

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: uh, yeah.... It's repaintable at least
================================================================
Where to get this CAR
Websites: RVZT AND MY SITE BITCHES
