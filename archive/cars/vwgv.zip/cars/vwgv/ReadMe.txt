Turn word wrap on if you're sick of scrolling.

================================================================
Car Information
================================================================
Car Name  : Volkswagen Golf "Variant"
Car Type  : Conversion
Folder	  : ...\cars\vwgv
Install   : Dump this car's folder into cars. That or, do the RVZT way, drag cars into "Re-Volt"
Top speed : 39 mph
Rating    : Professional

================================================================
Car Description
================================================================
Skarma's PoV: Yo yo yo, whats up fools? Look what we have today, a Golf estate! You never seen one before? Really? Well guess what... I dont care! Because I've brought one to Re-Volt for you all! Not really much to say here, top speed is almost identical to Humma's (just a tad slower). I had fun playing with the springs on cars since I released the Brabus so hopefully this one hopefully feels like a nice relaxing drive for you all. Have fun! THANK YOU N' GOOD NIGHT.

Adam's PoV: A decent little car oddly comparable to the Stagea- I helped Skarma get along with it in its final moments. Did the colored bitmaps, carbox, wheel offsetting and general tooly junk. It's worthwhile, but really I probably  made it too much my own. I left Skarma's params basically intact though, so if you have any complaints, direct them at him! :3

================================================================
Construction
================================================================
Base           : NFS4 model by Ladis
Editor(s) used : Paint.NET, ZModeler 1.07b, RV Minis 5, prm2hul, Car::Load, RV-Sizer
Known bugs     : The rear wheels cut into the interior rear seat a bit. Not noticeable in most situations, but notable- and not really fixable, it's just the way the car's made- you'd either have to offset the wheels horribly to prevent it or redo the interior completely.

================================================================
You've seen it before... thank you all!
================================================================
DSL_Tile for keeping the Re-Volt love strong
Ladis for this model
Jigebren and KDL for making my job much easier (prm2hul/Car::Load)
Chris Elston for being Adam's bestest friend
Skarma for being one of Adam's good Re-Volt buddies
MOH for being cool
Rick Brewster: for being sponsored by Microsoft and somehow not sucking (I <3 PDN)
Oleg M. for ZModeler 1.07b

================================================================
Copyright
================================================================
Do what you wish with this car, I ain't gonna be your personal nanny. Ryuji won't be, either. He's lenient and so am I. What kills communities like this is "rights" and the "mine mine mine" attitude of creators. Most of Re-Volt community understands this, and is pretty lax, thankfully. Let's keep the laxness up, it is what makes this community better than... that other game's community! While I think it is right to state who did what, people deserve credit after all... it isn't right to treat your stuff like a horny dominatrix. Let stuff be free.:)

================================================================
Oh car, where art thou?
================================================================
RVZT, potentially other places.