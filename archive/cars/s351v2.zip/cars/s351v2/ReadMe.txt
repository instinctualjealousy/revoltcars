================================================================
Car Information
================================================================
Car Name  : Saleen S351 v2
Car Type  : Conversion
Folder	  : ...\cars\s351v2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 43 or so mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.byethost14.com (just as old as ever!)

================================================================
Car Description
================================================================
Addition: Removed doublesiding cuz I hate it (but you can see through the car at certain angles), fixed the mirror-length problem by using a different set, made the parameters a tad more unique, custom colors (make your own too, if you download at my site), new wheels, and not much else. Fixed the mapping of the mirrors as well.

Original: Ryuji Kainoh's S351 is made available to Re-Volt by me. Enjoy it.
I had to set the body offset to the right by 0.45 because the car model has a longer mirror on the right than on the left, so RVCenter made the car centered incorrectly based on the mirror's positions. But it actually is centered, it was just Ryuji's unsymmetrical mirrors that did it.

I decided to do a Canary Yellow Mustang out of this.
No bmq because the car was doublesided, it can make textures really low quality and low res on parts that need accurate pureblack areas.
================================================================
Construction
================================================================
Base           : Original NFS4 model by Ryuji Kainoh
Poly Count     : You really shouldn't care...
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : The only bug is the bug that occurs with Ryuji cars when you remove doublesiding, i.e. the car being see-through on the other side. But Ryuji designed his cars this way and doublesiding doesn't necessarily make it look better anyway.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools

================================================================
Copyright / Permissions
================================================================
Authors MAY possibly (I guess) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint it suckas! Especially you Aeon :P

================================================================
Where to get this CAR
Websites: RVZT and ma site!
