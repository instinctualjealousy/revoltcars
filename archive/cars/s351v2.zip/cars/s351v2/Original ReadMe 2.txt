================================================================
Car Information
================================================================
Car Name  : Saleen S351
Car Type  : Conversion
Folder	  : ...\cars\s351
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 40ish mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (Ryuji Kainoh's model)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : NOW AT: http://fallingupward.net/adamodell

================================================================
Car Description
================================================================
Ryuji Kainoh's S351 is made available to Re-Volt by me. Enjoy it.
I had to set the body offset to the right by 0.45 because the car model has a longer mirror on the right than on the left, so RVCenter made the car centered incorrectly based on the mirror's positions. But it actually is centered, it was just Ryuji's unsymmetrical mirrors that did it.

I decided to do a Canary Yellow Mustang out of this.
No bmq because the car was doublesided, it can make textures really low quality and low res on parts that need accurate pureblack areas.
================================================================
Construction
================================================================
Base           : Original NFS4 model by Ryuji Kainoh
Poly Count     : You really shouldn't care...
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : None, all textures are as perfect as they can be to my knowledge.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh (model) and scloink (wheel mesh).
I don't really care to list everybody I thank this time, it's on all of my older readme's :P

================================================================
Copyright / Permissions
================================================================
Authors MAY possibly (I guess) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.
Repaint it suckas! Especially you Aeon :P

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
