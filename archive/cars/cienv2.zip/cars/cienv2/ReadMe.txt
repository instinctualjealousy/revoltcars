================================================================
Car Information
================================================================
Car Name  : Cadillac Cien v2
Car Type  : Conversion
Folder	  : ...\cars\cienv2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : ...not 39! 45 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell (newly updated again)

================================================================
Car Description
================================================================
Conversion of Bob Robert's Cadillac Cien model from 2002!
Fixed the brake pads to be pureblack on the edges, not a square no longer.
RV-Centered the body, and adjusted the wheels as such.
Adjusted the wheel radius so the wheels aren't sinking into the ground.


================================================================
Construction
================================================================
Base           : NFS4 model (Bob Robert) converted by me
Poly Count     : Unknown
               : 
Editor(s) used : Paint.NET, RV Minis 5, Chaos Tools, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) ntdll.dll!!?!?!
Known Bugs     : Absolutely none to what I know.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Bob Robert, but here is other thanks:
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: This car is supposed to be grey. What gives?

================================================================
Where to get this CAR
Websites: RVZT (when or if it is ever up) and my site...
