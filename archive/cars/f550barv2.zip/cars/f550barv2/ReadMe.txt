================================================================
Car Information
================================================================
Car Name  : F550 Barchetta v2
Car Type  : Conversion\Repaint
Folder	  : ...\cars\f550barv2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 39 mph I think...
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell (as always...)

================================================================
Car Description
================================================================
Conversion of EA's and Viper's Ferrari F550 Barchetta to Re-Volt!
Now fixed up, RV-Centered, blue-colored, etc. Also removed the shine due to the errors it was causing on this model. Thanks go out to The Me and Me for knowing how to do this. I'm sure you'll like HOW IT ISN'T GREY!!!!!!!

================================================================
Construction
================================================================
Base           : NFS6 model converted to NFS4 by Viper. Converted to Re-Volt by me.
Poly Count     : Like 6000 something... Can slow game down (turning off V-Sync can speed the game up 20 frames)
               : 
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : Absolutely none.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Viper (or EA), but here's other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Mammountain again, for being just awesome

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: Maybe some new colors?

================================================================
Where to get this CAR
Websites: RVZT and my site
