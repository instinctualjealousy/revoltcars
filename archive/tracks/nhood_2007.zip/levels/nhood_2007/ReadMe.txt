This track is by me, Adamodell
It is exactly the same as Toys in the Hood 1, except with better optimized (and better in general) textures.
ENJOY!

Credits to Acclaim for the original track and Rick Brewster for Paint.NET.
It comes with a replacement sky that you put in the nhood1 folder.
(make backups of the old original files)