This car is done in month August of year 2004,by VSO.

-Features:

-Completely 3d,every single thing is modeled by me.
-Realistic Performance.
-Dashboard view
-Non-locked viv
-No damage
-Vidwall
-9800 polygons in total(i love detail thats why it is high)
-An Upgrade

-Credits:

-Thanks to the guy who made the blueprint of this car,i really do not remember his name.
-Thanks a lot to Ike Chiemes for creating gr8 engine sounds and supporting me from heart.
-Thanks to NightEYE,A great friend,who allways helped me about finding textures,he gave me lots of useful ideas.I really respect to u N.E.
-To ANP,For those gr8 taillight pics.(I modified them a bit but..)
-To T-Shine:You motivated me a lot,you r a good person T.Thanks for seat blueprints and rim pics(i did not used his ones,but thanks again).
-To Spirit,Laury,Reilss,BMW760LI and other guys i did not remember:For your respects,and friendship!
-To Martin Leps:Lol,he is a good person and a gr8 modeler,i allways examine his models and try to learn about his tecnic,he is my master.I hope we can be friends with him.
-To Distinictive Chris:For not listening to my advices.
-To Sander Prinsen:For NFSCARS,and all its stuff.
-To Lamborghini A.G:For making such a nice car,for car colors. 

**Especially thanks to JAY,VIPER JAY5:Who allways supported&motivated me.Thanks a lot for helping me in every single thing,you helped me even if you were busy.Thanks a lot Jay,thanks a lot for not leaving us.**

*Feel free to edit this car,as viv is not locked.You can do whatever you want for your own use,but you cannot release it.