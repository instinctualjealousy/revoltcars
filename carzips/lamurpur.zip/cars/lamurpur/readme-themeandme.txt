================================================================
Car Information
================================================================
Car Name  : Lamborghini Murcielago
Car Type  : Conversion
Folder	  : ...\cars\lamur
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 46 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me
EMail       : saver@gmx.li
Homepage    : http://www.themeandme.de/

================================================================
Car Description
================================================================
The newest car by Lamborghini. And the first one that has been
developed after Lamborghini has been bought by Audi. And our RV
version is as good as the real one. It also has 4WD. The
handling's good, tho it may get tricky if you hit walls in the
wrong angle. Have fun!

================================================================
Construction
================================================================
Base           : NFS4 custom model by Ryuji Kainoh
Poly Count     : 1250 polies for the body
               : 150 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
scloink:
Damn, this is again a car that uses scloink's wheels. They look
great even if they have been used for a thousand times. Dunno
what to say, blabla. Thanks!

SMAG [ROMEO]:
For Oasis, a beautiful looking conversion of the Garden Battle
level, where we took the screenshot on. We thought it fits the
posh character of the car. Thanks!

Ryuji Kainoh:
For creating this wonderful lovely looking vehicle for NFS. It's
been out a couple of months now and we were worried if he'd make
it all. And he did. And how he did... Wow! Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/

