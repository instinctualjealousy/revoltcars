@echo off
copy violet.bmp car.bmp