@echo off
copy tan.bmp car.bmp