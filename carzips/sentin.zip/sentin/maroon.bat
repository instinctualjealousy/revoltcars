@echo off
copy maroon.bmp car.bmp