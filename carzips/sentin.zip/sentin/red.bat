@echo off
copy red.bmp car.bmp