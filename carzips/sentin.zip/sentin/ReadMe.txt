================================================================
Car Information
================================================================
Car Name  : GTA3 Sentinel
Car Type  : Conversion
Folder	  : ...\cars\sentin
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 40ish mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (Rockstar's and Power City Tuning Team's model)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : NOW AT: http://fallingupward.net/adamodell

================================================================
Car Description
================================================================
This is the AFTER release candidate version. Comes with two new colors, and edited old colors (Yellow is more yellow...)
Rockstar's Sentinel from Grand Theft Auto 3. I converted out of NFS4 for ease. Oddly enough, this car is only 2000 polies, WITH THE WHEELS!

Credit to Power City Tuning Team for converting the car to NFS4.
================================================================
Construction
================================================================
Base           : GTA3 model by Rockstar and Power City Tuning Team for NFS4 conversion
Poly Count     : You really shouldn't care... 2000 is a good estimation
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : The polies reflect correctly, so, none.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Rockstar (model) and Power City Tuning Team (converting to NFS4).
I don't really care to list everybody I thank this time, it's on all of my older readme's :P

================================================================
Copyright / Permissions
================================================================
Authors MAY NOT use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
