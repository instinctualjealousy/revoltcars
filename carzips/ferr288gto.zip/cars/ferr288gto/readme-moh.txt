Car information
================================================================
Car name                : Ferrari 288 GTO
Car Type  		: original
Top speed 		: 55
Rating/Class   		: Pro
Install folder       	: ...\cars\288gto
Description             : 288 GTO made by MOH

 
Author Information
================================================================
Author Name 		: MOH, Adamodell
Email Address           : carmadman@hotmail.com, metallicafan128@gmail.com (both MSN and email)
Misc. Author Info       : 
 
Construction
================================================================
Base           		: original
Poly Count     		: ? polies for the body
               		: ? polies for each wheel
Editor(s) used 		:  photoshop 7, zmodeler, rvshade, rvsizer, rvdblsd, paint.net (for wheels), hulscale
 
Additional Credits 
================================================================
Everyone whos still plays revolt for keeping the game alive
everyone on rvzt for keeping each other into revolt.
Adamodell for supplying parameters, wheels, better vertex normals for the body, hulscaled hul, and paint sheets
 
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars.  
You MAY distribute this CAR, provided you include this file, with no 
modifications.  You may distribute this file in any electronic format 
(BBS, Diskette, CD, etc) as long as you include this file intact.

 
Where else to get this CAR
================================================================
FTP sites		:
Website  		: RVZT
Other			:
