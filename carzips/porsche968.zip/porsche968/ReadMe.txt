================================================================
Car Information
================================================================
Car Name  : Porsche 968 CS
Car Type  : Conversion
Folder	  : ...\cars\porsche968
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Around 46 (tops out kinda funny, you'll be 44 most of the time)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (Since I like Opeth more, I should change that to "opethfan128@gmail.com")
Homepage    : http://adamodell.vndv.com

================================================================
Car Description
================================================================
Wasn't joking about "more Ryuji cars to come", infact, I'm going through all the cars that I like that The Me and Me just absolutely didn't see. Another car will come shortly, a Porsche 924 Carrera GT, parametered by DSL_Tile. This car should tide you over for now. Expect cars on the weekends when school isn't hogging my precious time, k?

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) RV-Sizer, and a couple others
Known Bugs     : Good luck finding them.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

This car is dedicated to Robenue, also now known as Kumachan, for his hard work in the latter half of last year. Thanks for all that chatting Luke, hope to see you release another car... I hate being without ya, man.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh for the main body mesh.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Myself for the wheels
Robenue for practically making me want to do another since he won't!! hahaha

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site, and probably a box.net link on RRR