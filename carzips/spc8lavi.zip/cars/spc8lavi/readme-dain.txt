***********************************************************************
SPYKER C8 LAVIOLETTE FOR NEED FOR SPEED 3

Car: Spyker C8 Laviolette v1.0 (based on Aston Martin DB7) 
File: Slc8.zip (includes car.viv, car.fec, readme.txt, 09_00.qfs)
Release date: October 2001 
Author : DaiN
E-mail: danielmodena@hotmail.com

Used editors 	: VIV Wizard v0.8 by Jesper Juul-Mortensen
                     	: NFSIII Car CAD v1.4b by Chris Barnard
               	: PaintShop Pro 5J

Installation:
 1. Go to the main NFS folder (The one wich includes NFS3.EXE).
 2. Go to the subfolder called GameData\CarModel.
 3. In there, make a new folder called 'Slc8'.
 4. Put the included files from this ZIP-file in there.
 5. Play NFS III and have fun!

Slide:
This car comes with a slide, but it's not necessary to install it. 
Also, you can only install the slide if you have the full installation 
of NFS. For the ones who don't know what a slide is, it's
the picture of the car you'll get when you load a race. Here's how to
install:
 1. Go to the main NFS folder (The one wich includes NFS3.EXE).
 2. Go to the subfolder called FeData\Art\Slides.
 3. Put the 09_00.QFS from this ZIP-file in there.
 4. Play NFS III and have fun! 

Permissions:
You can modify this car, but ONLY when you ask me 
and if I'm credited for it in the readme file!
If unchanged, this car can be distributed FREELY.
If you use this car for your own website, please be so nice and tell me where it is.

