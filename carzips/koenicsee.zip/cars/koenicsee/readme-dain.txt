***********************************************************************
THE  KOENIGSEGG CC FOR NEED FOR SPEED 3

Car: Koenigsegg CC (v2.0)
File: Koen.zip
Release date: August 2001 
Author : DaiN
E-mail: danielmodena@hotmail.com

Used editors 	: VIV Wizard v0.8 by Jesper Juul-Mortensen
                     	: NFSIII Car CAD v1.4b by Chris Barnard
               	: PaintShop Pro 5J

Installation:
 1. Go to the main NFS folder (The one wich includes NFS3.EXE).
 2. Go to the subfolder called GameData\CarModel.
 3. In there, make a new folder called 'Koen'.
 4. Put the included files from this ZIP-file in there.
 5. Play NFS III and have fun!

