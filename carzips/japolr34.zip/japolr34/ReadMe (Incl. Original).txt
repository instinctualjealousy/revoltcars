Turn word wrap on if you're sick of scrolling.

================================================================
Original ReadMe
================================================================
Pursuit Skyline GT-R V.spec for Need for speed IV

Title          : Pursuit Skyline GT-R V.spec
Car            : Pursuit Skyline GT-R V.spec[SAITAMA Prefectural Police version] (SN:46)
File           : P34r.zip
Version        : 1.0 (Upgrade Feature : NO)
Date           : DEC 2002

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : NFS Wizard v0.5.0.79 by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 297) by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 299) by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : NFS Car CAD v1.5b by Chris Barnard
               : CAR3TO4 by J�Eg Billeter
               : NFS FCEConverter by Addict&Rocket
               : PaintShop Pro 5J

================================================================
Car Information
================================================================
Creator	  : Ryuji Kainoh
Converter : Adamodell (Adam O'Dell)
Car Name  : Pursuit Skyline JP
Car Type  : Conversion
Folder	  : ...\cars\japolr34
Top speed : 40 mph
Rating    : Pro
Bugs      : AI might be rough, as it was a patchup job at best. Otherwise, I know of nothing.

================================================================
Editors Used
================================================================
ZModeler 1.06f
Car::Load
Paint.NET
Kay's "PRM" tool
Autoshade
rvshade
prm2hul
Lithium Unwrapper
Re-Volt Textures Resizer
Photoshop CS4 (For saving RLE 8-bit bitmaps that Re-Volt didn't hate)
PNG to 32-bit BMP for saving my 32-bit bmps for Re-Volt
BMP2PNG with -a flag if I had to do just the reverse

================================================================
You've seen it before... thank you all!
================================================================
Citywalker for the Car AI tutorial lest she forget
Skarma for a couple Re-Volt 1.2 tips and basically the car's params (but I made tweaks)
zipperrulez for a little bit of testing
Jigebren and KDL for making my job much easier with all their fresh tools
Oleg M. for ZModeler 1.06f (it runs a little less worse than 1.07b on Win7, but- hard to find)

And as an extra thanks- for making the recreation of my site possible:
RVZT, and the people who helped it exist throughout this time
Cat, for having a couple of my files backed up
Box.net, for me having some of my car installers uploaded to it
Mediafire, for having other slim pickins uploaded to it

================================================================
Copyright
================================================================
I don't care. Does Ryuji? Maybe. I wouldn't know.

================================================================
Oh car, where art thou?
================================================================
My new site is http://adamodell.co.cc/
Another URL for it is http://adamodell.vndv.com/, revived.
http://adamodell.web44.net is gone.
There's always RVZT as well.