================================================================
Car Information
================================================================
Car Name  : '67 Shelby GT500 Eleanor
Car Type  : Conversion
Folder	  : ...\cars\shelgt
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 40ish mph if you're lucky to get it to reach those speeds...
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (Alberto Daniel Russo's model)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : NOW AT: http://fallingupward.net/adamodell

================================================================
Car Description
================================================================
Car by Alberto Daniel Russo, and excellent car model to say the least. I sent a picture of it to him, but he'll probably never receive it.
Edit Feb. 9th, 2016: Replaced those stupid executables with the batch we know and love.

================================================================
Construction
================================================================
Base           : NFS4 car by Alberto Daniel Russo
Poly Count     : You really shouldn't care... 5000 is a good estimation
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : The polies reflect correctly,

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Alberto Daniel Russo, for the whole car.
I don't really care to list everybody I thank this time, it's on all of my older readme's :P

================================================================
Copyright / Permissions
================================================================
Authors MAY NOT (hmm, maybe you can if you're nice) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net (without PNGs)
          http://fallingupward.net/adamodell