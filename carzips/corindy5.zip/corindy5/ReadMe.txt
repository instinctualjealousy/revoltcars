================================================================
Car Information
================================================================
Car Name  : Corvette Indy 500 Pace Car
Car Type  : Conversion
Folder	  : ...\cars\corindy5
Install   : Unzip with folder names on to the main Re-Volt folder or install with my crazy installer
Top speed : A bit slower, at the rough estimate of mid-40's
Rating    : Pro-fessional

================================================================
Author Information
================================================================
Author Name 	: Adamodell
EMail and MSN	: metallicafan128@gmail.com (Find me on MSN!! I wanna talk! Well, maybe not...)
Homepage    	: http://adamodell.vndv.com

================================================================
Car Description
================================================================
I wanted to do an extremely minimalist conversion with one texture sheet, the original wheels, and within the least amount of space possible. This car is a rarity in the files of NFS3, but it's an official EA car. This is why there is no original ReadMe. I found the release on NFSCars, so thanks to whoever uploaded it (I forgot and cannot be bothered to look further...). All files were converted, I didn't use TheMeandMe's NFS3 Corvette conversion as a base. Then it'd be lame and lazy. And lame and lazy aren't cool. That's about as bad as "false and homosexual".

================================================================
Construction
================================================================
Base           : NFS3 model by EA themselves
Poly Count     : Dude, get with the times!
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b (doesn't crash much on Vista amazingly), Chaos Tools, hulscale (the latter two I had to run on a 32-bit XP virtual machine... I have a 64-bit system now)
Known Bugs     : I'm a perfectionist. Don't point out errors or I might OCD on them.

================================================================
KTHXHAI
================================================================
Well, I lost my girlfriend, but I got over that. Haha. Stupid teenage romance never works. That's what... THE FUTURE! is for. Oh yeah, I'm totally bi....polar. Well, sorry I have to be a failure at humor now, but it's better than being a xenophobic self-centered freak. Oh wait, that's exactly what I am. Well... thanks to everyone for not sucking too bad and thanks to human for making the best track for Re-Volt since Gabor was around.

================================================================
You've seen it before... thank you all!
================================================================
Rarity skin for the Corvette by EA
The Me and Me as my main influence and drive to convert (doubt it)
Aeon, for not sucking
Rick Brewster: for being sponsored by Microsoft and somehow not sucking (Thanks for PDN)
Oleg M. for ZModeler 1.07b, but no thanks for terrible NT compatibility
The Re-Volt Communion for being the epitome of mediocrity (waits for societal outrage)
Manmountain for not sucking too hard *kids* Aww man, you don't suck, don't worry
NO THANKS TO PEOPLE WHO DEVELOP PROGRAMS LIKE IN LIKE 16-BIT LIKE YA KNOW?
GIT WIT DA TIMES HOMIE.

In the words of one of my favorite friends:
Danku. :3
if you have no clue what I just said, you don't deserve to live.
*Snaaake eyyyyyes*

================================================================
Copyleft
================================================================
Screw copyrights. You can use this car as your personal "toy" if you see fit. But... you have problems if you do that. You can advertise it to cure squirrel AIDS too. Just, I want a cut of the money. Just remember, squirrel aids is some serious sh*t.

================================================================
Oh car, where art thou?
================================================================
Websites:
http://adamodell.vndv.com
http://rvzt.net