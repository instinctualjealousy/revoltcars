================================================================
Car Information
================================================================
Car Name  : Volkswagen W12 Coup� v2
Car Type  : Conversion
Folder	  : ...\cars\w12coupev2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : A few mph faster than before
Rating    : Pro

================================================================
Author Information
================================================================
Author Name 	: Adamodell
EMail and MSN	: metallicafan128@gmail.com
Homepage    	: http://adamodell.vndv.com

================================================================
Car Description
================================================================
I might update the other NFS3 conversions as well...

================================================================
Construction
================================================================
Base           : NFS3 model by DaiN
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, Paint Shop Pro 9, Chaos Tools, RV Minis, hulscale, and something else I'm surely forgetting
Known Bugs     : Maybe a month from now I'll discover one.

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
http://adamodell.vndv.com and http://revolt.speedweek.net/main