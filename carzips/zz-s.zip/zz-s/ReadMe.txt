================================================================
Car Information
================================================================
Car Name  : Tommy Kaira ZZ-S
Car Type  : Conversion
Folder	  : ...\cars\zz-s
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Around 45 for both sets of params
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.byethost14.com (just as old as ever!)

================================================================
Car Description
================================================================
Converted for Prestonfs and his brother. Was delayed because of Robenue's set of params. I tweaked his params enough that they are practically mine. Both sets have wild flaws on certain types of tracks, but combined there might be enough variety to aid this. Removed the shine from the rear cover, cuz it looks cool that way. Very similar conversion from the two ZZ's that preceded it.

================================================================
Construction
================================================================
Base           : Tommy Kaira ZZ-S by Polyphony Digital
Poly Count     : Not much
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, Chaos Tools (keep forgetting to mention Chaos), LithUnrap, FCE Finish to fix the normals (an NFS program)
Known Bugs     : Remapped conflicting mappings, so nothing really glitchy about that. It's as close to perfect as I can get it with my limited mapping skills.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldn't be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

A long thanks list:
Thanks to the community for the enthusiasm that I need to continue
Thanks to Aeon for constructive criticism
Thanks to Manmountain for "just being there"
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to someone I don't know for Lithium Unwrapper
Thanks to zipperrulez for waiting

================================================================
Individual Thanks On This Car
================================================================
Car made by Polyphony Digital
Myself for the wheels (wheel textures from GT2)
Thanks to Polyphony Digital for their high-detail low-poly models
Thanks to Oleg for ZModeler and specifically the c?o importer
Rick Brewster for the awesomeness that is Paint.NET *very good for fancy pics, and texture sheets alike*

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site, and most likely elsewhere