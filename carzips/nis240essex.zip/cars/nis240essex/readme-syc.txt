Car:
-----------
Nissan 240sx tuned


Author:
-----------
SYC Motors

This is a 1994 Nissan 240sx

It has:
- 3d lights
- Apathy's Mags
- Savidge's shifter
- Low poly hi detail 240sx frame I made from EA's FM50.

Thanks to 
Savidge for the shifter :) , Apathy for the Mags.

