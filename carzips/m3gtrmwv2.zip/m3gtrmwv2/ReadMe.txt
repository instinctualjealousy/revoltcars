================================================================
Car Information
================================================================
Car Name  : BMW M3-GTR v2 (from Most Wanted)
Car Type  : Conversion
Folder	  : ...\cars\mwm3gtrv2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 42ish mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (StYLiZeR's model)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
This car is quite a performance hit on DINO PC's :)
4000 something polies for the body and 1098 polies for EACH wheel
So come prepared

The car was converted to Need for Speed 4 by StYLiZeR (that's how it's spelled right?)
We all know how easy it is to convert from NFS4 to Re-Volt, so yeah

Changes:
Fixed the light tranparency problem, deleted all window and light polygons. Kept ENV due to minimal errors. Also deleted the front brake disks. Thought about merging them to the front wheels, but the brake discs are very obviously rotating.

Other small UV mapping tweaks that aren't worth mentioning.... (like part of the front wheel wells)

and:
Fixed some of StYLiZeR's errors, also, like, a badly mapped polygon on the right mirror, that was black instead of white. Also deleted a square on the back of the car that was mapped to a unlogical texture (the grill and the M3 logo were mapped to it, check out version 1's back really close up to see), most likely what was supposed to use the M3 logo on the texture.

Upped the wheel radius so the wheels aren't sinking as much, and all is in check.

Comes with both of the repaints (Red and Black/Blue and Grey). Also now comes in flat black. Repaint of this car removed from repaints section! Now included with this car only.

No pureblack areas, anymore, in places they shouldn't be, either.

God, that's  a lot...
Oh, one more thing. I remapped the wheels, too. Look at the redblack.bmp, and you'll see a black square and a grey square a few pixels from eachother. That is the new mapping right there. The other cars just have white wheels, so they aren't the best examples of the new mapping.

Because of the new wheel mapping, there won't be any conflicts with the body. You can now recolor the rims without the front bumper showing that color on the edges. Blue and Grey version had this error (on the old repaint), now it is fixed.
================================================================
Construction
================================================================
Base           : Originally a Most Wanted model converted to NFS4 by StYLiZeR, converted by me
Poly Count     : 4867 polies for the body, 1098 polies for each wheel (come prepared)
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : Almost all errors were fixed in this release

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to EA and StYLiZeR. All I needed was to waste my time converting it, Zmodeler 1.07b keeps crashing...
They really need to make a Zmodeler2 filter for Re-Volt.

================================================================
Copyright / Permissions
================================================================
Authors MAY NOT (I guess) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.
Any way you can't really repaint it (except for the color).

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
