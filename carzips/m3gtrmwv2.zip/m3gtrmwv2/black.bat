copy black.bmp car.bmp
pause