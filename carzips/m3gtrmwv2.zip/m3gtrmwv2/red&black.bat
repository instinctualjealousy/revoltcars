copy redblack.bmp car.bmp
pause