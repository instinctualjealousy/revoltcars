copy NFSMW.bmp car.bmp
pause