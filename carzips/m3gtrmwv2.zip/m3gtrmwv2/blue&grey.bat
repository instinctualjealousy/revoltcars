copy bluegrey.bmp car.bmp
pause