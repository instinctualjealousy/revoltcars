================================================================
Car Information
================================================================
Car Name  : Zexel Skyline '97
Car Type  : Conversion
Folder	  : ...\cars\zexelsky
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Around 50
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.vndv.com

================================================================
Car Description
================================================================
The majority of this car's textures are actually straight from GT2's texture sheet, although the front and rear textures were printscreened. I modified the side textures quite a bit and simplified them, some things may be missing. It has proper left and right sides.

The bottom of the car was remodeled by MOH so now the car has proper wheel wells.

The wheels are completely remapped and look better now, than the ones on previous cars.

================================================================
Construction
================================================================
Base           : Zexel Skyline '97
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) RV-Sizer, and a couple others
Known Bugs     : My most seamless UV mapping almost ever.. I don't think there are any bugs.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
MOH for remodeling the bottom of this car to Re-Volt standards
Polyphony Digital for the body mesh
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Myself for the wheels

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site, and probably RRR
