================================================================
Car Information
================================================================
Car Name  : Nissan Silvia S15
Car Type  : Conversion\Repaint
Folder	  : ...\cars\nissil15 and nissil15tuner
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 47ish mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (Ryuji Kainoh's model)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (not updated anymore, all uploads to RVZT)

================================================================
Car Description
================================================================
Ryuji Kainoh's Silvia S15. This is my most "Me and Me"-ish conversion yet. I used scloink's wheel mesh this time, and used the original wheel texture design so I came up with something moderately original :P
Oh, and did I tell you that I repainted it too?
================================================================
Construction
================================================================
Base           : Originally and NFS4 model by Ryuji Kainoh
Poly Count     : You really shouldn't care...
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : None, all textures are as perfect as they can be to my knowledge.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh (model) and scloink (wheel mesh).
I don't really care to list everybody I thank this time, it's on all of my older readme's :P

================================================================
Copyright / Permissions
================================================================
Authors MAY possibly (I guess) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.
Repaint it suckas! Especially you Aeon :P

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          my site not updated no more... AGAIN!
