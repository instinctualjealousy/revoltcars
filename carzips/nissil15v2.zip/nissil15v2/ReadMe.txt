================================================================
Car Information
================================================================
Car Name  : Nissan Silvia S15 v2
Car Type  : Conversion/Repaint
Folder	  : ...\cars\nissil15v2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 47ish mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.byethost14.com (just as old as ever!)

================================================================
Car Description
================================================================
Addition: My new wheel mesh, un-doublesided, hulscaled and perfectly centered, color making sheets on my site only, a couple param tweaks, and fixed mirror mapping. Pretty much all of what Aeon did on his repaint version but I did it myself. Also comes with an enhanced remake of the included repaint of the last version.

Original: Ryuji Kainoh's Silvia S15. This is my most "Me and Me"-ish conversion yet. I used scloink's wheel mesh this time, and used the original wheel texture design so I came up with something moderately original :P
Oh, and did I tell you that I repainted it too?


================================================================
Construction
================================================================
Base           : Originally an NFS4 model by Ryuji Kainoh
Poly Count     : You really shouldn't care...
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : Not doublesided, that's all

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools

================================================================
Copyright / Permissions
================================================================
Authors MAY possibly (I guess) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: Re-Volt Zone Tracks and my new site

