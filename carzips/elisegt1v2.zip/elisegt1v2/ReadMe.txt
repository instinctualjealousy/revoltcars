================================================================
Car Information
================================================================
Car Name  : Elise GT1 from GT2 v2
Car Type  : Conversion\Repaint
Folder	  : ...\cars\elisegt1v2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Around 40
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.byethost14.com (just as old as ever!)

================================================================
Car Description
================================================================
Addition: A different texture for the rear, a color-creating sheet at my site, comes in black (or white, reminds one of GT4), new wheels, wheel texture from GT2, and whatnot. Rear window is now visible, and textures were edited slightly. Still not the GT2 textures though. All next GT2 conversions will use the real textures. Body is centered correctly and sports a hulscaled hul.

Original: I now present, the first ever conversion from Polyphony's giant, Gran Turismo 2.
It was impossible for me to get the original textures, so I got my own. I used Paint.NET thoroughly for this. It uses newer Elise textures, unlike the original car. I also added some GT2 insignias and such. I tried to make it look somewhat like it did in GT2. The whole car had to be re-UV mapped because the GT2 importer in ZMod doesn't import UV mapping. This was VERY difficult for my limited skills. I tried to make the mapping as symmetrical as possible. I'm sure you'll like how I carbon-fibered up the spoiler and bumper parts.

I used a tool called GT2Vol to extract the files from GT2's .vol file on disc. The car was originally in the .cdo format, which is partially importable in ZModeler, sadly without the UV which most likely prevented anybody from attempting this.

So, the three biggest roadblocks in this conversion were complete UV mapping of the car, and the difficulty (or lack thereof) in getting the mesh from the disc, and the inability in getting the original car's texture from the disc. Also, I could not find mesh data for the wheels, so I just used mine.

I spiced the internet-found textures up with some of my own touches, such as the GT logo spanned out on the sides, and a carbon fiber spoiler with the the GT2 branding.

Oh, and just so you know, I UV MAPPED THIS WHOLE CAR! So don't be hatin' on this car, as it was more than my most difficult conversion.

================================================================
Construction
================================================================
Base           : Elise GT1 mesh from GT2
Poly Count     : 400-something for the body, 280 something for each wheel
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, GT2Vol, LithUnwrap
Known Bugs     : Was kinda lazy but I made the mapping more symmetrical and the hul is good

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.
Thanks to the community for the enthusiasm that I need to continue.

================================================================
Individual Thanks On This Car
================================================================
Car made by Polyphony Digital
Myself for the wheels
Thanks to Polyphony Digital for Gran Turismo 2
Thanks to Oleg for ZModeler and specifically the flawed GT2 importer
mkreations for GT2Vol (on this page: http://www.geocities.com/mkreations/files/)
Other people for their pics of the Elise
Rick Brewster for the awesomeness that is Paint.NET

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site
