By Kregspiel 
================NEED FOR SPEED 4: High Stakes======================

Date             : 1/02/04
Title            : Porsche 917K (Kurzheck or short-tail) 2.0
Type             : Edited car  
Used Editor(s)   : Nfswiz
                   CarCad 143
		   CarCad 1.5
		   Paint Shop Pro
                   Adobe photoshop
                   FCE finish
                   FCE tweak
                   Zmodeler 
                   Sonic foundry
Filename         : GP917.zip

Author           : Kregspiel
Email Address    : Make comments at the site if you would like a response!

			                     		
Installation     : create GP917 folder in EA\NFS4\\data\cars\ directory and extract car.viv from the zip /also may extract the PK22 qfs file to the NFS4\data\feart\vidwall 
                              
================================================================

Car name               : Gulf-Porsche 917 Kurzheck (short -tail)
New Textures           : about 90% new
New Performance        : Realistic (based on actual specs) Warning-other cars also more real!
                         Spent a lot of time here-these were all about power to weight ratio
                         and huge tyres. Also found another improvement for AI cars-now champion 
                         level will give you experts a good run.
New Dash               : Improved - Dont you spend most of your time IN THE CAR!     
New sound              : real 917 samples

Thanks to all those good people out there who were nice enuff to post their
tutorials and methods as well as programs to build cars.Thanks also to  
Peter Morgan for his excellent book"Porsche 917 -the winning formula".
Thanks also to Steve McQeen for his great movie "Lemans"!
  					   