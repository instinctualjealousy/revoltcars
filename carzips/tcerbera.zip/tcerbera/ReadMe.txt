================================================================
Car Information
================================================================
Car Name  : TVR Cerbera (from Test Drive 6)
Car Type  : Flat out no-holds barred conversion
Folder	  : ...\cars\tcerbera
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 42 and up depending on how long of a straight you have
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
My second TD6 conversion, but not necessarily the best of the two. Very sporty params remniscent of the DB7's with a little tweaking.

================================================================
Construction
================================================================
Base           : TVR Cerbera mesh from Test Drive 6
Poly Count     : Not many
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, Chaos Tools (keep forgetting to mention Chaos), LithUnwrap
Known Bugs     : Remapped conflicting mappings, so nothing really glitchy about that. Like all my TD6 conversions, the wheels will go through the mesh on turning, but this is the way the mesh was made and I don't feel like modifying it.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

A long thanks list:
Thanks to the community for the enthusiasm that I need to continue
Thanks to Aeon for constructive criticism
Thanks to Manmountain for "just being there"
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to someone I don't know for Lithium Unwrapper
Thanks to zipperrulez for waiting

================================================================
Individual Thanks On This Car
================================================================
Car made by the TD6 crew
Myself for the wheels (wheel textures TD6)
Thanks to Infogrames and who knows else for their TD6 demo
Thanks to Oleg for ZModeler and specifically the TD6 importer
Rick Brewster for the awesomeness that is Paint.NET *very good for fancy pics*

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell