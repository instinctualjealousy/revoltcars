Power City Tuning Team presents:
IDAHO FROM Grand Theft Auto 3
by Power City Tuning Team

INDEX:
(1) Cars Features
(2) The Authors
(3) Contact

CHAPTER #1

This car is a convertion from GTA3 an it features realistic damages and realistic tuning 
as it was in GTA3� let�s kick some Triad�s asses!

CHAPTER #2

Converting, Modeling and Damages: Lawrence
Tuning: M3T4L

CHAPTER #3

If you want to contact us just e-mail us!

Lawrence: wlaw@inwind.it
M3T4L: gniccolini@tiscalinet.it
Power City Tuning e-mail: pctt@libero.it

WARNING
YOU MUST NOT MODIFY ANY PART OF THAT CAR WITHOUT OUR PERMISSION AND YOU MUST NOT POST IT 
TO OTHER SITES DIFFERENT THAN THE ONE'S IN WICH WE DECIDE TO POST IT