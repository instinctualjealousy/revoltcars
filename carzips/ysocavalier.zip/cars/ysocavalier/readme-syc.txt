This vehicle is by SYC, but did not come with a ReadMe file in the original car download.
