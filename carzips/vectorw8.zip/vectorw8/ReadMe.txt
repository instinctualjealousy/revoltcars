================================================================
Car Information
================================================================
Car Name  : Vector Wiegert Vector W8 Twin Turbo (the full name), shortened in-game to Wiegert Vector W8
Car Type  : Conversion/Repaint/Original (mostly converting)
Folder	  : ...\cars\vectorw8
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 46 or more
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
I'm sure after my announcement that I'm takin' a break, many of you thought I'd never do anything more, let alone another "pain in my rearside" conversion of a GT2 car. But this car is so amazing in real life and in GT2 that it just had to be ported to Re-Volt. Used the exact same techniques to convert it, with an added twist, the mapping is flipped on the opposite side so that it takes up less of the bitmap and is symmetrical. I did this in LithUnwrap, which I believe is an update of Lithium Unwrapper.

And yes, I know that the front lights aren't "true" to the actual car, but I like them that way, and I don't know how GT2 handles the lights on function, as the lights weren't a model included in the mesh.

Also, I had to delete and/or move some polygons on the mesh due to the way Re-Volt renders stuff.

================================================================
Construction
================================================================
Base           : Wiegert Vector W8 Twin Turbo by Polyphony Digital
Poly Count     : Not much
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, Chaos Tools (keep forgetting to mention Chaos), LithUnrap, FCE Finish to fix the normals (an NFS program)
Known Bugs     : Remapped conflicting mappings, so nothing really glitchy about that. It's as close to perfect as I can get it with my limited mapping skills.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

A long thanks list:
Thanks to the community for the enthusiasm that I need to continue
Thanks to Aeon for constructive criticism
Thanks to Manmountain for "just being there"
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to someone I don't know for Lithium Unwrapper
Thanks to zipperrulez for waiting

================================================================
Individual Thanks On This Car
================================================================
Car made by Polyphony Digital
Myself for the wheels (wheel textures internet)
Thanks to Polyphony Digital for their high-detail low-poly models
Thanks to Oleg for ZModeler and specifically the c?o importer
Rick Brewster for the awesomeness that is Paint.NET *very good for fancy pics, and texture sheets alike*

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell