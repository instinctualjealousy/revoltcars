------='67 Shelby GT500 - Eleanor=-----
---=by Alberto Daniel Russo AKA AdR=---
--------=adrstudio@hotmail.com=--------
------=http://dtd.niteshade.net=-------
---------------11/09/01----------------
--------=NFS version:16/10/01=---------
-----------UPDATED:05/03/02------------

Just fixed some normals, added a new chassis and new engine sounds took
from MCO... basically I "tuned" it up for NFS, so it looks much better
than the previous version.
The reason why I decided to update it was 'cause I've been getting a 
lot of emails asking for permission to convert this car for other games
like MM2, Viper Racing or even Nascar Heat. This is the version that's
worth converting, so you don't need to ask for my permission now, but
please let me know for wich game you converted it and where it goes.
I'd like to know where my work goes... don't forget about the credits.
The credits for the Halibrand Cobra wheels should go to Ryan T, the 
rest is mine.

go nuts! =)