Car:
-----------
Honda Accord LX 1997


Author:
-----------
SYC Motors

This is a SYC Motors 1997 Accord LX type-R

It has:
- 3 upgrades
- Realistic Performance
- Low poly hi detail Accord frame I made from EA's BMW M5.

no upgrade:170hp
2.4L Horizontal Inline 4
4 speed auto
TOP 250Kph
0-60 4.14
