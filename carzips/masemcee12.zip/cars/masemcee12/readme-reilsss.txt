Maserati MC 12

Author: Reilsss

Converter: Freak-DS

Mail: Reilsss@gmx.de 
         Freak-DS@gmx.net

Description: 

This Maserati MC 12 was built by Reilsss, so all credits goes to him.

Features:

-10k polys 
-Animated (Standart NFS4) Driver
-Openable Roof
-10Colour-shemes
-...

Thanks to:

Reilsss for building & allowing me the converting of this car


YOU MAY NOT EDIT, CONVERT IT OR UPLOAD IT ON ANY PAGE WITHOUT THE PREMISSION
OF THE AUTHOR!!
