================================================================
Car Information
================================================================
Car Name  : Cobra Daytona Coupe
Car Type  : Conversion
Folder	  : ...\cars\cobracoupe
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Almost 50
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.vndv.com

================================================================
Car Description
================================================================
I love doing GT2 conversions every once in a while to burn some time off. This is my first GT2 conversion of the new school year. I am now a junior in high school, or what most may call 11th grade or year. I cheapened the sides so that the numbers don't mirror, rofl.

================================================================
Construction
================================================================
Base           : Cobra Daytona Coupe
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) RV-Sizer, and a couple others
Known Bugs     : All the stuff that can't be prevented like shiny wheel wells, but everything else is non-buggy.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
Polyphony Digital for the body mesh
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Myself for the wheels

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site
