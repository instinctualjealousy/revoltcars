================================================================
Car Information
================================================================
Car Name  : F-250 Lowrider (from Ford's World [4x4 Evo car modder])
Car Type  : Conversion with sum UV stretching
Folder	  : ...\cars\f250lowride
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 39ish (observed, may reach higher under certain situations)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
My first 4x4 Evo conversion, quite large. Wheels by SupermotoXL, an excellent 3d modeler, and were included on the original car as well. Not much to say about it. Parameters tweaked by Manmountain.

================================================================
Construction
================================================================
Base           : F-250 mesh from 4x4 Evo by Terminal Reality with SupermotoXL's wheels
Poly Count     : All in the wheels pretty much
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, Chaos Tools (keep forgetting to mention Chaos), FlyRawGUI, and PodView , and also Lithium Unwrapper (thanks Aeon for the tip on this wonderful prog)
Known Bugs     : Remapped conflicting mappings, so nothing really glitchy about that. Axles are kinda low in comparison to the wheels, but the original car has the same "flaw".

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

A long thanks list:
Thanks to the community for the enthusiasm that I need to continue
Thanks to Aeon for constructive criticism
Thanks to Manmountain for "just being there", and doing params for this car
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to someone I don't know for Lithium Unwrapper
Thanks to zipperrulez for waiting

================================================================
Individual Thanks On This Car
================================================================
Car made by Terminal Reality
Wheels made by SupermotoXL
Thanks to KC for providing a legal free version of 4x4 Evo
Thanks to Oleg for ZModeler and specifically the SMF importer
Rick Brewster for the awesomeness that is Paint.NET *very good for fancy pics*

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell