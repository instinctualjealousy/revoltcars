Alfa Romeo GT 2004

Features:
-----------------
3d rims
3d lights
Interior
NOS Boost
Polies: 4000
-------------------

Do not edit or upload car for public purposes without
my permission. You can edit the car for your personal use only.