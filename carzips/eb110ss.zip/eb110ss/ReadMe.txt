================================================================
Car Information
================================================================
Car Name  : Bugatti EB110 SS
Car Type  : Conversion
Folder	  : ...\cars\eb110ss
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Around 50 (I really don't care to observe, it's about where it tops off though)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.byethost14.com

================================================================
Car Description
================================================================
Not too many Bugatti cars for Re-Volt. Probably converted at the dismay of Rally Leggend Stiu, whom hates French cars no matter what. Styling is definitely an acquired taste, I'm not too keen on it either, but I like the overall car's design as a whole, the front is sorta iffy though.

From a technical standpoint, it's an excellent little model that makes good use of texturing.

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) RV-Sizer, and a couple others
Known Bugs     : I really, really don't think so. -Torben Ulrich

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh for the main body mesh.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Myself for the wheels

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site
