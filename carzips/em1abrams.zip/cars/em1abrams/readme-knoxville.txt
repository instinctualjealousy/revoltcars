Hi.
I'm glad you have downloaded my
first low-poly I like :))
Please feel free of posting any comments.
Some of my artworks if anybody interested:
http://render.ru/gallery/show_work.php?work_id=15072
http://render.ru/gallery/show_work.php?work_id=14185
http://render.ru/gallery/show_work.php?work_id=3705
http://render.ru/gallery/show_work.php?work_id=11326
http://render.ru/gallery/show_work.php?work_id=4770
http://www.3dexport.com/search.php?search_user=knoxville

Thanx a lot...
>>>>>>>>>>>>>>>>>>>>>>>>>
knoxville@list.ru