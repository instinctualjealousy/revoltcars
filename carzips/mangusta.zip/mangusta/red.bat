@echo off
copy red.bm* car.bm*