@echo off
copy sepia.bm* car.bm*