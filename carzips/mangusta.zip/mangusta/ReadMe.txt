================================================================
Car Information
================================================================
Car Name  : DeTomaso Mangusta
Car Type  : Conversion
Folder	  : ...\cars\mangusta
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 43 mph I think... Really tops out at 42 though.
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (stopped updating my site, all uploads to RVZT)

================================================================
Car Description
================================================================
Converted by me obviously, the original readme doesn't state much, sadly.
Wasted my time making some colors instead of the usual grey!!!!1111111111
The original car was by K/Cendra!

Here is the NFSCars page:
http://www.nfscars.net/file/view/highstakes/364.aspx

And I also know that it has been a while since my last release (1 month or more), but, please, bear with me!

================================================================
Construction
================================================================
Base           : NFS4 model (K/Cendra) converted by me
Poly Count     : Methinks 2000ish (too lazy to open properties in ZMod..)
               : 
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) ntdll.dll gotta love it
Known Bugs     : Absolutely none that I know of ATM. (as always)

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.


The community feels dead right now, do your part and keep it alive!
Ok, its completely dead now!
But I'll still release stuff :P
================================================================
Individual Thanks On This Car
================================================================
All credit goes to K/Cendra, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Corel for PSP 10.03 (for the Red/Green/Blue color edit)

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: uh, yeah.... It's repaintable at least, and I did the colors...
================================================================
Where to get this CAR
Websites: RVZT
