@echo off
copy silverblue.bm* car.bm*