@echo off
copy purple.bm* car.bm*