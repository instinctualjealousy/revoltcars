@echo off
copy silver.bm* car.bm*