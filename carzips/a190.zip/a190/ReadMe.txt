================================================================
Car Information
================================================================
Car Name  : Mercedes-Benz A190
Car Type  : Conversion
Folder	  : ...\cars\a190
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Almost flat 40 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.vndv.com (this is the last move "fo sho")

================================================================
Car Description
================================================================
A conversion of a tiny car that might go well with the MCC Smart. Nimble soft parameters that might be kinda slow for this type of car but offer a smooth and untwitchy ride on most simple tracks.

================================================================
Construction
================================================================
Base           : Originally an NFS4 model by Ryuji Kainoh
Poly Count     : You really shouldn't care...
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!), Chaos Tools
Known Bugs     : Nothing to care about. I, I really don't think so.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools

================================================================
Copyright / Permissions
================================================================
Authors MAY possibly (I guess) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: Re-Volt Zone Tracks and my new site

