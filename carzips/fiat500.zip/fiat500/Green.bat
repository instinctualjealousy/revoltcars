@echo off
copy green.bmp car.bmp
ECHO Copy complete. The Fiat 500 is now "Green".
ECHO Note: this script CAN be used while Re-Volt is running.
pause