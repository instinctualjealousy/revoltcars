================================================================
Automobile Info
================================================================
Car Name  : Fiat 500
Car Type  : Conversion
Folder	  : ...\cars\fiat500
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Above 40. Decided to make it slower than what I usually go for.
Rating    : Professional

================================================================
The 'tard who converted this disasterpiece
================================================================
Author Name : Adamodell
E-Mail      : metallicafan128@gmail.com 
Homepage    : http://adamodell.vndv.com

================================================================
Descrip'n, homie
================================================================
Conversion of The Power City Tuning Team's "Fiat Nuova 500 v.4".
Parameters heavily modified from the set MM made for my 917K.
Batteries not included.
Sent an e-mail out to TPCTT to see if they are fine with my conversions of their cars. I think they'll be fine with it, but I felt like I should finally try to contact them.... awaiting a response.

================================================================
Blood, sweat and tears
================================================================
Base           : NFS4 model (The Power City Tuning Team and Whoever Else) converted by me
Poly Count     : Not terrible
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b and anonymous bull****, hulscale, Chaos Tools (in a 32-bit VM)
Known Bugs     : The fact that it drives like poop.

================================================================
Tanks. :P
================================================================
Thanks to Power City Tuning Team for the model.
Thanks to Dave-o-rama for all you getting served by a fat ugly lunch lady.
Thanks to my best friends for keeping me sane and feeling all warm and fuzzy inside.

================================================================
Copyright
================================================================
Well, I don't know what The Power City Tuning Team want. Just read their readme if you want an idea. Haha.

================================================================
Where to get this cah in the yahd
================================================================
Websites: RVZT and your m...-my site. Maybe an RVL release.
