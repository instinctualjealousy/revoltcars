@echo off
copy yellow.bmp car.bmp
ECHO Copy complete. The Fiat 500 is now "Yellow".
ECHO Note: this script CAN be used while Re-Volt is running.
pause