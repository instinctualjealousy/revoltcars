@echo off
copy red.bmp car.bmp
ECHO Copy complete. The Fiat 500 is now "Red".
ECHO Note: this script CAN be used while Re-Volt is running.
pause