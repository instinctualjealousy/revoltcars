@echo off
copy orange.bmp car.bmp
ECHO Copy complete. The Fiat 500 is now "Orange".
ECHO Note: this script CAN be used while Re-Volt is running.
pause