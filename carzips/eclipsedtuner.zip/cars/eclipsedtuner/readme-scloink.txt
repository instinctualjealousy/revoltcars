=====================================================================
Eclipse GSX converted from NFS by scloink
=====================================================================
Car name                : Eclipse GSX
 
Install in folder       : Unzip all files to your main Re-Volt folder

Author/s                : scloink 

Email Address           : extremerv@djis.net 

Homepage	        : http://www.rvarchive.com/  

Rating                  : Pro/44 MPH                                                        

====================================================================
Description:
This is the great Mitsubishi Eclipse GSX. It is an all wheel drive car with a turbo engine. It ranks up there with the Acura Integra Type-R in performance. The ReVolt version holds true to the real car by having all wheel drive and good handling. Acceleration also is good and the car was made to perform similar to the Integra Type-R made also by me. I made it a pack of six cars because we didn't like having to change the skin when we were racing multi as will as not liking every car looking the same. The parameters on all of them are exact. So the only difference is the color.

Creation:
This car was converted using NFS Wizard to extract the fce file. Then ZMod was used to import it then export it as a 3Ds file. Finally I imported it into Max 3.1 for editing and sizing. The wheels are custom wheels created by me in Max to resemble the original wheels that were standard on the GSX models. 


Tools Used:
NFS Wizard, ZMod, PSP 7.0, and Max 3.1


Thanks:
Thanks go out to the entire community and especially to Wayne Lemonds because without his support during GA Games romp through our lovely community the RV scene would have probably died because his message board helped keep people around and interested.


Special Thanks:
Ryuji KAINOH - Original Author (see RKReadme.txt)
The Me and Me - Testing 
SlowJustice - Testing and advice
DSL_Tile - Testing and advice
CADster - Advice in Max
triple6s - Testing and advice and giving me an all around hard time.
crosseyed - Testing and advice
Krytt - My wife for putting up with me while I continue to mess with the crazy game.


Very Specail Thanks:
God - For allowing me to live another day.

 
Anoyone else I may have missed in this readme please forgive me as it has been months since I converted this car and it is just now getting posted. Hehe.


Visit:
www.rvarchive.com - The Revolt Archive
www.racerspoint.com - The Racers Point, home of the greatest forum anywhere


