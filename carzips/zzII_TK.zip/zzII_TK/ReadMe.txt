================================================================
Car Information
================================================================
Car Name  : zzII TK 
Car Type  : Repaint
Folder	  : ...\cars\zzII_TK
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 59
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : rally leggend stiu
EMail       : rallyleggendstiu@msn.com
================================================================
Thanks to:
================================================================
RVZT to accpet my repaints;
adamodell to helped me with the front bumper;
you to have downloaded my repaint.

(maybe it's a bit dark, i know, a little lighter will better..)
Plz comment it!!