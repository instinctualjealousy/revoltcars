================================================================
Car Information
================================================================
Car Name  : Tommy Kaira ZZII (in four variations: Novice, Medium, Pro, F1)
Car Type  : Conversion\Repaint\Some Original stuff like UV assignment
Folder	  : ...\cars\zzIIbase, zzIInovice, zzIImedium, zzIIprofessional, zzIIf1
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 43-63 depending on variation (just an estimation, guess from Test Track 5)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
The most difficult GT2 conversion yet, took me four days to do due to all the mistakes I made repeatedly. Used a different method to get the textures this time. I printscreened GT2 on ePSXe in 800x600 resolution and edited it all in Paint.NET into something that resembled a texture sheet.
I made future texture edits AFTER the car was mapped, too.
Now, just enjoy, and if you want a real challenge, drive the rear-wheel drive Professional version. It slides out like nothing else. Also looks good too. The F1 version is easier to drive, and reaches a top speed of 63 mph.
Yes, you need this base folder. It contains all the PRM's to load.


P.S.: I remapped my wheels for this car, the mirroring for the left and right side is more symmetrical. It still has wheel wobble, even though I resized the square plane way smaller, so it don't protrude out outside the wheel part. Looks more like a GT2 wheel, and I'm sure you'll like the Dunlop logo on the sides :P.

================================================================
Construction
================================================================
Base           : Tommy Kaira ZZII mesh from GT2
Poly Count     : 500-something for the body, 258 for each wheel! (no, it's not 2000, RST!)
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, GT2Vol
Known Bugs     : Miniscule to nothing. You can see the environment through some parts of the car, as it isn't doublesided. As doublesiding results in peculiar polygon glitching on most GT2 cars to my experience :P.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

My longest thanks list ever:
Thanks to the community for the enthusiasm that I need to continue.
Thanks to Aeon for constructive criticism.
Thanks to Manmountain for "just being there"
Thanks to RST for what-else am I forgetting and not banning me twice :)
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to my own drive and determination to innovate RV conversions once more with this GT2 breed of cars
Thanks to RST in giving me permission to post my GT2 to RV tutorial elsewhere (but I won't until it is done)
Thanks to Oleg for the relatively easy UV mapper in ZModeler
Thanks to zipperrulez for waiting

================================================================
Individual Thanks On This Car
================================================================
Car made by Polyphony Digital
Myself for the wheels (wheel textures Polyphony Digital)
Thanks to Polyphony Digital for Gran Turismo 2
Thanks to Oleg for ZModeler and specifically the flawed GT2 importer
mkreations for GT2Vol (on this page: http://www.geocities.com/mkreations/files/)
ePSXe for my ability to take pics of the car with a printscreen
Rick Brewster for the awesomeness that is Paint.NET *very good for making texture sheets*
RST for checking the car and "beta" testing, some R3-DCP pics

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
          http://z8.invisionfree.com/RRR_Racing_Forum/
          Anywhere else I'm missing!
