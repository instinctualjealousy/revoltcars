Chaparral 2F for NFS4


___________________________________________________________

Title          : chaparral 2F
File           : chaparral.zip
Author         : Eddie B (Fivespeed)
Email          : fivespeed3@hotmail.com
Homepage       : http://savidge.sniperland.com/5Speed/5speed.html

Used Editor(s) : NFS Wizard
               : Zonoza Modeler
               : NFS Car CAD v1.5b 
               : PaintShop Pro 5J
               : FCEfinish v2

Thank you to the creators of these programs.
___________________________________________________________

Installation;   
               
: Put the "car.viv" in "Program files\Electronic Arts\Need for Speed High Stakes\Data\Cars\ch2f".

___________________________________________________________

Featutes;      
               
: Scratch built
: 3D chrome exhaust
: Accurate 3D model
: Tons of small details (logos, lights, interior etc.)
: Clear windows (all graphics cards)
: Animated driver (Thanks to Beniamino Calchera for the driver)

___________________________________________________________

By downloading the car you have agreed to the following; 

: Any emails asking to modify, change or tune the car in any way will be ignored. (The car may be modified for personal use only.  I will not give permission to release) 
: Any emails asking to convert the car will also be ignored.  
  The car may be converted to other games, but only if "Fivespeed" is clearly stated as the author of the car ON THE WEBSITE AS WELL AS THE README.
: No part(s) from this car may be taken out and used on other cars without my permission.
: Feel free to upload this car to your website as long as I am credited as author (ON THE WESITE)

THE CAR WILL BE TAKEN OFF A WEBSITE AND PRONOUNCED STOLEN IF;

:The car does not clearly state "FIVESPEED" as the author on the website and readme.
:The converted car does not clearly state "FIVESPEED" as the author on the website and readme.


This car is scrath made by me, please respect the time and effort I have put into it.
___________________________________________________________


Final thought;

:Thank you for your time in reading this.  
:Thank you for downloading

Now enjoy the freaking car!

             
                                                           -Eddie B (Fivespeed)-
