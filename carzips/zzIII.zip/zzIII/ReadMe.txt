================================================================
Car Information
================================================================
Car Name  : Tommy Kaira ZZIII (only one hard to drive variation)
Car Type  : Conversion\Repaint\Some Original stuff like UV assignment
Folder	  : ...\cars\zzIII (one folder w00t!)
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 45 (I'm getting really lazy at filling out the readme)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
Didn't take me as long to do. There are some UV seams because I still suck at UV mapping. They are hard to notice though, and hard to fix due to the source textures (literally printscreened on ePSXe!)
Decided to include a Hue/Saturation style color changer with it. Might come with the PSD version on RVZT, it is Manmountain's choice. It will come with both the Paint.NET and Photoshop Document versions on my site though. I'm still not sure if I should of released it with such unstable params.

The front and back UV mapping is amazing, in my opinion, but, the side is lackluster, took me a while to fix it up to be releasable.
The car's parameters are pretty much "track only" as this thing can barely take bumps. RWD too. The grip values of the rear wheels are quite high.

================================================================
Construction
================================================================
Base           : Tommy Kaira ZZIII mesh from GT2
Poly Count     : (not lazy today), 289 polies for body!, 258 polies for each wheel
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, GT2Vol
Known Bugs     : Miniscule to nothing. You can see the environment through some parts of the car, as it isn't doublesided. As doublesiding results in peculiar polygon glitching on most GT2 cars to my experience, also the UV mapping isn't completely seamless.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

My longest thanks list ever:
Thanks to the community for the enthusiasm that I need to continue.
Thanks to Aeon for constructive criticism.
Thanks to Manmountain for "just being there"
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to my own drive and determination to innovate RV conversions once more with this GT2 breed of cars
Thanks to Oleg for the relatively easy UV mapper in ZModeler
Thanks to zipperrulez for waiting

================================================================
Individual Thanks On This Car
================================================================
Car made by Polyphony Digital
Myself for the wheels (wheel textures Polyphony Digital)
Thanks to Polyphony Digital for Gran Turismo 2
Thanks to Oleg for ZModeler and specifically the flawed GT2 importer
mkreations for GT2Vol (on this page: http://www.geocities.com/mkreations/files/)
ePSXe for my ability to take pics of the car with a printscreen
Rick Brewster for the awesomeness that is Paint.NET *very good for making texture sheets*
Thanks to GIMP for helping me make a PSD version that wasn't an effing megabyte like the PDN PSD exporter

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell