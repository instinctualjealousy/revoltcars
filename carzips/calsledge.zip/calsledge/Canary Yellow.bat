@echo off
copy canaryyellow.bmp car.bmp
ECHO Copy complete. The Callaway Sledgehammer is now "Canary Yellow".
ECHO Note: this script CAN be used while Re-Volt is running.
pause