@echo off
copy red.bmp car.bmp
ECHO Copy complete. The Callaway Sledgehammer is now "Red".
ECHO Note: this script CAN be used while Re-Volt is running.
pause