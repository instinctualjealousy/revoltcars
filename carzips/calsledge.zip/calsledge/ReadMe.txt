================================================================
Car Information
================================================================
Car Name  : Callaway Sledgehammer [Corvette]
Car Type  : Conversion
Folder	  : ...\cars\calsledge
Install   : Unzip with folder names on to the main Re-Volt folder or install with my crazy installer
Top speed : You waited a year for a conversion, so why would you care?
Rating    : Pro-fessional

================================================================
Author Information
================================================================
Author Name 	: Adamodell
EMail and MSN	: metallicafan128@gmail.com (Find me on MSN!! I wanna talk! Well, maybe not...)
Homepage    	: http://adamodell.vndv.com

================================================================
Car Description
================================================================
My first conversion in ages. It's quite a few firsts, actually:
1. It's my first NEW car this year (not counting reversionings)
2. It's my first car converted on my weaker upstairs computer
3. It's my first on this clean install of XP
4. This is my first ReadMe I tried on
5. Hai!

I hope you like it. I hope I scare a few people as well. And I wish you all a merry Christmas, even if I'm more atheist than most agnostics. It's all about the presents, isn't it? Haha. Nah, it's about giving. I like giving. I give this all to you, haha.

I realize the parameters aren't that good. =)

================================================================
Construction
================================================================
Base           : NFS4 model by Sniper
Poly Count     : 3041+(350x4)=Four thousand, four-hundred forty one polygons as reported by RV-COUNT.
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b (haven't crashed on my new XP install yet), Chaos Tools, hulscale
Known Bugs     : I'm a perfectionist. Don't point out errors or I might OCD on them.

================================================================
KTHXBAI
================================================================
Well, I'm good. My life is new, and I have met new friends. I have moved on. Crap, I gotta get my hours in for my driver's license, but crap I don't care about that. Well... I now have a girlfriend but no car! Haha, what's wrong with that picture? Everything. I myself never paint the pictures correctly. My life is like abstract art. It's low in quality but it could be appreciated by a few numnuts. My conversions are not, though. I try to perfect with each release. This latest might sadly be a regression simply because I haven't converted in ages... hence a bit rusty at it. I think it's a good one though. Not my best, admittedly. I will own you, fellow converters! Yes, that means you, the dude with the name referencing a crappy CD burning program!

================================================================
You've seen it before... thank you all!
================================================================
Pretty cool model by Sniper
The Me and Me as my main influence and drive to convert (doubt it)
Aeon, for not sucking
Rick Brewster: for being sponsored by Microsoft and somehow not sucking (Thanks for PDN)
Oleg M. for ZModeler 1.07b
The lacking Re-Volt Communion and all who behold the title "member"
Manmountain, where art thou?

================================================================
Copyleft
================================================================
Screw copyrights. You can use this car as your personal "toy" if you see fit. But... you have problems if you do that. You can advertise it to cure AIDS too. Just, I want a cut of the money.

================================================================
Oh car, where art thou?
================================================================
Websites: http://adamodell.vndv.com, perhaps RVZT at later date