@echo off
copy lightblue.bmp car.bmp
ECHO Copy complete. The Callaway Sledgehammer is now "Light Blue".
ECHO Note: this script CAN be used while Re-Volt is running.
pause