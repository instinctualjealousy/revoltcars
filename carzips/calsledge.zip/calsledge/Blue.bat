@echo off
copy blue.bmp car.bmp
ECHO Copy complete. The Callaway Sledgehammer is now "Blue".
ECHO Note: this script CAN be used while Re-Volt is running.
pause