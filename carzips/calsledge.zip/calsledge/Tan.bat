@echo off
copy tan.bmp car.bmp
ECHO Copy complete. The Callaway Sledgehammer is now "Tan".
ECHO Note: this script CAN be used while Re-Volt is running.
pause