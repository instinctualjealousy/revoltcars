 ........    ..          ........           ........          .          ........      ........
.........    ..          .......           .........         ...         ..........   .........
..           ..              ..            ..               .. ..        ..      ..   ..
........     ..             ..             ..              ..   ..       ..........   ........
 ........    ..            ..              ..             .........      .........     ........
       ..    ..           ..               ..            ...........     ..   ..             ..
.........    .......     ......            .........    ..         ..    ..    ..     .........
........     .......    .......             ........   ..           ..   ..     ..    ........ 


THANK YOU FOR DOWNLOADING.
   
NAME           : BMW M3 E46 GTR - Most Wanted.
FOR            : Need For Speed:High Stakes (NFS4:HS).
GAME CAR NAME  : BMW M3 E46 GTR.
RELEASE DATE   : 10th September 2006.
ORIGINAL AUTHOR: StYLiZeR.
Email          : slz.rupak@yahoo.co.in

TOOLS USED TO  : ZModelor 2.0.7.
CONVERT &      : ZModelor 1.07.
MODIFY         : MWTex.
               : Adobe Photoshop 7.
               : NFS Wizard.   
               : FCE Finish 2.
               : FCE Center.
THANKS TO THE AUTHOR OF THESE TOOLS.


--->Need for Speed:Most Wanted conversion by StYLiZeR.<---


--->THANKS TO:-
>Dato. This car would have been impossible if dato wouldn't have send me the installation of ZModelor 2.0.7.
>Sparkle. NOS performance file from his FnF Mazda RX-7.

   
--->INSTALLATION:-
Make a new folder named 'MWM3' in your NFS4 directory/Data/Cars & then copy car.viv in it.


--->FEATURES:-
Damage:- Yes.
Convertible:- Yes.(People with no graphic cards acn turn this option on to disable windows.)  
Dashboard:- No.
Class:- AAA. 
Serial Number: 28. 
Windows:- Black tinted transparent & Grey tinted headlight covers.
Licence Plate:- Yes. 
Top Speed:- 330 kmh
Polycount:- 10103 Faces. 
Pursuit:-No.

>Performance from Sparkle's FnF Mazda RX-7.
>Original model with textures on proper positions.
>Lights in proper place.
>Stock horn and engine sounds.
>Driver & head movement.
>Works on every version of NFS4.
>Original driver of NFS:MW with fingers.
>3d brake discs & caliper.


--->NOTE:-
1:)Please do not modify,change,tune or convert this car to other games without my proper permission.
2:)You may upload the car to any website.
3:)You are not allowed to convert this car for NFS6. Modified and converted is OK.


--->KNOWN BUGS:-
1 | When I want to start the race, it crashes saying "Exception caught...".
A:- Its a serial no. conflict(two cars have the same serial no.). Get NFSWizard or Serialnumbereditor and change it.

2 | If I want to view a car in the menu, it crashes with the message "render out of ran".
A:- This is a high poly car. NFS4 can render cars up to 5000 polies. Get a highpolypatch to fix it.

3 | Iam getting an "exception caught" message when I start a race. Theres no serialnr. conflict and a high poly patch is          installed.
A:- It has something to do with the polycount. When you start a Full-Grid race, the game have to render SO many polies, that      it will crash. Race alone or with less or other car opponents.

No other bugs other than these I guess.

HAVE FUN..........
                                                     -StYLiZeR.          
 