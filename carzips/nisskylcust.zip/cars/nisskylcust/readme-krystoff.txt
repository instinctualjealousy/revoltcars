Nissan Skyline Gtr-R for Need for speed IV

Title          : Nissan Skyline Gtr-R
Car            : Nissan Skyline Gtr-R (SN:27)
File           : gtrr.zip
Version        : 1.0 (Upgrade Feature : No)
Date           : Apr 2002

Author         : Krystoff
Email          : christophe.dugourd@laposte.net

Used Editor(s) : NFS Wizard 
               : Z Modeler
	       : PaintShop Pro
               : Fce Center
               : Fce Finish    

Thanks	       : EA for the base
__________________________________________________________

Installation : Put the "car.viv" in "Data\Cars\Gtrr"