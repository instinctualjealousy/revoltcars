Turn word wrap on if you're sick of scrolling.

================================================================
Car Information
================================================================
Car Name  : Isdera Commendatore 112i
Car Type  : Conversion
Folder	  : ...\cars\isdcomm
Install   : Dump this car's folder into cars. That or, do the RVZT way, drag cars into "Re-Volt". Or if you used my installer, ignore.
Top speed : Around 41 mph
Rating    : Professional

================================================================
Car Description
================================================================
Mostly the same ideals- I decided against making it like my old conversions in the end. Kinda hard to drive on bumpy roads- I'd keep this thing on a race track unless you want a ride that could be potentially difficult. I added TheMeandMe's spoiler to the mesh itself, remapped it as I saw fit, manually double sided the polygons (so sadly it's double the polygons, but I don't feel like hexing in double side properties). Remapped the bottom to a better bottom texture- remapped the windows and inner wheel wells to a portion of the map that didn't conflict with my custom wheel mesh- used FCE Finish to calculate vertex normals that were lost during the 3ds format intermediary, used ZModeler to disable ENV on faces sa I saw fit, including the rear portion of the car, the bottom of the car, and the carbon fiber portion of the wing. Used RV-SIZER and rvshade in XP VM. Added shadow to texture to simulate under-spoiler shadow.

The car itself handles badly at slower speeds, gaining better handling abilities at higher speeds- for this reason- it's better to drive it as fast as you can- and preferably on tracks where that's an advantage- unless you can handle the rear tire slip at low speeds.

Car paint sheet comes as a PSD file this time through- and always will from now on. Paint.NET has a pretty good PSD plugin now, GIMP can open PSD natively, Photoshop can open PSD natively (duh), and PSP can open PSD natively (I think). There's no point in using a format like PDN to release my color sheets when only Paint.NET can open it.

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh
Editor(s) used : Paint.NET, ZModeler 1.07b, RV Minis 5, prm2hul, Car::Load, LithUnwrap, FCE Finish, RV-Sizer
Known Bugs     : Underneath wheel wells shine. The polygons were meshed together in such a way that was too confusing for me to "Don't blend textures" on. You'll likely not notice or care. There were even polygons RIGHT ON polygons, which made selecting hard- I don't know why there was polygons placed in such ways.

================================================================
You've seen it before... thank you all!
================================================================
DSL_Tile for keeping the Re-Volt love strong
AGT for having the coolest name of all (ALMIGHTYGodofTitans)
Ryuji Kainoh for generally knowing what the hell he's doing (I wish his site still existed)
Jigebren and KDL for making my job much easier (prm2hul/Car::Load)
Chris Elston for being my bestest friend ever, I love him, no homo (I hate gender double standards)
MOH for generally owning everyone else
Rick Brewster: for being sponsored by Microsoft and somehow not sucking (I <3 PDN)
Oleg M. for ZModeler 1.07b
Manmountain for having a cool name and being the main influence for my set of car parameters (to the point of me checking out his parameters and seeing how he did it)
And I'm sure there's a bunch of people I'm forgetting, so please pat yourselves on the backs (I'm not being sarcastic)

In the words of one of my favorite friends:
Danku. :3

And as an extra thanks- for making the recreation of my site possible:
RVZT, and the people who helped it exist throughout this time
Cat, for having a couple of my files backed up
Box.net, for me having some of my car installers uploaded to it
Mediafire, for having other slim pickins uploaded to it

================================================================
Copyright
================================================================
Do what you wish with this car, I ain't gonna be your personal nanny. Ryuji won't be, either. He's lenient and so am I. What kills communities like this is "rights" and the "mine mine mine" attitude of creators. Most of Re-Volt community understands this, and is pretty lax, thankfully. Let's keep the laxness up, it is what makes this community better than... that other game's community! While I think it is right to state who did what, people deserve credit after all... it isn't right to treat your stuff like a horny dominatrix. Let stuff be free.:)

================================================================
Oh car, where art thou?
================================================================
My new site is http://adamodell.co.cc/
Another URL for it is http://adamodell.vndv.com/, revived.
http://adamodell.web44.net is gone.
There's always RVZT as well.