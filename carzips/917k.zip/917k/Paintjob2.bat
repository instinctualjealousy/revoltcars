@echo off
copy car2.bmp car.bmp
copy car2.bmq car.bmq