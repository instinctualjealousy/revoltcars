================================================================
Car Information
================================================================
Car Name  : Porsche 917K
Car Type  : Conversion
Folder	  : ...\cars\917k
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 55 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell (and most definitely Manmountain)
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (newly updated again)

================================================================
Car Description
================================================================
Conversion of Kregspiel's 917K (it's frikkin wicked)
Use the included batch files to change between alternate parameters and skins.
Default parameters and skin are by Adamodell.

================================================================
Construction
================================================================
Base           : NFS4 model (Kregspiel) converted by me (modified by Manmountain)
Poly Count     : Body - 3058
               : Front Wheels - 400, Back Wheels - 382
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b, PSP4, Notepad
Known Bugs     : Absolutely none, non-clear windows due to superly crazy mapped windows....

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading 
this car (and many other way better ones I might add) is what is keeping the community 
alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credits go to Kregspiel, but here's other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model (lol)
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community

================================================================
Copyright / Permissions
================================================================
Authors MAY (don't care I guess, do what the hell ya want) 
use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: Not really any...

================================================================
Where to get this CAR
Websites: RVZT and my site...
