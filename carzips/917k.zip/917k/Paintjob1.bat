@echo off
copy car1.bmp car.bmp
copy car1.bmq car.bmq