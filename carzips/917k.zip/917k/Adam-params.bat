@echo off
copy Adam-parameters.txt parameters.txt