@echo off
copy MM-parameters.txt parameters.txt