I was asked to give a fresh spin to this car. This is the result.

It is my take of a balanced police car: it�s now an embodiment of the �strong arm of the law� � armour-heavy and powerful, but also prone to slip at times.

As has become the law with me lately, it includes two versions: one for training on RC tracks and one for service on RL tracks. 

Technically: 10 kgs of weight make it impervious to most weapons and ramming, and high speed and acceleration make it nimble at the same time, but with great power comes great propensity to make a mistake and hit a wall, so to speak � meaning: it�s a half-drifter, so be careful where you point your vectors :) 

Expert AI is optimised for close-quarters crime-fighting at Hood 2, but can also cope with the wide-open approach of Hood 1.
RC is tuned for powerslide at threshes 2187.500000.
RL is good as easy powerslider with threshes 5000.000000.


Have fun and be responsible!


Credits: parameters are somewhat based on my own Nissy (my old-time edit of MOH�s Nissan 350z), visuals are from Adamodell.

(I can be contacted at Re-Volt Live and Our Re-Volt Pub forums.)