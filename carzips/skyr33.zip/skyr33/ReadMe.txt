================================================================
Car Information
================================================================
Car Name  : Skyline GT-R R33
Car Type  : Conversion
Folder	  : ...\cars\skyr33
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 48 or so
Rating    : Pro

================================================================
Author Information
================================================================
Author Name 	: Adamodell
EMail and MSN	: metallicafan128@gmail.com (Find me on MSN!! I wanna talk!)
Homepage    	: http://adamodell.vndv.com

================================================================
Car Description
================================================================
Slightly different params based off of the R32 Veilside Skyline, but it is much different in the way it leans into the corners. Standard fare conversion.

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) RV-Sizer, and a couple others
Known Bugs     : Good luck finding them. Once again.

================================================================
Thanks And Accolades
================================================================
This community has had its ups and downs thats for sure, I'm glad any of you still care. So thanks to the whole community for showing an ounce of respect to us all.

This car is dedicated to MOH because this is first day I have chatted with him on MSN.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh for the main body mesh!
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Myself for the wheels

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site, and probably a box.net link on RRR