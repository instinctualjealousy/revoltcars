================================================================
Car Information
================================================================
Car Name  : M1 Abrams Tank
Car Type  : Conversion
Folder	  : ...\cars\m1abrams
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : A slow tank, reaches about 40 with added weight
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
Doing it RiffRaff style this time. A conversion from a free 3DS mesh from http://modelsbank.3dm3.com. The person who did the model I believe is found on the links of the original readme, by the name of "Maxim Rudakov", but the site is in Russian. There is text on the bmp, but resizing it to 256x256 sort of removed it from being readable. The texture was originally a 1024x1024, but we know RV can't handle that. I made some texture edits do to the fact that this model uses only 1 prm. There are no wheel prms. I had to texture it so it was less obvious that the wheels weren't spinning. I changed the rims to a flat texture, and I removed the tread texture and replaced it with flat black.
The parameters were edited over and over again, and I still can't get the feel right.

This is where the model is available... It says "Guest" on it though...
http://modelsbank.3dm3.com/model445.htm

Also, this car's parameters are really made to handle like a tank. The thing slides out on hills sometimes, and take your turns wide.
Also, to turn sharper, let off of the accerator and keep turning. The vehicle will do a small drift to up the steering radius. Try it at the gas tanks of PetroVolt.

The thing is hesitant to turn, but turns relatively sharp when at full radius, with the slide very sharp.

================================================================
Construction
================================================================
Base           : Free mesh from 3dm3, believe it was made by Maxim Rudakov based on the links in the original readme
Poly Count     : 5000 is about correct
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!)
Known Bugs     : None, textures are low-res due to the fact that it originally came with a 1024x1024. Also, no individual wheel models.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
Believed to be made by Maxim Rudakov based on links
Zmodeler 1.07b keeps crashing...
They really need to make a Zmodeler2 filter for Re-Volt.
You know who I thank, you've seen it in over 30 readmes.

================================================================
Copyright / Permissions
================================================================
Authors MAY (I guess) use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
