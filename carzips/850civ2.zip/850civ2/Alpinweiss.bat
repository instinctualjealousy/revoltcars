@echo off
copy alpinweiss.bmp car.bmp