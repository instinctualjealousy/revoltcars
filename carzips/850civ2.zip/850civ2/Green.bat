@echo off
copy green.bmp car.bmp