@echo off
copy orange.bmp car.bmp