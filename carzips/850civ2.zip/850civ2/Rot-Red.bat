@echo off
copy rotred.bmp car.bmp