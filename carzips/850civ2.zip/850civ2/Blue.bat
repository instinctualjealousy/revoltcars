@echo off
copy blue.bmp car.bmp