@echo off
copy black.bmp car.bmp