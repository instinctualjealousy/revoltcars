================================================================
Car Information
================================================================
Car Name  : BMW 850ci v2
Car Type  : Conversion/Repaint
Folder	  : ...\cars\850civ2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 45~ mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (newly updated again)

================================================================
Car Description
================================================================
Conversion of Cooya!'s/ Yuriy Antipin's/ Clark's BMW 850ci.

Additions: Colors, new params, double-sided, centered, resized by 0.92. Wheels don't 
overcollide with brake pads now. Ever so slight 4-wheel steering for driftier performance.

================================================================
Construction
================================================================
Base           : NFS4 model (all 3 people stated above) converted by me
Poly Count     : 4000ish with those damn wheels
               : 
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b
Known Bugs     : Fixed all that were known

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading 
this car (and many other way better ones I might add) is what is keeping the community 
alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to three people stated above, but here's other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model, now for making me create a multi-color car!
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site...
