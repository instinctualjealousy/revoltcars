@echo off
copy yellow.bmp car.bmp