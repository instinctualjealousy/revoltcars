@echo off
copy grey.bmp car.bmp