Turn word wrap on if you're sick of scrolling.

================================================================
Car Information
================================================================
Car Name  : Nissan Stagea Autech Version 260RS
Car Type  : Conversion
Folder	  : ...\cars\stagea260rs
Install   : Dump this car's folder into cars. That or, do the RVZT way, drag cars into "Re-Volt".
Top speed : Around 40-41 average tops, competes with stocks more fairly than previous cars
Rating    : Professional

================================================================
Car Description
================================================================
This car is a reinvention of my ideals- it's been a year and I'd like to think I'm more mature now. When I got to work on this car, I had to kick myself in the butt- I had a few problems with the interior, Ryuji's mapping was weird, I don't believe I messed anything up. I instead realized interiors on these cars never really looked that good anyway. I pulled an "early BurnRubr" and trashed the interior- I reconverted to PRM without the interior at all, saving polygons, making it easier for me. The car itself competes much better with the stocks than my previous cars, and while it isn't perfect, it's a definite improvement. Also of note is the addition of an antenna, this is the first car I intentionally added an antenna to. One last note- this is my first car release that is posthumous to my site's premature death at the hands of negligent Zymic (and negligent me).

Also, I must note I rushed myself to finish this car- I was falling into "endless improvement hell".

P.S. Instead of using batch files to change color, I got rid of that completely- instead just edit the params to point to whatever bitmap you want. Don't be lazy. :)

If you wish to make your own colors- here is the intermediary file, Paint.NET format:
http://www.box.net/shared/ndlhfmuzvc

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh (I'd give this guy a big hug if it were possible, as he's made much of what I do possible)
Editor(s) used : Paint.NET, ZModeler 1.07b, RV Minis 5, prm2hul, Car::Load
Editor(s) ditched : hulscale, Chaos Tools set (just resized model in ZMod itself this time through, 64-bit OS prevents me from Chaos Tooling)
Known Bugs     : I'm a perfectionist. Don't point out errors or I might OCD on them.

================================================================
You've seen it before... thank you all!
================================================================
Cat for actually being cool and backing up my wheel meshes
DSL_Tile for keeping the Re-Volt love strong (being a "lifer" in his words)
AGT for having the coolest name of all (ALMIGHTYGodofTitans)
Ryuji Kainoh for generally knowing what the hell he's doing (I wish his site still existed)
Jigebren and KDL for making my job much easier (prm2hul/Car::Load)
People generally being supportive (generally)
Chris Elston for being my bestest friend ever, I love him, no homo (I hate gender double standards)
Everyone who doesn't suck at this (on a good day)
Aeon, for sucking even less than those who don't suck
MOH for generally owning everyone else
Rick Brewster: for being sponsored by Microsoft and somehow not sucking (I <3 PDN)
Oleg M. for ZModeler 1.07b, but no thanks for terrible NT compatibility
Manmountain for having a cool name
And I'm sure there's a bunch of people I'm forgetting, so please pat yourselves on the backs (I'm not being sarcastic)

In the words of one of my favorite friends:
Danku. :3

================================================================
Copyright
================================================================
Do what you wish with this car, I ain't gonna be your personal nanny. Ryuji won't be, either. He's lenient and so am I. What kills communities like this is "rights" and the "mine mine mine" attitude of creators. Most of Re-Volt community understands this, and is pretty lax, thankfully. Let's keep the laxness up, it is what makes this community better than... that other game's community! While I think it is right to state who did what, people deserve credit after all... it isn't right to treat your stuff like a horny dominatrix. Let stuff be free.:)

================================================================
Oh car, where art thou?
================================================================
As of now- RVZT is my new car release site. That's just how it is- blame Zymic for that. I have no more site, so this car will be released on RVZT only. I might actually go ahead and submit it to other sites too- to prevent it from disappearing like the rest of my stuff. AliasReVoltMaster? Re-Volt Tip Top? Who knows. Feel free to upload this package anywhere you wish, on any of the sites, anything. Share it.

-As you know, I eventually did make a site, obviously. This release from my site includes the PDN and the carbox.