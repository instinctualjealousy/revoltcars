================================================================
Car Information
================================================================
Car Name  : Porsche 924 Carrera GT
Car Type  : Conversion
Folder	  : ...\cars\porsche924
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Relatively the same as previous car
Rating    : Pro

================================================================
Author Information
================================================================
Author Name 	: Adamodell (and a touch of DSL_Tile)
EMail and MSN	: metallicafan128@gmail.com (Find me on MSN!! I wanna talk!)
Homepage    	: http://adamodell.vndv.com

================================================================
Car Description
================================================================
Another car, now comes with a param set by DSL_Tile, set as the default params. My params are a relative copy of the 968 params with maybe a couple tiny tiny tweaks. Tile's params are more inventive and completely different than anything that has been released under my name. You have the ability to change/make your own colors (making colors requires files not included in RVZT release), and choose whether you want the lights up or down. Please enjoy, I'm running out of time.

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) RV-Sizer, and a couple others
Known Bugs     : Good luck finding them. Again.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

This car is dedicated to a certain special someone, but I don't care to tell. Anyone who has spoken with me on MSN for extended periods of time knows who I'm talking about, especially SnOoKiE_21.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh for the main body mesh!
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Myself for the wheels
DSL_Tile for supplying params

SnOoKiE_21 for helping me think in a more logical manner, and helping me get over my depressed moments in real life, even if he's doing it across the ocean in a wonderful place called Melbourne in Australia, thanks for your time!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site, and probably a box.net link on RRR