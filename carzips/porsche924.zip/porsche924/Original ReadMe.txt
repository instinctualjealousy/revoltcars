Porsche 924 Carrera GT for Need for speed IV

Title          : Porsche 924 Carrera GT
Car            : Porsche 924 Carrera GT (SN:11)
File           : p92c.zip
Version        : 1.0 (Upgrade Feature : NO)
Date           : JUL 2002

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : NFS Wizard v0.5.0.79 by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 297) by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 299) by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : NFS Car CAD v1.5b by Chris Barnard
               : CAR3TO4 by J�Eg Billeter
               : NFS FCEConverter by Addict&Rocket
               : PaintShop Pro 5J

* CM_500 made 924 Carrera GT's "CARP.TXT" for my car.

Thanks.
___________________________________________________________

Installation : Put the "car.viv" in "Data\Cars\p92c".
               and  the "p92c.qfs" in "Data\FeArt\VidWall".

Have a fun !!