================================================================
Car Information
================================================================
Car Name  : R30 Silhouette Formula v2
Car Type  : Conversion\Repaint\Some Original stuff like UV assignment
Folder	  : ...\cars\r30silformulav2
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Standard fare
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.byethost14.com (just as old as ever!)

================================================================
Car Description
================================================================
Addition: Hulscaled hul and all that. The biggest thing about this revision is all the new texturing, color making, and the fact that the left and right sides are mapped to different parts. The newest wheels are good as well, and the wheel texture was ripped from GT2. Every other texture on this car was either hand made or taken from real car pictures.

Original: I'm not sure if this or the Elise was harder. They took about the same lengths to convert. Also, just so you know, this is almost a definite version 1. I'm probably going to finish the rest of the missing logos later, but I like it quite a lot right now.
UV mapping is fun, yet a bore.The front is what is most completed, with accurate hood and front logos, and even the correct TOMICA bumper. There is room for improvement, though, as on all of my cars. And so you know, I AM working on another GT2 conversion. Either an MR-s/MR2 Spyder (depends on where you live), or a Tommy Kaira ZZII, I can't decide. I'm working on them right now. It's very difficult to find textures for these cars.

================================================================
Construction
================================================================
Base           : R30 Silhouette Formula mesh from GT2
Poly Count     : I stopped caring
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, GT2Vol, LithUnwrap
Known Bugs     : If anything, I didn't see it.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.
Thanks to the community for the enthusiasm that I need to continue.

================================================================
Individual Thanks On This Car
================================================================
Car made by Polyphony Digital
Myself for the wheels
Thanks to Polyphony Digital for Gran Turismo 2
Thanks to Oleg for ZModeler and specifically the flawed GT2 importer
mkreations for GT2Vol (on this page: http://www.geocities.com/mkreations/files/)
Other people for stock R30 pics
Rick Brewster for the awesomeness that is Paint.NET *very good for making texture sheets*

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site!
