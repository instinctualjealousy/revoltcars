================================================================
Car Information
================================================================
Car Name  : Blitz ZZII
Car Type  : Repaint with some 3d mods
Folder	  : ...\cars\bzzII
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 48 tops
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
My first repaint, in, uh, forever. Has an "engine" I built in GMax, 'tis just a rectangle with some extruded edges. I deleted the normal wing, and drew some faces to make an NSX style wing on the back. This is the car I built "Adamodell's Wheel Mesh V4" for. Has dark blue front lights, a new tuner bumper, new rear lights, Blitz logos on the side and wing, and a new white paintjob with carbon fiber hood. I stole the engine idea from MOH's Delta S4. Almost all the modified textures came from pictures of real cars, heavily modified to suit the color and what-else of the other parts and mesh itself.

Very unstable params at low speeds, so keep up the pace, and race only on wide open tracks like GP1.

Also modified the UV slightly to suit some higher res objects and stuff.

Hulscaled hul as well.

================================================================
Construction
================================================================
Base           : Tommy Kaira ZZII by Polyphony Digital
Poly Count     : Slightly less than the stock ZZII for the body, around 288 polies for each wheel.
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, Chaos Tools (keep forgetting to mention Chaos), LithUnrap, FCE Finish to fix the normals (an NFS program)
Known Bugs     : Same as the stock ZZII.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

A long thanks list:
Thanks to the community for the enthusiasm that I need to continue
Thanks to Aeon for constructive criticism
Thanks to Manmountain for "just being there"
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to someone I don't know for Lithium Unwrapper
Thanks to zipperrulez for waiting

================================================================
Individual Thanks On This Car
================================================================
Car made by Polyphony Digital
Myself for the wheels (wheel textures internet)
Thanks to Polyphony Digital for their high-detail low-poly models
Thanks to Oleg for ZModeler and specifically the c?o importer
Rick Brewster for the awesomeness that is Paint.NET *very good for fancy pics, and texture sheets alike*

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell