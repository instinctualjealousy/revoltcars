Folder: cars\Mang\car.viv
Number: 34
more cars: www.kcendra.com/nfsbolide.htm