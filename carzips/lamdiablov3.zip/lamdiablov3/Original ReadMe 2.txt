================================================================
Car Information
================================================================
Car Name  : Lambo Diablo 6.0 SE (Version 2)
Car Type  : Conversion\Repaint (hardly a repaint, lol)
Folder	  : ...\cars\lamdiablov2
Install   : Unzip with folder names on to the main Re-Volt folder
            Damn, we haven't upgraded to self-extracting archives yet!
Top speed : Updated to around 46
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://www.freewebs.com/adamodell/ (not updated, too much of a hassle)

================================================================
Car Description
================================================================
Addition: 
Fixed front lights (made them 3D, like they should be), added some gold to the front Lamborghini logo, screwed with the center-of-mass, widened the body by 1.1%, used some of scloink's highly superior wheels, accentuated some of the body lines, made the parameters have a little more personality, RVCentered the body, made the rear wheels larger than the front (like real life), positioned the wheels way further out, etc. Can't remember what else... (it's actually late 2007 lol)

Original:
Conversion of Ryuji Kainoh's Diablo, amazed it hasn't been released yet (it's the middle of 2007 lol)

================================================================
Construction
================================================================
Base           : NFS4 model (Ryuji Kainoh) converted by me
Poly Count     : approx. 700, about +800 for all 4 wheels, total approx. 1500
               : Looks quite sexy for the low poly count :P
Editor(s) used : Paint.NET, RV Minis 5, Chaos Tools
Known Bugs     : Absolutely none, NOW ANYWAY!

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: How about some other colors? As always, I suck at custom colors.

================================================================
Where to get this CAR
Websites: RVZT
