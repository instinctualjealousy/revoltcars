================================================================
Car Information
================================================================
Car Name  : Lambo Diablo 6.0 SE (Version 3, took me 3 tries to get it right)
Car Type  : Conversion
Folder	  : ...\cars\lamdiablov3
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Updated to around 46
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://adamodell.byethost14.com (just as old as ever!)

================================================================
Car Description
================================================================
Addition: 
Multiple color possibilities, made car slightly more narrow (92%), removed doublesiding because Ryuji cars hate that, body centered at 0,0,0 and a hulscaled hul is included. Parameters haven't been changed because I like these. Hopefully this conversion in the eyes of the people can compete with the level of class that is The Me and Me. I waited too long to fix it up. I used layer masks split it up into a paintable layer much like the one Aeon made for the Ford Puma, another car that needs a bit of fixing.

These painting sheets are not included with the RVZT release. As always my newest wheel mesh at the time is used on this model.

Original:
Conversion of Ryuji Kainoh's Diablo, amazed it hasn't been released yet (it's the middle of 2007 lol)

================================================================
Construction
================================================================
Base           : NFS4 model (Ryuji Kainoh) converted by me
Poly Count     : approx. 700, about 258 per wheel
               : Looks quite sexy for the low poly count :P
Editor(s) used : Paint.NET, RV Minis 5, Chaos Tools, LithUnwrap
Known Bugs     : Well since I said there were none on version 2, I better shut up now.
================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh, but heres other thanks.
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: I've finally figured out custom colors, so Aeon is not required! :p

================================================================
Where to get this CAR
Websites: Re-Volt Zone Tracks and my new site
