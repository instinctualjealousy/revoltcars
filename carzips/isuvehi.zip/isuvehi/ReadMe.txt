Turn word wrap on if you're sick of scrolling.

================================================================
Car Information
================================================================
Car Name  : Isuzu VehiCROSS
Car Type  : Conversion
Folder	  : ...\cars\isuvehi
Install   : Dump this car's folder into cars. That or, do the RVZT way, drag cars into "Re-Volt".
Top speed : Around 46 for DSL_Tile's params set- much lower for mine, around 38 mph
Rating    : Professional (Tile's params are arguably SUPER Pro)

================================================================
Car Description
================================================================
This car utilizes the same ideals as my Stagea conversion, except one thing. One notable thing- the parameters. I've decided the Stagea is as far as I can go on the "perfect" handling train. Tile has definitely delivered on some WILD parameters. These are the default parameters. As unneutral as they are- and as "love it or hate it" as they are- they are the default parameters. They handle nothing like my previous cars. Not even the other one Tile did parameters for. Quick, hoppy, in control yet out of control is what to expect of his work. It's too fast for the stocks, definitely. But if you want a more neutral parameter set, use mine. Mine were influenced by Manmountain's use of inertia to handle things, among other experiments. It feels notably different from my previous work, yet handles oddly good. The only thing with my params is the car will spin out a little bit more when you hit ramps and the like from flat surfaces. It's hard to explain. So when you're getting ready to drive up something, be careful. It might be a few of the oddball settings I used, even. But I like it- it keeps you on your toes.

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh
Editor(s) used : Paint.NET, ZModeler 1.07b, RV Minis 5, prm2hul, Car::Load
Editor(s) ditched : hulscale, Chaos Tools set (got an XP VM if I need to use Chaos Tools, if I must)
Known Bugs     : Sliding out on flatland/incline transitions if you're doing a tight turn. If that's a bug.

================================================================
You've seen it before... thank you all!
================================================================
DSL_Tile for keeping the Re-Volt love strong and making the main parameters for this car
AGT for having the coolest name of all (ALMIGHTYGodofTitans)
Ryuji Kainoh for generally knowing what the hell he's doing (I wish his site still existed)
Jigebren and KDL for making my job much easier (prm2hul/Car::Load)
Chris Elston for being my bestest friend ever, I love him, no homo (I hate gender double standards)
MOH for generally owning everyone else
Rick Brewster: for being sponsored by Microsoft and somehow not sucking (I <3 PDN)
Oleg M. for ZModeler 1.07b
Manmountain for having a cool name and being the main influence for my set of car parameters (to the point of me checking out his parameters and seeing how he did it)
And I'm sure there's a bunch of people I'm forgetting, so please pat yourselves on the backs (I'm not being sarcastic)

In the words of one of my favorite friends:
Danku. :3

And as an extra thanks- for making the recreation of my site possible:
RVZT, and the people who helped it exist throughout this time
Cat, for having a couple of my files backed up
Box.net, for me having some of my car installers uploaded to it
Mediafire, for having other slim pickins uploaded to it

================================================================
Copyright
================================================================
Do what you wish with this car, I ain't gonna be your personal nanny. Ryuji won't be, either. He's lenient and so am I. What kills communities like this is "rights" and the "mine mine mine" attitude of creators. Most of Re-Volt community understands this, and is pretty lax, thankfully. Let's keep the laxness up, it is what makes this community better than... that other game's community! While I think it is right to state who did what, people deserve credit after all... it isn't right to treat your stuff like a horny dominatrix. Let stuff be free.:)

================================================================
Oh car, where art thou?
================================================================
My new site is http://adamodell.co.cc/
Another URL for it is http://adamodell.web44.net/
There's always RVZT as well.