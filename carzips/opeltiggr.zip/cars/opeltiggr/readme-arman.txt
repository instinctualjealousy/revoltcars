Opel Tigra

Wieder ein Opel von Winz.Der Opel Tigra.Als Grundmodell habe ich den Tigra Steinmetz 
von Arman(arman@atlas.cz) verwendet.Netterweise erlaubt er es jedem,das Auto zu ver�ndern,wenn man ihn erw�hnt.
Die Karosse wurde �berarbeitet(neue Dachpartie u.a.)und das Corsa-Cockpit von Joseph Fernando(seppimnet@compuserve.de)
eingef�gt.



Installation:       Car.viv      nach  "..\..\NFS\data\cars\otig " entpacken
                                    Achtung  Seriennummer anpassen!!!

 Tools:
                                                       CarCad
                                                       NFS Wizard
                                                       VIV Wizard
                                                       FCE Tweak
                                                       Ulead Photo Plus
                                                      

Dieses Auto ist frei kopierbar,d.h. man darf es jedem weitergeben.





winzcom@gmx.de

http://nfs-opel.2XS.net