**************************************************************
***    N F S   C O N V E R S I O N S   U N L I M I T E D   ***
***                                                        ***
***       Original Need for Speed 6: Hot Pursuit II        ***
***                    Converted to                        ***
***        Need For Speed III: Hot Pursuit Format          ***
***                         by                             ***
***                     Viper Jay 5                        ***
***							   ***
**************************************************************
***              "Ferrari 550 Barchetta"                  ***
**************************************************************
***                 CAR FILE INFORMATION                   ***
**************************************************************
*** Car Folder Name  : BAR7                                ***
*** Car Serial #     : 8                                   ***
*** Class            : A                                   ***
*** Date Converted   : 7/11/04                             ***
*** Dash Included    : Yes - Stock EA F50                  ***
*** Sound Files      : Generic                             ***
***                                                        ***
*** Carp File        : I've incorporated a carp file which ***
***                    allows for fairly decent handling   ***
***                    at all speeds.                      ***
***                                                        ***
*** Multi-Language Support:British, English, French,       ***
***                        German, Italian, Russian,       ***
***                        Spanish and Swedish.            *** 
***                                                        ***      
**************************************************************
***                 CAR FILE INSTALLATION                  ***
**************************************************************       
***                                                        ***
*** Place the "BAR7" in your NFS IV/Data/Cars Folder and   ***
***         select car from your in-game menu.             ***
************************************************************** 
***               CAR EDITING PROGRAMS USED                ***
**************************************************************
- Zmodeler V1.07b 	by Oleg                            ***
- NFS Wizard 		by Jesper Juul-Mortensen           ***
- VIV Wizard 		by Jesper Juul-Mortensen           ***
- FCE Center 		by Addict                          ***
- NFS Car Cad 		by Chris Barnard                   ***
- MS Paint		by Microsoft                       ***
**************************************************************
***           MODIFICATIONS MADE FROM ORIGINAL             ***
**************************************************************
*** NOTE: Not all modifications may be applicable          ***
***                                                        ***
*** - Parts Fused, Car.Fce and TGA Files converted         ***
*** - Dummies Added, Renamed and Relocated                 ***
*** - Carp, Sound and FEDATA files compiled                ***
*** - FEDATA Logo and Dash Added                           ***
*** - Screenshot compiled                                  ***
*** - * Possible Interior, Driver and other parts added    ***
*** - * Possible Window Polygons removed for better view*  ***
*** - Possible additions of my own parts/textures          ***
***                                                        ***
**************************************************************
***               CREDITS AND DISCLAIMERS                  ***
**************************************************************
***                                                        ***
***      You are allowed to use the parts and textures     ***
***   PROVIDED YOU GIVE ME CREDITS ACCORDINGLY NOT ONLY FOR***
***   THE CAR CONVERSION AS A BASE FOR YOUR WORK BUT FOR   ***
***    ANY PARTS, TEXTURES OR PERSONAL MODIFICATIONS OF    ***
***   MINE WHICH YOU MAY CHOOSE TO USE AND FOR WHICH YOU   ***
***      MUST OBTAIN COMPLETE PERMISSION FIRST !           ***
***							   ***
***    Special thanks to Azrael for having provided the    ***
***      RGB Portion of the TGA files which made the       ***       
***              conversion so much easier !               ***
**************************************************************
***                                                        ***
***                  ***FINAL NOTE***                      ***
***                                                        ***
***       Thank you for downloading my conversions !       ***
*** I sincerley hope you enjoy playing with this car as    ***
***              much as I had converting it !             ***
***                                                        ***
***                   Respectfully,                        ***
***                    Viper Jay 5                         ***
***                                                        ***
**************************************************************
***   N F S    C O N V E R S I O N S   U N L I M I T E D:  ***
***   NFS PURSUIT CAR CONCEPTS/ELECTRONIC ARTS CONVERSIONS ***
***                     founded by                         ***
***                    Viper Jay 5                         ***
*** Email     : Shubunkin1960@hotmail.com                  ***
*** Homepage  : http://www.nfscars.net                     ***
*** Staff Position: NFSCars Administrator                  ***
***                "NFSCars "Copper"                       ***
***                                                        ***
**************************************************************

