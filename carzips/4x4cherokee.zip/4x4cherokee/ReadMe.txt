================================================================
Car Information
================================================================
Car Name  : 4x4 Jeep Cherokee (from 4x4 Evo Free Edition)
Car Type  : Conversion with sum UV stretching
Folder	  : ...\cars\4x4cherokee
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 39ish (observed)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
My second 4x4 Evo conversion, has a stance of a Professional Level 3 car in 4x4 Evo with it's big wheels and high ride height, a welcome change from BurnRubr's style of lowering the car to a Re-Volt like ride height. Excellent params tweaked by Manmountain that accurately portray the feel of a high-riding offroader meant to do justice to the dirt and bumpy terrain alike. Textures quite low-res, but I didn't remap the car, I just stretched the current mapping. So some things will be really low res like the front lights. I resampled them the best I could in Paint.NET, so no yelling about it. The wheels were actually converted from 4x4 Evo, rather than look-alikes. If ya want higher resolutions, get the effing source of Re-Volt and make it process 512 pixels a direction.

================================================================
Construction
================================================================
Base           : Jeep Cherokee mesh from 4x4 Evo by Terminal Reality
Poly Count     : Not many
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, Chaos Tools (keep forgetting to mention Chaos), FlyRawGUI, and PodView , and also Lithium Unwrapper (thanks Aeon for the tip on this wonderful prog)
Known Bugs     : Remapped conflicting mappings, so nothing really glitchy about that.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

A long thanks list:
Thanks to the community for the enthusiasm that I need to continue
Thanks to Aeon for constructive criticism
Thanks to Manmountain for "just being there", and doing params for this car
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to someone I don't know for Lithium Unwrapper
Thanks to zipperrulez for waiting

================================================================
Individual Thanks On This Car
================================================================
Car made by Terminal Reality
Wheels made by Terminal Reality (stretched a bit with RV-Sizer)
Thanks to KC for providing a legal free version of 4x4 Evo
Thanks to Oleg for ZModeler and specifically the SMF importer
Rick Brewster for the awesomeness that is Paint.NET *very good for fancy pics*

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell