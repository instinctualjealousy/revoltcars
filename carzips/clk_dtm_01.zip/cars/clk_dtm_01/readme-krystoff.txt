Mercedes CLK DTM 2001 for Need for speed IV

Title          : Mercedes CLK DTM 2001
Car            : Mercedes CLK DTM 2001 (SN:27)
File           : Clk01.zip
Version        : 1.0 (Upgrade Feature : No)
Date           : Jul 2003

Author         : Krystoff
Email          : dugourd.christophe@wanadoo.fr

Used Editor(s) : NFS Wizard 
               : Z Modeler 1.07b
               : PaintShop Pro 7

Thanks	       : Codemaster (Toca Race Driver) for the basic car (3d and texture)
__________________________________________________________

Installation : Put the "car.viv" in "Data\Cars\Cl01".           