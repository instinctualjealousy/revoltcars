
  V           V  W         W
   V         V   W    W    W
    V       V    W    W    W
     V     V     W    W    W
      V   V      W    W    W
       V V        W  W W  W 
        V           W   W

  -----------------------------------------

  Volkswagen Golf Variant

  -----------------------------------------


  Cars Name:                      VW
  Model:                Golf Variant
  Class:                           A
  Damage:                        Yes
  


  Author's Name:               Ladis                          

  E-Mail Adress:    cars@l-tuning.de

  -----------------------------------------
   
  INSTALLATION 
    
   
  Create a VwGv Directory. Copy all
  Files in it!
  Just put the VwGv in your NFS 4 
  Cars Directory.  
  Normal: C:\PROGRAMMS\ELECTRONIC ARTS\
              NEED FOR SPEED\DATA\CARS\

  Put the VwGv.QFS in your VidWall 
  Directory.
  Normal: C:\PROGRAMMS\ELECTRONIC ARTS\
              NEED FOR SPEED\DATA\FEART\
              VIDWALL\
  
  Problems? Mail to me: cars@l-tuning.de

  -----------------------------------------

  VW Golf Variant 
  is made by:                        Ladis
                                 
  Beginn of construction:       08.03.2001
  End of construction:          10.03.2001

  Based on BMW M5  

  -----------------------------------------

  PLEASE DON'T STEAL OTHER PEOPLES WORK!




  (C) Copyright by Ladislaus Schulmeister 
  