================================================================
Car Information
================================================================
Car Name  : Wiegert Vector W8: Anime Ver.
Car Type  : Repaint
Folder	  : ...\cars\vectorw8Ani
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 46kph or mph?? or more?? 
Rating    : Pro, PRO!

================================================================
Author Information
================================================================
Author Name : Robenue aka Kumachan
EMail       : info@kchanshinobi.vndv.com
Homepage    : http://kchanshinobi.vndv.com
================================================================
Car Description
================================================================
A repaint of a conversion adamodell made for Gel, I just added the touch of Anime to make it feel more modified in a way.

================================================================
Construction
================================================================
Base           : Wiegert Vector W8 Twin Turbo by Polyphony Digital
Editors: Photoshop CS2
================================================================
Thanks And Accolades
================================================================
"Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim."
- adamodell

Robenue:
Thanks for downloading my repaint.. I thank Adam for letting me repaint this.. Even though i think i didnt even ask him.. only jk. Anyway racers this is pretty much just a skin no perform modification just a repaint. The perform are prettty good already. Execept for the landing. Adamodell sorter slipped on that one.

Later on I will start converting again, I just really hope people will remember me as a converter. I have quite a few cars coming to mind everyday. 


================================================================
Individual Thanks On This Car
================================================================
...

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
         http://kchanshinobi.vndv.com/
        http://kchanshinobi.darkbb.com [ FORUM ]