if you have any problems email me:soemyat@hotemail.com




by unzipping this zip file you agree to these terms:

you may not do anything with this car other then use it for nfs4
if you wish to reuse this mod to make another car pls email me if not start from scratch

create a folder name called "nasp"
in C:\Program Files\Electronic Arts\Need For Speed High Stakes\Data\Cars
------------------------------------------------------------------------
car id: 	nazc
car serial no:	26
car name: 	italdesign nazca c2 spider
class:		A

This car is made for Jessica
