CAR: 2002 Acura Integra

AUTHOR: SYC

(SYC Motors) syc.nfsracer.com

FEATURES: Damage, Driver, Vidwall, Cockpit

Edited BMW M5 model and all new texture.

PERFORMANCE: Realistic