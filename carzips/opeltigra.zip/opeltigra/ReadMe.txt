================================================================
Car Information
================================================================
Car Name  : Opel Tigra
Car Type  : Conversion
Folder	  : ...\cars\opeltigra
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 43 tops
Rating    : Pro (but almost too slow for this rating)

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
I was inspired by the Tigra on RVZT to convert a stock one. Here it is. My second 
front-wheel drive conversion, it's handling doesn't have that much personality. But the 
stability is more than up, and should be great for tight tracks like Sakura. Dropped the 
hul because I wasn't satisfied with it.
And also, I have an OCD about some things. I don't want to have to go back and hulscale 
every effing one of my cars. I've already RVCentered them all!

================================================================
Construction
================================================================
Base           : Opel Tigra mesh from Winz
Poly Count     : I don't know, I don't care, you shouldn't either. It's 2008, these 
polycounts shouldn't lag ya
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b
Known Bugs     : Miniscule to nothing. Had to be doublesided. Remapped the seats and roof 
due to odd errors and bad coloring!
================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading 
this car (and many other way better ones I might add) is what is keeping the community 
alive even through the bankruptcy of Acclaim.

Thanks to the community for the enthusiasm that I need to continue.
Thanks to Aeon for constructive criticism, and joining my forum
Thanks to Manmountain for "just being there"
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to Oleg for the relatively easy UV mapper in ZModeler

================================================================
Individual Thanks On This Car
================================================================
Car made by Winz
Myself for the wheels (wheel textures Winz)
Thanks to Oleg for ZModeler
Rick Brewster for the awesomeness that is Paint.NET
Thanks to the GIMP team, helped me get the transparency on the car-color maker high enough 
to have vibrant colors, thank you layer masking!

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell
