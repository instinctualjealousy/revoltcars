================================================================
Car Information
================================================================
Car Name  : Veilside GT-R32 CI
Car Type  : Conversion
Folder	  : ...\cars\r32veil
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Sorta 50
Rating    : Pro

================================================================
Author Information
================================================================
Author Name 	: Adamodell
EMail and MSN	: metallicafan128@gmail.com (Find me on MSN!! I wanna talk!)
Homepage    	: http://adamodell.vndv.com

================================================================
Car Description
================================================================
I actually attempted to tweak the params to be a tad unique on this one, but they are relatively the same to the 968. I converted this car because there were no R32's available for Re-Volt, at least to my limited knowledge.

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) RV-Sizer, and a couple others
Known Bugs     : Good luck finding them. Again. And again!

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldn't be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

This car is dedicated to my best friend Shawn Emerson, since I now plan on dedicating cars to people. Hmm, maybe I should reveal who I dedicated the 924 to, well, the initials are DJ, and they aren't of the gender you would think with those initials. Let's just say I'm obsessed with them, beyond all belief.
Oh, and Shawn Emerson knows the answer, among about 5 other people. Just ignore this and race this car, lol.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh for the main body mesh!
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Myself for the wheels

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: RVZT and my site, and probably a box.net link on RRR