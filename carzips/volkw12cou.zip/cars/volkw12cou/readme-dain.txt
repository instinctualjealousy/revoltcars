**********************************************************************************
VOLKSWAGEN W12 COUPÉ FOR NEED FOR SPEED 3

Car			 Volkswagen W12 Coupé v1.0 (based on Mercedes CLK-GTR)
File 			 Vw12.zip (includes car.viv, 12_00.qfs, readme.txt)
Release date		 November 2001
Author			 DaiN
E-mail			 danielmodena@hotmail.com

Used editors 		- VIV Wizard v0.8 by Jesper Juul-Mortensen
                     		- NFSIII Car CAD v1.4b by Chris Barnard
			- FCE Finish v2.00 by Klaus Heyne
               		- PaintShop Pro 5J

Special Credits	 	- Kremit, for using his spoiler
			- Martin Beaulieu, for using his rims from his W12
			- EA, for making the CLK-GTR and letting me use it as a base for 
			  my Volkswagen W12
Installation
 1. Go to the main NFS folder (The one wich includes NFS3.EXE).
 2. Go to the subfolder called GameData\CarModel.
 3. In there, make a new folder called 'Vw12'.
 4. Put the included files from this ZIP-file in there.
 5. Play NFS III and have fun!

Slide
This car comes with a slide, but it's not necessary to install it. 
Also, you can only install the slide if you have the full installation 
of NFS. For the ones who don't know what a slide is, it's
the picture of the car you'll get when you load a race. Here's how to
install:    		
 1. Go to the main NFS folder (The one wich includes NFS3.EXE).
 2. Go to the subfolder called FeData\Art\Slides.
 3. Put the 12_00.QFS from this ZIP-file in there.
 4. Play NFS III and have fun!

Permissions:
You may not modify this car. If unchanged, this car can be distributed FREELY.
If you use this car for your own website, please be so nice and tell me where it is.
