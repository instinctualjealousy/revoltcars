1988 Callaway "Sledgehammer" Corvette for Need for speed IV

Title          : Callaway Sledgehammer
File           : sledgehammer.zip
Version        : 1.0 (Upgrade Feature : NO)
Date           : March 1, 2002

Author         : Sniper
Email          : thom_dupuis@hotmail.com
Homepage       : http://sniper.totalnfs.net

Used Editor    : ZModeler
               : 3D Studio Max
               : NFS Wizard v0.5.0.79 
               : NFS Car CAD v1.5b 
               : FCEFinish v2.0
               : NFS FCEcenter
               : PaintShop Pro and Adobe Photoshop
Thanks.
___________________________________________________________

Installation : Put the "car.viv" in the "Data\Cars\sled" folder.
               and the "sled.qfs" in the "Data\FeArt\VidWall" folder.

Have fun !!

Please do not upload this car or any of my cars to any other websites!
Unless you get my permission by e-mail first.

Visit www.Racerplanet.com for other great NFS sites!!!