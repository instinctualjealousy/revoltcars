                       PRESTONFS DEALERSHIP

 Special thanks to
 Adamodell for helping me with the shading

To the proud owner of this cute little car custom built by Prestonfs Autos,

Congratulations on the download of this remarkable design!

Story: My brother's favorite cars were the clockworks and Phat Slug, so I
fused the two cars together and this was the end result!

Driving tips: Take extreme caution as to not flip the car over because
it is vulnerable to other Re-Volters who want to wreck him.
This is awesome in the curves as we put our main focus on him to have
our patented SUSPENSESHOX (copyright) Into him to allow him to stop on a dime,
then pull a wheelie faster than you can say: Phat Slug!

Bugs: No springs, and a bit of the wheel texture stained the bumpers.

DISCLAIMER: we are not responsible for any sort of death, injury, or seizures
behind the wheel or under it whatsoever!

(copyright 2008)