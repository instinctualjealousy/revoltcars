                       ========MITSUBISHI EVOLUTION VIII========
	               (NEED FOR SPEED UNDERGROUND 2 CONVERSION)

FOR INFO ON MY FUTURE PROJECT, PLEASE VISIT: 

http://www.nfscars.net/forum/showthread.php?t=15730&page=1&pp=40


DEDICATED TO A VERY CLOSE FRIEND OF MINE. THIS ONE IS FOR YOU SAL. SORRY I COULDNT FINISH IT ON 
YOUR BIRTHDAY, BUT I AM SURE IT WAS WORTH THE WAIT, : P.

Serial Number: 8
Class: AA
File: evo8.zip
Base Author: EA
Conversion, Tuning, & Modelling: Owl
Email: fury008@hotmail.com
Date Of Release: 01/01/2006 (HAPPY NEW YEAR!!! :D)

==============================================================

Used Editors:

-Z modeler
-Car CAD
-FCE Finish
-VIV Wizard
-PSP 7
-Adobe Photoshop
-Fce Centre
-Bintex
-Nfs Wizard
-BIN2ASE
-3d Exploration
-3D Win
-MS Paint


=============================================================

Description:

-Texture creation and mapping from scratch
-Normals editing
-Appropriate dummies added
-Car fedata files complied
-Car showcase and vidwalls created
-CARP file compiled
-Some modelling of parts done by me



=============================================================

Features:

-11 525 Polys
-Avaliable In Factory Colors
-Window Tints
-Colored exhuast tips, spolier and other parts
-Precision damage model
-3d engine, doors, and boot
-Covertible(hood)
-Showcase
-Custom Nfs Number Plate
-Custom NFSUG2 Sounds by momaka (a must hear!!!)
-Vidwall
-2 Preformance files
-Dash View (AT LAST!!!)
-Multi Language Support(Including Showcase)

There is a dash this time : P, i took the time out to perfect it.
============================================================

Installation:

-HIGH POLY PATCH REQUIRED (FOUND ON ALMOST ALL MAJOR NFS CAR SITES)
-Put "car.viv" in NEED FOR SPEED HIGH STAKES\DATA\CARS\EVO8
-Put all the files in "Showcase Art" in NEED FOR SPEED HIGH STAKES\DATA\SHOWCASE\ART
-Put all the files in "Vidwall" in NEED FOR SPEED HIGH STAKES\DATA\FEART\VIDWALL

This car comes standard with a realistic preformance file. If you wish to change that, unpack
the car.viv using NFS Wizard and replace the original CARP file with the one in the "Extreme
Preformance" folder.

-To get the maximum out of this car:
-INSTALL ALL FILES PROPERLY AS STATED ABOVE OR YOU WILL NOT BE ABLE TO VIEW THE SHOWCASE!!!
-Use 1024 x 768 resolution or more
-Put all graphics details to full
-Use my Neon Underglow Patch (Found on www.nfscars.net)

============================================================

Thanks:

ALOT of people to thank this time:

Firstly a HUGH thanks to my good friend KARL "GEORGE" KELLER for sticking with me all the way and
providing me new and innovating ideas. For finding all the flaws in my car and helping me improve
them. Thanks George, this car would not have been possible without you, and thank you for 
teaching me the art of perfection. Good luck with your IS300 and Impreza.
 
-EA : Base Car & Textures
-Martin Leps : Driver(interior and exterior), Seats, Steering, Single Wiper & some textures.
-momaka : For the KILLER engine sounds, they were simply stunning man. Greatly appreciate your 
help, any time you need any help in return, you can count on me. Thanks man.

All the guys at the NFSRELOADED team:

Aqeel: For starting it all
BMWDude: For providing us with an official RELOADED website. Thank you so much.
Max Prez: For your positive support through all my projects. Thanks Max, you are a great guy. Any
help you need with your projects, dont hesitate at all to ask.
Racer X: For your support and comments.
NJ (XJ 220): For your support and for providing us with the killer Porsche, great work, very
impressive modelling. Thank you.
DVDidko.FCE: For your support and ideas when i got stuck, cheers mate.
momaka: Your kind support and amazing sounds and determination to help me. Only a few
execptional people would do that. Thanks man, you have a friend for life. Good luck with Gotham
City, although i know you will succeed.
Rich P: Support

All the guys who posted at my thread for their help and ideas:

J Design, Max Prez, DVDidko.FCE, deMuderdoll, Christian Xaver, Benny, RiCk Fx, and LeastWanted.

Sorry if i missed anyone

============================================================

Final Word:

Out of all the cars i have done, this one was the biggest struggle. I went all out on this car.
Put in enough effort in the process too. This one after my Skyline is the first one to have a 
dash view. The dials are modelled to give maximum detail. I used 256*256 textures this time so 
no quality is lost. The engine is very nicely textured since i textured it from scratch rather 
then using EA textures. Love the chromed carbon fibre parts. Very pleasing end result there. 
Also put a 3D boot and doors so the car has good damage effects. I tried a new technique with 
window normals, and managed to get killer reflections on them. The car poly count caused enough 
misery. I had to put the detail down considerably for it to run smoothly ingame. The car kept 
crashing the game, and that really pissed me off. I even came to the stage where i was not even
gonna bother doing it for NFS 4, but i am glad that i finally managed in the end. Shockly my 
last car was 12008 polys and that ran fine, where as this one is 11525 and if i go any higher 
the game will crash. Although its a conversion mainly, i spent about 3 months on this car, 
so you can imagine the hard work that went into it. This car is bug free and has no flaws as 
far as i know, but if anyone finds any, please let me know so i can improve for my next car.

Sadly, this is my last car for NFS 4. The fact that detail can only be added to a certain given
limit if pissing me off now. I could have made this car ALOT better if i was bugged down by the
NFS 4 poly limit. I am now moving to NFS 6 and other racing games. So from now on, you people 
will be seeing all my work for NFS 6 only. I am glad that game has no poly limit, i can add 
detail freely. The only way i may do NFS 4 cars again is if you guys want me to. If you really 
enjoyed my cars for NFS 4 and would like me to continue, email me at fury008@otmail.com, and i
may still do an occasional car for it. Either that or if momaka manages to make Gotham City for
NFS 4, :D.


Thank you for taking the time out to read this and i hope you enjoy playing with the car because 
i sure had fun making it. :)


-NO MODFIFCATION CAN BE MADE TO THIS CAR...PERIOD. I WANT IT LEFT AS IT.
-NO CONVERSIONS CAN BE MADE TO OTHER GAMES. THIS CAR MODEL IS DONE FOR NFS 4 ONLY!!! I HAVE MADE
ANOTHER MORE DETAILED MODEL WHICH IS TO BE USED FOR CONVERSIONs. EMAIL ME OR PM ME AT NFSCARS.NET
IF YOU WOULD LIKE TO MAKE A CONVERSION AND I WILL SEND YOU THAT MODEL.

I hope that all of you can respect the above.

THANKS FOR DOWNLOADING AND ENJOI


 ====  =        =  =
=    =  =      =   =
=    =   = == =    =
=    =    == ==    =
 ====	  =   =    =======
  	

IF YOU ARE HAVEING ANY PROBLEMS WITH CAR INSTALLATION, DO NOT HEISTATE TO CONTANE ME, MY EMAIL IS
FURY008@HOTMAIL.COM.

FOR INFO ON MY FUTURE PROJECTS, PLEASE VIST: 

http://www.nfscars.net/forum/showthread.php?t=15730&page=1&pp=40