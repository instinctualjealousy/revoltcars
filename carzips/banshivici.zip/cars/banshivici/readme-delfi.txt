--* X-Box Wheel MOd *--
       By Delfi

To install:
All you have to do is replace the wheels.txd and wheels.dff in the models/generic folder of you vice directory.
Have fun!


Fixed X-Box wheels mod by Suction Testicle Man / Delfi
------------------------------------------------------

Just replace the wheels.dff and wheels.txd files in the models/generic folder in your Vice City directory.

The wheels do not flicker black now like in Delfi's original.

Suction Testicle Man