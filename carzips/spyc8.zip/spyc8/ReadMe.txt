================================================================
Car Information
================================================================
Car Name  : Spyker C8 Laviolette
Car Type  : Conversion
Folder	  : ...\cars\spyc8
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Really fast is all that you need to know :P
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell (newly updated again)

================================================================
Car Description
================================================================
Conversion of DaiN's awesome Spyker C8 Laviolette. It was only released for Need for Speed 3 (to my knowledge).
It is very low poly, with no interior. But it still is beastly, don't you worry.
I had to remap the wheels AGAIN! for this car, but it was worth it. I used my huge discovery from the W12 again. I tried to change up the params a bit.

================================================================
Construction
================================================================
Base           : NFS3 model (DaiN) converted by me
Poly Count     : The wheels are 258 polies each, made by me, don't know about teh body
               : 
Editor(s) used : Paint.NET, RV Minis 5, Chaos Tools, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) ntdll.dll!!?!?!
Known Bugs     : Absolutely none to what I know.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldnt be as it was today. You downloading this car (and many other way better ones I might add) is what is keeping the community alive even through the bankruptcy of Acclaim.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh and myself for the wheels, but here is other thanks:
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Chaos for Chaos Tools
Rocket for NFSFCEConverter

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

Repaint suggestions: NOT GREY.

================================================================
Where to get this CAR
Websites: RVZT and my site, as always, never will change
