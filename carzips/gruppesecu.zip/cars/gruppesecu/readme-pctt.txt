Power City Tuning Team presents:
SECURICAR FROM Grand Theft Auto 3
by Power City Tuning Team

INDEX:
(1) Cars Features
(2) The Authors
(3) Contact

CHAPTER #1

No way to robber it� it�s heavy and though!

CHAPTER #2

Converting, Modeling and Damages: Lawrence
Tuning: M3T4L

CHAPTER #3

If you want to contact us just e-mail us!

Lawrence: wlaw@inwind.it
M3T4L: gniccolini@tiscalinet.it
Power City Tuning e-mail: pctt@libero.it

WARNING
YOU MUST NOT MODIFY ANY PART OF THAT CAR WITHOUT OUR PERMISSION 
AND YOU MUST NOT POST IT TO OTHER SITES DIFFERENT THAN THE ONE'S IN WICH 
WE DECIDE TO POST IT