Porsche 968 CS for Need for speed IV

Title          : Porsche 968 CS
Car            : Porsche 968 CS (SN:43)
File           : p9cs.zip
Version        : 1.0 (Upgrade Feature : NO)
Date           : JUL 2002

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : NFS Wizard v0.5.0.79 by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 297) by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 299) by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : NFS Car CAD v1.5b by Chris Barnard
               : CAR3TO4 by J�Eg Billeter
               : NFS FCEConverter by Addict&Rocket
               : PaintShop Pro 5J

* CM_500 made 968 CS's "CARP.TXT" for my car.

Thanks.
___________________________________________________________

Installation : Put the "car.viv" in "Data\Cars\p9cs".
               and  the "p9cs.qfs" in "Data\FeArt\VidWall".

Have a fun !!