================================================================
Car Information
================================================================
Car Name  : Ferrari 456 GT Venice Estate
Car Type  : Conversion
Folder	  : ...\cars\f456e
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Don't know, don't care
Rating    : Pro

================================================================
Author Information
================================================================
Author Name 	: Adamodell
EMail and MSN	: metallicafan128@gmail.com (Find me on MSN!! I wanna talk! And just so you know I'm a much better person on MSN, just ask zipperrulez)
Homepage    	: http://adamodell.vndv.com

================================================================
Car Description
================================================================
Oh holy hypocrisy Adam! You all must hate me now because I cannot keep my word. Well whatever, be happy I did this!
I made a bet that... if Manmountain wasn't back 10 days after the 30th of December, I would release a new conversion.
I just thought I should at least make something fun out of his more than extended absence. I'm sure some will see it as as a rude move, but I wasn't intending anything negative with it. I am not sending it to RVZT until someone is back to approve the cars, there's probably already enough on hold for right now, in fact I'd make a bet half of them are lost or will be lost.

The car itself, I cannot believe it hasn't been converted yet. I won't lie, it is a weird car. Available in a few colors as always, and all the standards I had set a year ago!

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) RV-Sizer, and a couple others
Known Bugs     : Good luck finding them. Eh there might be one.

================================================================
Thanks And Accolades
================================================================
Dedicated to Manmountain, SnOoKiE, and zipperrulez. Just so you know I'm not dead. I'm sorry I had to be a hypocrite... but!
This was just for a bet. Publicity stunt? No. I have way too much of that anyway. More infamous than famous anyway, because I am too opinionated for my own good. I have changed the most I have ever changed over this last year. I hope it was a good change and not a bad one. Well... I still deliver my wording in excess. I'm not as smart as I sound.

Oh, and one more thing... where'd all the converters go?!
This is to you guys who popped up just to die right at the start. Please... XRQ, Piereligio, Sora... and any others... don't give up. And, if you can be bothered, manage your own sites as well.... it will do you good in the long run. Just don't make useless forums like I did... and NEVER declare yourself done, you're just... uh... burning bridges anyway.

If you're wondering what I am doing right now... I'm going to release my first conversion in final form for Midtown Madness 2, soon. Check it out. I'm sure you can find it if you look around on www.mm2x.com.

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh for the main body mesh!
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Myself for the wheels
The Me and Me: For helping me repair that bridge I burned so badly JUST KIDDING

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: My site, possibly RVZT. No chance on RRR since I cannot navigate that forum right now!