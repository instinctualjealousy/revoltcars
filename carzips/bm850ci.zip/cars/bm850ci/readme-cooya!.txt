
 ---------- BMW 850CSi for NFS4 ----------
 -----------------------------------------
 ------ brought into 2004 by Cooya! ------


 --Credits--


 � base car:      Yuriy Antipin and Clark

 � Wheels:        Zlatko - from his BMW M5 e34

 � side-mirrors:  Georg - from TeamBMW�s BMW M3 e36

 � new textures, interiour-design, mesh-tweakings and new colors by Cooya!


 Hi everybody!
 Although the original car from Yuriy Antipin and Clark is very old now (2001) it is still extremely
 good and a perfect base to bring it up-to-date with some today standards!



 --Changes--


 � 3D-wheels by Zlatko (thanks buddy) and highpoly 3D-mirrors by Georg (thanks,too)

 � almost completely new (or changed) photo-textures

 � completely changed interiour style (2-tone leather)

 � some minor mesh-tweakings on the exteriour and interiour and 2D brakedisks

 � completely new paintjobs including color-changing interiour and "Tobagoblue Individual"-color
  with black roof! 
  All colors are factory BMW 850CSi colors! - I spend hours to make them

- still veeeery low polycount for full-grid racing (about 3580 polys) -


 I put a lot of work in it and I think it turned out pretty good so I decided to release it.
 Feel free to modify it for your own use but ask for permission if you want to release it (as I did!)

 I don�t think you want to convert it - Krazymond made a much more detailed one for NFS6 - but I have
 nothing against it as long as you give CREDITS and don�t forget the original readme�s.

 If you have questions or want to contact me: AlexKujer@AOL.com 
 Have fun! ;-)

             Cooya!, 8.12.2004
