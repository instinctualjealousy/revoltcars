------- BMW 850 CSi for NFS4---------

Authors: 

Yuriy Antipin  	   -  AntipinYuriy@mail.primorye.ru
Clark    	   -  christoph.koepke@t-online.de

The shape and basic textures are from Yuriy, I did a lot to it to give it a finished look.

Extract the car.viv to a folder called "8csi" in your Data\Cars directory, the 8csi.qfs to data\feart\vidwall.

You can modify the car for your own use but don't have permission to release your modified version.

If you want to upload the car do it as long you don't change the content of this zip file.

If you want to convert the car contact me (Clark) first..

Enjoy the car!

Clark, 1st September 2001
