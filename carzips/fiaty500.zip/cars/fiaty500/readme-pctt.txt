Power City Tuning Team presents:
Fiat Nuova 500 for Need For Speed High Stakes
by Power City Tuning Team

INDEX:
(1) Cars Features
(2) Installation
(2) The Authors
(3) Contact

CHAPTER #1

This is the new 4.0 relase of the fantastic Italian classic car Fiat Nuova 500, this new version includes damages, vidwall and upgrades. Clear windows, animated driver, customizable plaque are also available. Even a totally new dashboard has been added. This car has been made by Lawrence and M3T4L (aka lelenick) after long time spent in improving the style as real as possible and the performances. In fact This car (in real life) was created with a 500cc 2cyl engine able to reach 95km/h. However in this period (around 1955) customizations weren't unusual so, lot of crazy people, modified their 500 pumping it's engine from 500cc to 696cc or, sometimes, even 850 resulting a top speed of about 160 km/h. So this is why we made the new 500 upgradeable: a return to the past where the cars were true and made by intrepid men who loves their car.

CHAPTER #2

Simple, really really simple...:
copy the car.viv file in the folder ...\Data\Cars\500
and the 500.qfs file ...\Data\FeArt\Vidwall
Then enjoy driving!

CHAPTER #3

Well well well... if you downloaded the older relases you already know that the genius that build the Fiat Nuova 500 was Lawrence, but now with a friend he opened the new team called "POWER CITY TUNING TEAM". Here we'll creat only small city cars in order to create a new relase for Need For Speed... howevere here is the names:

Modeling and Project: Lawrence
Tuning: M3T4L (aka lelenick)

CHAPTER #4

If you want to contact us just e-mail us!

Lawrence: wlaw@inwind.it
M3T4L: gniccolini@tiscalinet.it



WARNING
YOU MUST NOT MODIFY ANY PART OF THAT CAR WITHOUT OUR PERMISSION AND YOU MUST NOT POST IT TO OTHER SITES DIFFERENT THAN THE ONE'S IN WICH WE DECIDE TO POST IT

THIS WORK IS COPYRIGHTED BY POWER CITY TUNING TEAM, 2001
