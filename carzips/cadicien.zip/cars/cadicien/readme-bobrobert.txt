This is the cadillac cien concept car.
 created by bob robert....Project_l147@hotmail.com


to install  put the viv into a folder, place the folder in,   nfs4/data/cars
to install the qfs pu it into nfs4/data/feart/vidwall


the interior was done with the help of Slipstreem

