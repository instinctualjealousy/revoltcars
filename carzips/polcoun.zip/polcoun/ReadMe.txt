================================================================
Car Information
================================================================
Creator	  : Ryuji Kainoh
Converter : Adamodell (Adam O'Dell), parameters by Citywalker
Car Name  : Police Countach
Car Type  : Conversion
Folder	  : ...\cars\polcoun
Top speed : 45 mph for both CW sets, my set is identical to prior released Skyline
			params-rc.txt is Citywalker's RC car params. params-rl is Citywalker's "real life" params.
			params-or.txt is the original, exact copy params from Pursuit Skyline (with offset corrections).
Rating    : Pro
Bugs      : Green coloration on bitmap that Skarma hates.
			This is totally normal and expected of a Ryuji car.

================================================================
Editors Used
================================================================
ZModeler 1.07b I think
Car::Load
Paint.NET
Kay's "PRM" tool
Autoshade
rvshade
prm2hul
Re-Volt Textures Resizer
Photoshop CC (For saving RLE 8-bit bitmaps that Re-Volt didn't hate)
PNG to 32-bit BMP for saving my 32-bit bmps for Re-Volt

================================================================
You've seen it before... thank you all!
================================================================
Citywalker for doing the parameters
zipperrulez for a little bit of testing
Jigebren and KDL for making my job much easier with all their fresh tools
Oleg M. for ZModeler 1.06f (it runs a little less worse than 1.07b on Win7, but- hard to find)

This car here has been sitting around for two years, and I have just now completed it. Haha.

================================================================
Copyright
================================================================
I don't care. Does Ryuji? Maybe. I wouldn't know.

================================================================
Oh car, where art thou?
================================================================
My new site is http://revoltcars.tk