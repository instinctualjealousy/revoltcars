				GT Design
				   by
				GT40 MK1
			email: ned_putnam@yahoo.com

				Car Information

				"Ford GT40 MKIII"
			Need for Speed IV: High Stakes

Car Folder Name: gt43
Car Serial Number: 17
Class: A
Car Information: Custom carp as close to specs as I can find,
		 tuned to most standard engine used in GT40 MKIIIs.
		 Top speed without in-game tuning is 170 mph, which is the fastest 
		 GT40 MKIIIs can normally go with a standard engine. 
		 Handling is good at all speeds. Custom showcase also included.
		 Dash Included.
		 
Poly count: 9,750

Car Installation:

Create a folder "gt43" in your Need For Speed High Stakes\Data\Cars folder and your 
Need For Speed High Stakes\SaveData\Cars and extract the car.viv file into each of them.

Showcase Installation:

Extract the files in the showcase folder inside this zip file to 
your Need For Speed High Stakes\Data\Showcase\Art folder.

Vidwall Installation:

Extract the files in the vidwall folder inside this zip file to your
Need For Speed High Stakes\Data\FeArt\VidWall folder.

Programs Used to make this car:
Zanoza Modeler 1.07b	Modeling				by Oleg
NFS Wizard		Compiling the files			by Jesper Juul-Mortensen
VIV Wizard		Compiling the files			by Jesper Juul-Mortensen
FCE Finish		Adding dummies				by Klaus Heyne
FCE Center		Centering the car			by Rocket/Addict
NFS FCE Converter	Editing colors				by Rocket/Addict
Macromedia Fireworks	Creating textures			by Macromedia/Adobe
Fshtool			File conversions			by Denis Auroux
TGA Maker		Creating TGA files			by Josh Klint

Credits:
Credits go to me for modeling and texturing.

Thanks:
Thanks to Electronic Arts for making such a great game. Thanks to Ford for making 
such an awesome car. Thanks to everybody at NFSCars.net for providing valuable 
tips that helped me improve my modeling skills and make this car look as good as I 
could make it. Thanks to the people who made the programs I used to make this car.
And special thanks to Power_Steering for making a great tutorial on modeling cars, 
you can visit it at: http://freakforspeed.sitesled.com/.

Important Notice:
You may convert this car to other games but tell me about it before you release it. 
You can contact me at NFSCars.net or by email. Also, include this readme with your release.
Another thing, don't do a bad job of it!

Copyright Information:
You may NOT sell the mesh for this car anywhere. I spent a long time on this and I am
providing it for free. If I wanted to sell it, I could. You may, however, distribute 
it for free. Ford and GT40 MKIII are copyright the Ford Motor Company; Need for Speed IV:
High Stakes and Electronic Arts are copyright Electronic Arts.

NOTICE FOR HIGH-POLY CARS

Depending on your system, you may be required to install the "high-Poly" patch which 
allows cars as high as 11k polys to be used.  To intall this patch, copy and paste 
this URL to your browsers address window 

http://rc.racerplanet.com/fileinfo.php?id=36&design=standard

Follow the instructions included in the file.
