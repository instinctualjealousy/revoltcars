================================================================
Car Information
================================================================
Car Name  : Pennzoil Skyline
Car Type  : repaint
Folder	  : ...\cars\pennzoilsky
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Around 50
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Rally leggend stiu
EMail       : rallyleggendstiu@msn.com

================================================================
Thanks And Accolades
================================================================
Adamodell to have converted this car;
RVZT where you can get this car


Hope you like it, have fun!
RLS'92