================================================================
Car Information
================================================================
Car Name  : Pennzoil Nismo GT-R GT
Car Type  : repaint
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : 46mh
Rating    : Pro

================================================================
Author Information
================================================================
By AlexFogliani
and Adamodell

================================================================
Thanks And Accolades
================================================================
Adamodell to have converted this car;
RVZT where you can get this car
and me for the texture

08/12/11