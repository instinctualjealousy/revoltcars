Gemballa Turbo GTR 650 for Need for speed IV

Title          : Gemballa Turbo GTR 650
Car            : Gemballa Turbo GTR 650 (SN:15)
File           : g650.zip
Version        : 1.0 (Upgrade Feature : NO)
Date           : JUN 2002

Author         : Ryuji KAINOH
Email          : ryuji_k@pop13.odn.ne.jp
Homepage       : http://www1.odn.ne.jp/ryuji_k/nfs3.htm

Used Editor(s) : Mrc(cartool.zip) by EA
               : NFS Wizard v0.5.0.79 by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 297) by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 299) by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : NFS Car CAD v1.5b by Chris Barnard
               : CAR3TO4 by J�rg Billeter
               : NFS FCEConverter by Addict&Rocket
               : PaintShop Pro 5J

* CM_500 made Turbo GTR 650's "CARP.TXT" for my car.

Thanks.
___________________________________________________________

Installation : Put the "car.viv" in "Data\Cars\g650".
               and  the "g650.qfs" in "Data\FeArt\VidWall".

Have a fun !!


...Formula1(1987to2002) Carset for ICR2(IndycarRacing2)...
http://www1.odn.ne.jp/ryuji_k/