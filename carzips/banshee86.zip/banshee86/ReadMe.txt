================================================================
Car Information
================================================================
Car Name  : GTAVC Banshee (from GTA Vice City)
Car Type  : Flat out no-holds barred conversion (with an "o shi-" amount of UV mapping)
Folder	  : ...\cars\banshee86
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : Fast, maybe 44ish, really tops out at 40 though
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Adamodell
EMail       : metallicafan128@gmail.com (yes I like Metallica, now shut up...)
Homepage    : http://fallingupward.net/adamodell/ (updated daily lol)

================================================================
Car Description
================================================================
The first true Vice City to Re-Volt conversion. The wheels are from the Xbox version, which has superior wheel models, and was in the pack "Xbox Wheel Mod" for the PC version of Vice City, as provided by Delphi and Suction Testicle Man (yes, that's his name).

================================================================
Construction
================================================================
Base           : Banshee mesh from GTA Vice City
Poly Count     : GTA meshes aren't known for their polycounts
Editor(s) used : Paint.NET, RV Minis 5, ZModeler 1.07b, Chaos Tools (keep forgetting to mention Chaos), LithUnwrap, TXD Workshop, IMGTool
Known Bugs     : Remapped all the parts by material as individual 3ds files and remapped them in Lithium Unwrapper, all arbitrary and perfect.

================================================================
Thanks And Accolades
================================================================
Same as before the Whole Re-Volt community wouldn't be as it was today. You downloading stuff and creating your own stuff is what is keeping the community alive even through the bankruptcy of Acclaim.

A long thanks list:
Thanks to the community for the enthusiasm that I need to continue
Thanks to Aeon for constructive criticism
Thanks to Manmountain for "just being there"
Thanks to Gaming4JC in proving that Linux doesn't suck (but isn't teh best at running RV)
Thanks to Robenue for totally giving up on making RV conversions (sarcasm)
Thanks to MOH at attempting conversions
Thanks to Sora at taking my advice and doing conversions
Thanks to Tile2 in supporting me
Thanks to The Me and Me for inspiring me to do RV cars
Thanks to Skitch and Hil for their excellent tracks...
Thanks to Crone94 for being a part of this community (same for Urne and KayTF)
Thanks to someone I don't know for Lithium Unwrapper
Thanks to zipperrulez for waiting

================================================================
Individual Thanks On This Car
================================================================
Car made by Rockstar
Wheels made by Rockstar and ported to the PC version of Vice City by Delphi
Thanks to Rockstar for the GTA series
Thanks to Oleg for ZModeler and specifically the GTA DFF importer, and also the ability to select by material, which made my job insanely easier.
Rick Brewster for the awesomeness that is Paint.NET *very good for fancy pics*

================================================================
Copyright / Permissions
================================================================
Authors MAY DEFINITELY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: http://revolt.speedweek.net
          http://fallingupward.net/adamodell