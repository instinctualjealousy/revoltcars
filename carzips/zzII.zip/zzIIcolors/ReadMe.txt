To use, open either the PSD (Photoshop, GIMP, Paint Shop Pro) or PDN (Paint.NET) and go to the Hue/Saturation layer.

Use the Hue/Saturation effect to change color with the Hue value.

Flatten and save as bmp. -Adamodell