**************************************************************
***			  				   ***
***     -= C O N C E P T   D E S I G N   W O R K S =- 	   ***
***                       -----				   ***
***          -= Viper - Tritoch - NFS Owner =-		   ***
***			  				   ***
**************************************************************
***							   ***
***          "Hyundai Tiburon Widebody Pursuit"	           ***
***							   ***
**************************************************************
***							   ***
***      Original Need for Speed 7: Underground Car        ***
***              Modified and Converted into               ***
***         Need For Speed IV: High Stakes Format          ***
***                Custom Pursuit Vehicle		   ***
***                        by                              ***
***                  -= V I P E R =-                       ***
***							   ***
**************************************************************
***                 CAR FILE INFORMATION                   ***
**************************************************************
***							   ***
*** Car Folder Name  : JTUN                                ***
*** Car Serial #     : 8                                   ***
*** Class            : AA                                  ***
*** Date Created     : 2/15/05                             ***
*** Interior Added   : Yes                                 ***
*** Dash Included    : Generic                             ***
*** Driver Movements : Yes                                 ***
*** Poly Count	     : 7569 Faces			   ***
*** Multi-Language Support: Yes                            ***
*** Performance      : I've incorporated a carp file which ***
***                  allows for fairly decent handling     ***
***                  at higher than normal yet not         ***
***                  exagerrated speeds-this is not meant  ***
***                  to replicate "realistic" performance. ***
***                                                        ***
**************************************************************
***                CAR FILE INSTALLATION                   ***
**************************************************************
***                                                        ***
***           Place the "JTUN" folder in your 		   ***

"C:\Program Files\Electronic Arts\Need For Speed High Stakes\Data\Cars" Folder.

***                                                        ***
*** NOTE: Your own directory may be different than the one ***
***      shown. to locate yours simply right-click on your ***
***      NFS HS Icon, select "Properties" and look in the  ***
***      "target" box for it's location. 		   ***
***                                                        ***
**************************************************************
***                   IMPORTANT NOTICE                     ***
***              FOR HIGH-POLY CAR CONVERSIONS             ***
**************************************************************
***                                                        ***
*** Depending on your own system, you may be required to   ***
*** install the "high-Poly" patch which allows cars as     ***
*** high as 11k polys to be used.                          ***
***                                                        ***
**************************************************************
***               CREDITS AND DISCLAIMERS                  ***
**************************************************************
***                                                        ***
***   I have invested a lot of time in converting many     ***
*** Stock NFS 4/6/7 cars specifically for anyone to use as ***
*** a base for their own projects- most of these can be    ***
*** found in the NFS 3 and NFS 4 sections of the downloads ***
*** under the author name of, "Viper".			   ***
***                                                        ***
***    The Concept Design Works line of cars is exclusive  ***
*** and we ask that you respect the Hard work that Tritoch ***
*** and I have invested in presenting these cars which are ***
*** NOT for use in any manner for your own projects !      ***
***                                                        ***
***   Therefore, ou are NOT authorized to use any of the   ***
*** parts, textures,etc. This file may NOT be uploaded on  ***
*** any other site unless specifically authorized by either***
***                  Viper or Tritoch.			   ***
***                                                        ***
***                                                        ***
***     Thank you for downloading our creations ! 	   ***
***  we sincerely hope you enjoy this car as much as we    ***
***               had compiling them for you.              ***
***                                                        ***
***                  -= V I P E R =-                       ***
***                                                        ***
**************************************************************
***                                                        ***
***   For additional information, comments, etc.  please   ***
***   Contact Tritoch:  olroxg@hotmail.com                 ***
***                                                        ***
**************************************************************






