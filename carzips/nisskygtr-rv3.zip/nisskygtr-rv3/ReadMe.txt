================================================================
Car Information
================================================================
Car Name  : Skyline GTR-R v3
Car Type  : Conversion
Folder	  : ...\cars\nisskygtr-rv3
Install   : Unzip with folder names on to the main Re-Volt folder
Top speed : A few mph faster than before
Rating    : Pro

================================================================
Author Information
================================================================
Author Name 	: Adamodell
EMail and MSN	: metallicafan128@gmail.com (Find me on MSN!! I wanna talk! And just so you know I'm a much better person on MSN, just ask zipperrulez)
Homepage    	: http://adamodell.vndv.com

================================================================
Car Description
================================================================
Yeah another update car. I hope this is a loophole. Probably not. I feel bad for being a hypocrite.

================================================================
Construction
================================================================
Base           : NFS4 model by Ryuji Kainoh
Poly Count     : Not enough to care, dude.
Editor(s) used : Paint.NET, RV Minis 5, Zmodeler 1.07b=(crashes so DAMN much on XP!!!!) RV-Sizer, and a couple others
Known Bugs     : Don't think so.

================================================================
Thanks And Accolades
================================================================
I thank everyone and anyone who has any part in Re-Volt. Oh, and I thank SnOoKiE (Stephen Snook) of Victoria, Australia, for being so effing nice to me, and being my best friend on MSN by far. Oh, and he sent me an expensive pair of headphones for about no reason at all. Yay!

================================================================
Individual Thanks On This Car
================================================================
All credit goes to Ryuji Kainoh for the main body mesh!
The Me and Me: for their awesome tutorial
Aeon: For suggesting a lower poly model
Rick Brewster: For Paint.NET
Oleg M. for ZModeler 1.07b
The Re-Volt Community
Manmountain (for just being there) lol
Myself for the wheels
The Me and Me: For helping me repair that bridge I burned so badly JUST KIDDING

================================================================
Copyright / Permissions
================================================================
Authors MAY use this car as a base to build additional cars.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
Websites: My site, possibly RVZT. No chance on RRR since I cannot navigate that forum right now!