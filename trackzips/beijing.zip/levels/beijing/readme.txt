 
 Beijing --- August 2008
 -------------------------
 by Adamodell and hilaire9
 ----------------------- 
 Length: 776 meters                                      
 Type: Extreme
 ====================================================

 *** To Install: Unzip into your main Re-Volt folder.

 =================================================================  
 Credit: Road mesh converted by Adamodell from a Midtown Madness 2 
 custom track (Green Town) by Aleksandr. G & Riva.
 Rock and tree model prms by Jimk.
 Additional meshes and edited for Re-volt by hilaire9.
 -------------------------------
 Tools: ZModeler v1.07b, 3D Studio Max 5, and MAKEITGOOD edit modes.
 -------------------------------------------------------------------
 --- Adamodell's webpage: http://adamodell.vndv.com

 --- hilaire9's Home Page: http://members.cox.net/alanzia
