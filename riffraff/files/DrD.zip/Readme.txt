This is a custom which took me several tries to get looking right. Its made from 23 different blocks, pieced together.

Dr. Death is just a sporty pickup with H.R.Giger graphics. Thought the name would be fitting, since this car is set up for Tag play, sorta. Its pretty roadworthy too, in case the host races instead of Tag.



The tools used to make this car are

1) 3dsmax R2.5 - To make the car body,  and wheels-tires.

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.


Have fun!  

RiffRaff
