This is the Pronto Cruiser Concept car.

--Mesh Info--

I basically modified the PTCruiser mesh quite a bit to get this model. I had to remap the car and paint it a little different, but for the most part is simular to the PT.

For some pictures of this Concept car, go to http://www.ptenthusiasts.org and surf the photo galleries. Lots of nice Cruiser pics there.

The wheels are a design I found at www.tirerack.com.

--Rules-- 

I only ask one thing if you use this car to make any others, that you acknowledge RiffRaff as the creator in your readme file. Thanks.

--Handling notes--

Handling is more or less the same as all my cars. All it takes is a notepad to change it if you dont like it.

--Paint--

Crummy I know, but I hate that part. 

--Tools--

3dsmaxR3.1 for the body, exported in .ASE format. Converted to .PRM format using Ali and 
           Antimorphs ASE2PRM.exe tool. 

Adobe Photoshop and MSPaint for the .bmp. 

CD of Stevie Ray Vaughn to help me thru the tough times.

-----

Enjoy it.

RiffRaff
9-2-2000.
