This is Warbird. Its not modeled after anything in particular. I named it after I painted it.

Its about 1482 poly without the tires. Tires are 281 each.

I did not spend much time on tuning with this car, so expect it to be about the same as any other car Ive tuned.

Like any of my latest cars, the aerial is not used. If you want an aerial, you will have to edit the parameters.txt and set it up yourself.

Tools: 3dsmaxR3.1
       Photoshop4.1
       Texporter plugin for max
       Ali and Antimorphs Ase2Prm.exe to convert into .prm file. Vertex colors are in        greyscale.

You MAY repaint, or retune, or both to this car. No previous permission required.

*Note* This mesh was stretched slightly in the rear after UVW Mapping was done. If you repaint the car, particularly in the taillight area, dont go to close to the corners.
           

RiffRaff
7-22-2000