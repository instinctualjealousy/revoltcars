8-1-2000

This is the PT Cruiser.

Everyone was asking for one so I jumped on it. Nairb was aching to be involved so I had him do up a set of parameters for it. His set is the default parameters.

I have included another set made up by me, and you already know how they work. I recommend you try out Nairbs parameters before you try mine. Nairb has created a realistic handling of this car and it is definitely more challenging to use them.

Note 8-2-2000: Nairb's parameters have just been updated and slightly improved.

There are 2 batch files to switch between the two sets. All you have to do is open the PTCruiser car folder, and double-click on the either of the batch files. Nairb_parameters.bat will set up the parameters.txt file with his settings. 
RiffRaff_parameters.bat will set it up with mine.

Nairb also fine tuned the scale of the car for me. He made it slightly smaller, and made the wheels a bit taller. They turned out beautifully.
And Nairb also did a little bit of fixing on the default bitmap which helped quite a bit. After he was done with it I painted on a few lines. 

Update 8-2-2000: Nairb made a few extra paint jobs to give you more choices.  They are all as close to real DaimlerChrysler PT Cruiser colors with the corresponding names as possible.  To use a different texture, just double-click on the colors batch file. Example- Double click on Aztec_Yellow.bat and the Aztec_Yellow.bmp will be copied over the PTCruiser.bmp. When you use the car it will display Aztec yellow as the color of the car.

* A few notes about the mesh *

This mesh started out as a box primitive with no subdivisions. All divisions were done with the CUT tool. It was an exercise for me. I dont recommend this approach entirely. It caused some problems in the mesh that I had a tough time fixing.

I did not divide excessively. Only enough to get the shape of the car. I was striving for 1500 poly or less. *almost made it*

This car was built on the left side only. After the left side was built it was UVW mapped. After it was mapped out I cloned the left side, mirrored it, and collapsed the two halves together. Then I welded up the center row of vertices. This created a symetrical object which is otherwise difficult to do. This also gives the advantage of giving you more room on the bitmap, which allows for larger mapping sections for better detail. Poly count 1534.

After Nairb sent me back the car I thought the shading had ended up to dark. He had made the mesh smaller by 10%, so I scaled it down 10% in 3dsmax and reshaded it. The size turned out right so I didnt have to modify the parameters he had written.

The wheels are designed after, but not entirely accurately, the Mille Miglia Emotion wheels.
These were found at www.tirerack.com. The mapping image was taken from thier site so I guess someone there has a copyright to the image. Im sure they wont mind, heh heh. Poly count 482 each.

This is a fairly high poly count car with the wheels. But it runs really really smooth on my AMD 450 K6-3.

* Rules *

There are none as usual. However I wouldnt recommend converting this car to a GT Cruiser, Panel Cruiser, or Pronto Cruiser because they dont even look the same. Besides, I want to try to build them too. ;^P 

If you do make another car from this one, I am asking you keep this readme intact within your zipfile. Thanks. 

* Tools used *

3dsmax3.1 for the car body.
3dsmax2.5 for the wheels.
Ase2prm.exe from Ali and Antimorph (have I said outstanding yet?).
Photoshop for the skin.
MSPaint for preliminary painting.
Texporter plugin to export the polygon edges to bitmap from 3dsmax.


I would like to thank Nairb for the help tracking down pictures of this car for me. It helped immensely, and I dont think the accuracy would be as good without his help.
He has also created a fine set of parameters for us to play with.

THANKS BRO!!

Thanks all, and enjoy it.