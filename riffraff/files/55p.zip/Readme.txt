Hope you enjoy this one, because it was the most difficult car to work with I have come across. Detail beyond belief.

This is a 1955 Porche 911.

I have tried to make it act as close to a real car as possible. However, this is Revolt. I am finding different bodies dont react the same to identical parameters. This one is smooth however, but I have slowed it down some to keep it that way. I really like the handling of this car.

This is a totally Royalty-free usage of this car. The copyright is owned by 3DCafe and Platinum Pictures.

The tools used to make this car are

1) 3dsmax R2.5 - To make the car body, axles, and wheels-tires.

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.
 

RiffRaff
