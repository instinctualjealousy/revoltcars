**** Welcome to my nightmare ****  Enable WordWrap if using Notepad...

I will say one thing right up front, this track is the hardest track I have EVER tried for POD. Having said that, it might even be the most aggravating, and least enjoyable too. This thing pisses me off more than Babelweb ever did. I have still never completed a full lap without hitting something.

I do not expect very many people to like this track, let alone even try to ghost on it.

I'm not going to try and describe it, but Reverse is different from Forward again. Almost 1/3 of the track is different. 3 different elevators on this one, but no railguns (accelerators).

**** Building it ****

I was thinking about some e-mails I got from Snakeeyes when he was building Forest. He wanted to make Forest harder than anything ever made, but he made the track too wide open. I took his ideas and assembled this track using tight sections, and parts I always had the most trouble on. I intended to make this track difficult, Im sure you will hate it. Well, maybe not Algor but everyone else will.

I used some easy sections, just to keep the flow going, and my blood pressure down.

You will notice a few sections are reskinned. I like the new paint.

**** Naming the track Newsance ****

I have spent more time tracking down errors and bugs on this track than any other projects combined. I almost gave up because some of the errors are rediculous. Several times Zed05 or Spin06 has a vertex with "incorrect UVW Mapping coordinates"... most of the time I just had to open the Unwrap UVW tool, and close it, and the error would dissappear.

Many times a Plant21 section would have a polygon that "Is neither a triangle or a quadrilateral", then it would tell me which polygon number it was. EVERY time I found the polygon, it was a triangle with an open edge.

I had one section that complained that a vertex didnt have any luminosity setting. Asking 3dsmax to "Select all" wouldnt help, so I finally deleted the section, and re-merged it. 

You see where Im going with this? This track was a total pain in the butt to make, a genuine "nuisance". I spent well over 40 hours on this SOB.

**** Known Bugs ****

Once in a while, a polygon appears to be missing until you get close to it. Others wont render if the angle you approach them are too steep. I cant fix this.

I tried very hard to simplify the textures below 20 images, but it just was too damned ugly. I managed to keep the track looking ok with 25 images. I eliminated 10 images in the process. If you use a 3dfx video card, you will probably have missing textures in a few places. Sorry, I cant fix this either.

I tried to fix all the areas where you fall off the track, and never reposition right. I had to create an alternate path to fix one of these spots, Im sure you will find it when you go in reverse. An intentional shortcut was developed to fix another spot like this. You will have to look very hard to find it in the BL4viewer, you will probably find it when your car is out of control. :)

**** Things I want but cant do ****

I wanted to use animated textures for this track, but Siklist has not finished the code for it. He has informed me he doesnt want to work on it anymore. This is too bad, the track really needs the flashing lights to look right.

However, I fully support Siklist's decision, because he is working very hard on the new project.

I also want Skubidou to try very hard to figure out how to make AI lines. Hows that CD working out Skubi? :) If you figure that thing out, Im sure there is a lot more we can do.

**** Reporting errors ****

Just post on the murmuran.net/pod forum. I wont accept emails because my ISP is getting crazy with the SPAM filtering. I can only accept mail from people on my accept list. So if I havent already heard from you, I cant accept email. You could try vigilantes@yahoo.com, but I dont check it very often.
This problem will be worked out, but for now thats how it is.

Leadbest
November 17, 2003.