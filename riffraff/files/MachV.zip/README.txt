This is the MachV, known as SpeedRacer. It is a custom mesh made with 3dsmax3.1 I exported
it to a 3ds format and textured it in 3dsmax2.5

There are 2 batch files that you can use to select the original speedracer (ORIGINAL.BAT),
or select the RiffRaff version (FAST.BAT). Just open the MachV directory and double-click
on the .bat you wish to use.

ORIGINAL.BAT will change the car to the SpeedRacer skin and parameters.
FAST.BAT will change the car to my skin and much quicker parameters.

Feel free to repaint this car if you like. If you redistribute this car, you must leave
my name in your readme file as the builder of the mesh.

Thanks and enjoy.

RiffRaff

