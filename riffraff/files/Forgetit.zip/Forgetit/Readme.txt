The world of IO as we know it has changed... LOL

Why is this track called Forgetit? Because everything you used to know about your favorite tracks, forget it.

No not really, but there are some changes here and there to break the monotony, and to make it seem fresh.

There are sections of Skyrace, Mine, Sewer, Lake, Factory, Magnetic, and West all put together to form this track. I did not make it easy to navigate, however it is not impossible either. It will take a few laps to start figuring out where you are, and remembering the changes.

Both of Magnetics "Accelerators", or "Rail-guns" are included. You will encounter the one in forward mode near the end of the lap. The other one is in reverse, which has a whole different feel to it and a nice surprise at the end. They do seem to accelerate you much faster than the original tracks did, I really couldnt make them work slower.

The track is laid out as follows:

--FORWARD--

The forward Skyrace section is simple. Either make it or Ctl-y it. LOL
There are 2 exits at the bottom, only one goes forward to West.

The West section has 2 options, the jumps or the ramp. Both can be accessed from both paths out of the first Skyrace section. Just slow down at the bottom because a nasty Factory section awaits you.

The Factory section is not too difficult, but the shortcut seems about the same as the original. Sometimes it lets you through, sometimes it wont. LOL
There are no bricks to CRASH through.

The Lake section is self explanatory. I placed the checkpoint to allow you to use the bridge shortcut if you want. 

The Sewer sections are relatively simple, nothing too difficult. Going forward, you will have to be careful because you are heading into...

...Mine. Simple, nothing tough except getting in.

Back to a quick view of Lake, and then on to the first Magnetic Railgun.

Thats the end of one lap. I was able to hit 1:40's laps pretty easy.

--REVERSE--

In Reverse you start out in Magnetic, and head off to Lake. 

The Lake section is very short, and you must find an entrance to Mine. (Look to the right)

You will "pop" out into a Sewer section, and end up back at Lake.

When you go through Lake in reverse, you have to take the jump and complete the loop. If you turn right and head for the bridge, you will miss the CP. Just hit the new ramp but be careful the correct path is narrow. Hehe. If you turn left, you MIGHT be able to use a CP quicker than going across the jump, but the gain might not be worth the risk because the track is narrow. Bump across the bridge and head into Factory.

Nothing changed here, just go on through to West.

Again, nothing new, head up the ramp and enter Skyrace.

When you enter Skyrace, a little to the right and out, this enters a very short Magnetic section, which turns into another Sewer section. 

This Sewer section takes a few laps to get used to, you will see.

Exit Sewer into the reverse Magnetic railgun. Zooooooom, grab 0 gear!

Reverse Skyrace includes our favorite 7th gear passage, hold on to your hat! Carefully navigate past the start. You are finished with a reverse lap. I only managed a 1:56 once, but I wasnt using the 0 gear.

The first CPs going both directions are quite a ways from the starting car positions. So just keep an eye on your timer to figure out where each lap starts.

----Credits----

Ubisoft for the great tracks and textures.

Skubidou for the monumental task of getting me the tracks fully textured. 

Siklist for the outstanding plugin. I never thought it could be this easy.

Rob for the English translated plugin tutorial. 

Each and every one of you for being a part of this outstanding community. We are still friends after almost 7 years.

Last but not least. Qball for the front porch to reality. ;) Without our jammin brudder we would have all been left out in the rain. 

THANK YOU!

