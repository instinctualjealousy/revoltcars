Dopple Version 6.  Its done! Sorry to those of you who had trouble with Version 5. I have worked out the low viewpoint problem, and now the car doesnt hit itself with its own weapons.  Kewl!!

This car Dopple is a car from the game Pod. Original Dopple body, using Cougars wheels.

The tools used to make this car are

1) 3dsmax R2.5 - To make the car body. Used the dopple.dxf available from Ubisoft.

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.

4) Caffiene- Lots of it.


Unzip to ###\cars\dopple   ### being the install directory on your PC.


The skin is done right. Its begging for talented painters. 
Have fun!  

RiffRaff
