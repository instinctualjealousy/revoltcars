This car is another total custom build. I originally was going for a jet engine type car, with magnetic disks attaching the wheels. That is the concept here. But after I started texturing it, it suddenly looked like the body of a grasshopper, so it was renamed Thorax.

Funny how things turn out.

Copyright to this car mesh belongs to myself. If you repaint or modify this car, you must state the copyright belongs to me.

Textures come from Pod but are modified somewhat. One section of texture is from Acclaims Forsaken. Some of it is handdrawn.

This car is not to be redistributed for profit, as no profits are to be made on this car.


The tools used to make this car are

1) 3dsmax R2.5 - To make the car body, axles, and wheels-tires.

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.
 

RiffRaff
