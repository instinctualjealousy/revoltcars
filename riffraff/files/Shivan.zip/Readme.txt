This is the SHIVAN. This car was one of the original 8 cars released with Ubisofts POD.
This particular car is dedicated to a friend of mine, Glenn Shiver AKA Shiv". A pod player who has no doubt logged more hours on Podnet than any other. Its taken me a while to get to this car again. I wanted it done right. 

The mesh from the body is copyright UBISOFT, as well as the texture set. I have painted this with the original textureset, but have made a change. Only a Podhead will see the difference.

The car layout is unchanged except for the axles Ive added. I just couldnt see not making it the way UBISOFT intended it.

The settings are the way I like them, change them if you dont like them.

I personally dont care if you copy this car or whatever. Theres only one Shivan tho, heh-heh.

Tools:      3dsmaxR3.1 
            ASE2PRM.exe from Ali and Antimorph.
            Texporter3 plugin for R3.1 which helps greatly with the painting of the car.
            Photoshop 4.1
            MSPaint
      
Detriments: Windows98SE
            One glass of water spilled across my keyboard and lap, causing loud shouts and             running dogs. 

Hope you enjoy this one. Even though its an easy conversion Im proud of her.

RiffRaff
7-13-2000
           