Something different. Modeled from the Bakar.

Install to ###\cars\pur

The tools used to make this car are

1) 3dsmax R2.5 - To make the car body. Used the Bakar.dxf available from Ubisoft.

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.

This car has custom axles. I was going to put custom tires on it, but the Cougar wheels fit perfectly. Just painted them different.

Couldnt think of any good schemes for the paint. Skin is mapped pretty accurate tho, so shouldnt be a problem for those who wish to repaint it.

RiffRaff