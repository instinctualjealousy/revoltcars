This is Bolink.                                                      April 19, 2000

I own an old 1/12 scale Bolink car, and this is the body that is on it. I dont know the name for the body.

This mesh is custom, build with a single NURBS sheet. 631 Polygons.

The paint is kinda crummy, but its the best I could do for a car like this. I didnt want to use science fiction graphics on it.

The parameters are the way I like them. Fast enough but still stays in control. If you dont like them, change them yourself. 

This mesh can be used to make your own cars with. All I ask is you mention RiffRaff in your readme file. If you dont, I dont really care but its a courtesy thing.

--Tools--

3dsmax2.5
Photoshop 4.1
MSPaint

Enjoy.

RiffRaff
