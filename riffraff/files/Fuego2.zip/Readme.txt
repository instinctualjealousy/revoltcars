Fuego is a car from the game Pod. Original Fuego body, using custom wheels.

This UPDATE uses different wheels.

Fuego was originally created by Richard "MachIV" Sirois for the game Pod. The mesh used to create this car was supplied by him.
The texture was supplied by Phoenix~.

Unzip to cars\Fuego.



The tools used to make this car are

1) 3dsmax R2.5 - To make the car body. 
                 The wheels are made custom. 

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.

4) Caffiene- Lots of it.

This is the last of the Pod Cars I wish to create. 


Thanks go out to Phoenix~ for the textures, and of course to Richard for the mesh.
And to all of you, for loving this car.


Have fun!  

RiffRaff
