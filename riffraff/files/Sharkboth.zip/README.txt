The Shark. Unzip to cars\shark.

The body and textures of this car were originally created by Richard "MachIV" Sirois.
He was very generous and give me the original mesh for this car. It appears here unchanged, except for scale. He should recieve all credit for the design of this car.

The textures were provided by Phoenix~, they are the textures from Shark that Ubisoft used when they finished this car. I tried to apply them exactly, it is very close.

This is Shark. This car will not satisfy everyone. It will not drive like it did in Pod.
In order to get some semblance of control from this car, I had to make the tires invisble and place them at a normal wheelbase. The short wheelbase version of this car with visible tires just is not driveable. So all you will see on track is the car body, a shark. The tires are there, just not visible. The handling modifiers have been tuned down, the car suffers from severe oversteer with normal steering. I believe it is very drivable in this state, you might have to bump the settings up if desired.

This car also exhibits a irritating graphic glitch that I could not get rid of. 3 builds and it keeps showing up. It is the panel just right of the dorsal fin. The windsheild area isnt right either. Give up trying to fix it.


The tools used to make this car are

1) 3dsmax R2.5 - To make the car body. Mesh provided by Richard Sirois. Known as MachIV in the Pod community. Thank you Richard.

2) Adobe Photoshop 4.1 - To paint the skin.

3) RHQ Car Manager - To make this compilation a little easier.

4) Caffiene- Lots of it.

This is the 4th of the Pod Cars I wish to create. More to come.



Have fun!  

RiffRaff
