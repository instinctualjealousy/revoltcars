If you are reading this, you have the zipfile that contains both versions of this car.

The zip is quite large, it contains 2 sets of tires, 2 sets of skins, 2 sets of parameters, and a couple of batch files to make the change easy.

To use with no tires and somewhat predictable handling, execute the No Tires.bat file within the installation directory. This will apply the skin which makes the tires invisible, it will also apply the correct parameters.txt file, which moves the tires to the corners of the car. This paint requires the use of the smaller tires.

To use with tires, and almost impossible to control handling, execute the Tires.bat file.
This will change to the larger visible tires, and apply the parameters which move said tires to the correct Shark position. This car is not easy to drive this way, and the parameters are ones I give up on refining. Do not expect much.

There should be no backing up of files required for either conversion.

