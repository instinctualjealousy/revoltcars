===============================================================================
                        *** TRACK INFORMATION ***
===============================================================================
Author                  : RiffRaff
Email Address           : leadbest@gorge.net
Track name              : Plant XXI
Filename                : Plant_XXI.zip	
Track length            : 1132 meters	
Textures (if any)      	: Original POD Plant21
Release Date            : 3/29/2003

Additional Credits to	: Ubisoft France, Skubidou (Email addy withheld), 
			  Antimorph and Nairb (For reverse information),
			  Ali, Antimorph, and Gabor for the ASE tools. 

===============================================================================


* Description *
---------------

This is Plant21 from the 1997 racing game POD. Texturing is exact.
The track is changed very slightly,in the road crossover area. This was done to 
overcome AI problems in the very likely event of a weapon impact just before the 
jump. Also the entrance to the shortcut was modified so the cars would no longer
miss the AI lines.You will find the AI cars have a much easier time completing 
the shortcut than you will. They are evil.

This track is somewhat long, but you should find it fun with any type of car. 
Supercars can be quite amusing, but the AInodes are set up for Toyeca class.

This track was Visiboxed and Trackzoned with the ASE tools. 
 
This was one of the top 5 tracks raced online in POD's heyday. 
I hope you like it.


* Tips/Hints *
--------------

If you have played POD, you undoubtably know the racing line for this one. 
Be aware that it has changed a wee bit. :) 

There is a completed reverse version that can be used following Nairb's instructions.
Type your name as TRACKER, select any track in reverse, hit escape until you get back
to the name screen, enter your name you race with, then select Plant21 Reverse. 
Please try the Reverse version any way you can. It is quite challenging.


* Gripes/Whines *
-----------------

I did not know the 3d sounds would not work once I copied this track to its own
folder. Its not a great loss, but I left the 3dsound objects in the .fob file.
They all worked when it was in the Nhood1 folder. Bummer.


* Installation *
----------------

Unzip into your ReVolt folder. Everything should fall in place. If not, flame me
ruthlessly and I will fix it. LOL


* Copyright/Permissions *
-------------------------

Under no circumstances will this track be allowed to be sold.
It is free now, and will always be free. No exceptions!
If you had to pay for it, you better give Ubisoft a call.

This track may be redistributed, free, as long as this readme is intact and 
included with the track.

Mesh and texture copyright permissions belong to UBISOFT FRANCE.
