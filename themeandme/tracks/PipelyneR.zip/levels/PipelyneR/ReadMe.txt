Track Name: Pipelyne R
Folder Name: ...\levels\PipelyneR
Track Type: EXTREME, based on the P.O.D. track
Author/s: RiffRaff, Manmountain, hilaire9 & The Me and Me
  Email: TheMeandMe: saver@gmx.li
  Homepage: http://www.themeandme.de/
Length: 1554 meters
Known Bugs: None

Install: Unzip with "Use folder names" on to the main RV folder

Tools used: PSP; Glue+Asetools by ali, Christer and Gabor Varga

================================================================
Description
================================================================
Twin set again. This time converted from the classic P.O.D. by
RiffRaff and made raceable in RV. A very fast track thru
futuristic stuff.
Backwards version features slightly shorter and a little more
difficult layout towards the end of the lap.

================================================================
Tips
================================================================
If anything, be careful with your cornering in the Pipelyne. Or
you'll flip and lose. A fast car is suggested, as it's a little
boring in a slow one. No problem to take something over 50 mph.
Time tips hugely depend on sheer speed of the car so there ain't
none.

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this track, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! And even tho the site
has closed down, we're all still able to visit the backup site,
hosted on RVA.
http://rvd.rvarchive.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #re-volt chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this track would not have been possible.

================================================================
Individual Credits and Thanks On This Track
================================================================
RiffRaff:
The mesh master. Conversion, texturing and mesh mods to make it
work in RV properly. Vissed it too. Word!

Manmountain:
The AI king. Responsible for them computerdriven enemies going
round the track like they do.

hilaire9:
The Wizard. If you don't know yet about hils magic, than youre
prolly under some evil wizards spell. He can do LIGTNING!

The Me and Me:
The Ez-stuff-mangs. Triggers, Fog, first AI route and Position
nodes, track zone layout and formal stuff like this ReadMe and
screenshots.

P.O.D. guys:
Thanks for that game, peeps. Wonderful racing action. Gaming
world would miss a gem if it hadnt been for you. Thanks!
================================================================
Copyright / Permissions
================================================================ 
You MAY distribute this TRACK, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this TRACK
================================================================
Websites : http://www.rvarchive.com/ or www.sportplanet.com/rva 
	 : http://www.revoltunlimited.co.uk/
	 : http://rvzt.expert-gamers.com/main/news.php
         : http://www.themeandme.de/