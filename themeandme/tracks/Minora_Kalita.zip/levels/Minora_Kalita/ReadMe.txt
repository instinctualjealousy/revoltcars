Track Name: Minora Kalita
Folder Name: Minora_Kalita
Track Type: LEGO with EXTREME editing techniques
Author/s: The Me and Me
  Email: saver@gmx.li
  Homepage: http://members.tripod.de/saver83/revolt
Length: 927 meters

Install: Unzip with file names on to the main ReVolt folder

Tools used: PSP 7.0; Glue4 by ali; RV-Remap by chaos

================================================================
Description
================================================================
Well this is just another track editor track thats uses
Spaceman's textures and some objects and instances. What's
special about this track then? Well, it sets a certain ambiance
with the fog so close and the fun and challenging layout. We also
used Glue4 for the first time (on our second track ;) and I can
tell it was not always easy for scloink and Silverlode to keep
us motivated.

================================================================
Tips
================================================================
Tips: If you want to get some of the pickups/stars, then you have
to go away from the best racing line in some places.
This track was designed with/for Pro cars, so we recommend to
race the track with these. You will make even better with SuperPro
cars, but not the AI drivers.
Lap times should come to an average of about 1:20 - 1:30 with
Pro/SuperPro cars. The best times we got were 1:09 with Lambo
Evelica SP; 1:14 with Shelia S 5000 and  1:23 with SuperTard's
Zone Patrol.


================================================================
Thanks and Accolades
================================================================

First off we would like to thank the entire community for hanging
around through all that has happened. we think we can compare 
ourselves to some of those Quake clans out there. We are the true 
fanatics of Re-Volt. 

We would also like to thank Wayne Lemonds for the great forum and 
website. He has helped bring some people together as aquaintances
as well as some friends. If you havn't visited his website please
do so, you won't regret it. www.racerspoint.com.

Then we want to thank the staff of RVA for their great site. As it
is the perfect addition to Racerspoint with all the tracks, cars,
tutorials and stuff. If you don't know it yet, go here and you
won't regret it: www.rvarchive.com.

We would also like to thank ALL the peeps at #re-volt chat on the
IRC austnet servers for their support and help without forgetting
anyone of them. Thanks dudes!

Then we want to thank the creators of the tools we used. Without
them, this track wouldn't be like it is.


Now for the individual thanks, they go to

scloink:
He was there in the chat when we first ran into Glue badly. He helped
us fixing some problems that we alone never would have been able to
fix. Also helpful in motivating us to do all the things he told us to.
Also for his ReadMe of Catacombs that we used for this as a template.

Silverlode:
He did a lot of testing on the preglue and afterglue track and made some
suggestion to make the track better in looks and layout.

Greenflag:
He did some testing on the preglued track and helped alot to improve
the layout of track.

Spaceman:
Last, but surely NOT least, we want to thank Spaceman for the textures
from his texture pool. The textures are the main thing in giving the
track its mysterious style.


If I have left anyone out I am sorry and feel free to reprimand me 
for it on the forum. 


* Copyright / Permissions *

You MAY distribute this TRACK, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this TRACK *

Website  : http://www.revolthq.com/
Website  : http://www.racerspoint.com/revolt/
Website  : http://www.rvarchive.com/

