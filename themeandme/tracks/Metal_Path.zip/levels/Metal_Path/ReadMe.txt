Track Name: Metal Path
Folder Name: ...\levels\Metal_Path
Track Type: LEGO with usage of RVGlue4
Author/s: The Me and Me
  Email: saver@gmx.li
  Homepage: http://members.tripod.de/saver83/revolt
Length: 584 meters

Install: Unzip with file names on to the main ReVolt folder

Tools used: PSP 7.0; Glue4 by ali

================================================================
Description
================================================================
A sorta short track in our LEGO-Only series. This one has modded
DownTown by Silverlode textures to fit the name. Glue was used
to get rid of that ugly blue walls. It flows good but only has
a few technical sections so beating the AI cars won't be too
challenging. But it is very fun in Multiplayer.

================================================================
Tips
================================================================
This track was designed with/for Pro cars, so we recommend to
race the track with these.
Lap times should come to an average of about 0.40 - 0.55 with
Pro/SuperPro cars. The best times we got were 0.34 with Lambo
Evelica SP and 0.38 with Shelia S 5000.

================================================================
Thanks And Accolades
================================================================

We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #re-volt chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Track
================================================================
Silverlode:
For making these great textures for his DownTown track. We
highly recommend to download his track, cuz it's more then just
fun and we use it to test us and our cars nearly all the time.
Its fun and challenging at one time which is really great IOO.
And the textures he made also look great. Thanks!

================================================================
Copyright / Permissions
================================================================ 
You MAY distribute this TRACK, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================

Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/

