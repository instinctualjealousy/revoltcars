Track Name: Kudos Walk
Folder Name: ...\levels\Kudos_Walk
Track Type: LEGO with usage of RVGLUE7 and some XTREME TECHN.s
Author/s: The Me and Me
  Email: saver@gmx.li
  homepage: http://www.themeandme.de/
Length: 748 meters
Known Bugs: Name doesn't really make thaaaat much sense

Install: Unzip with file names on to the main ReVolt folder

Tools used: PSP 7.0; Glue by ali, Christer and Gabor Varga

================================================================
Description
================================================================
Basically, a pretty challenging Lego track with rusty textures.
To make it more interesting, we added pics of one of the best
looking women in the showbiz, Nova Meierhenrich. Even though
most of you might never heard of her. To make it a lil less
one-sided, we also added reference (kudos, hence the name) to
several important RV websites and to RVGlue.
We also heavily modded the track's AI-file to have challenging
Computer opponents. We made them turn a 1-lap race by more than
10 secs faster as they did b4. Have fun!

================================================================
Tips
================================================================
This track was designed with/for Pro cars, so we recommend to
race the track with these.
Lap times should come to an average of about 1.00 - 1.15 with
Pro/SuperPro cars. The best times we got were 0.51 with Lambo
Evelica SP and 0.54 with Shelia S 5000.

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this track, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.revoltdownloads.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #re-volt chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this track would not have been possible.

================================================================
Individual Thanks On This Track
================================================================
RiffRaff:
For the base textures from his tracks Newk and Magnet. Both are
really a blast to look at and to drive on. Textures have been
modified quite a bit, but still... Where would this track be
without them? Nowhere good, we guess. Thanks!

GWC & revlo:
For testing the track and submitting screenshots with various
results just for AI comparison. Thanks!

Webmasters mentioned on the track and RVGlue makers:
Just for the effort they put in for Re-Volt. Really appreciate
their work, without them, RV wouldn't be where it is. Thanks!

Nova Meierhenrich:
For looking so good. Well, of course we care for her smarts as
well. But it's pretty hard to put them into pictures. Thanks!

================================================================
Copyright / Permissions
================================================================ 
You MAY distribute this TRACK, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this TRACK
================================================================
Websites : http://www.revoltdownloads.com/
         : http://www.rvarchive.com/
	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/