Track Name: Similiar
Folder Name: similiar
Authors: The Me and Me
Email: saver@gmx.li
Homepage: http://members.tripod.de/saver83/revolt
Type of track: LEGO with new textures and some EXTREME editing

Track Installation: Extract all files to your Re-Volt root directory.

Track Length: 830 meters

Description: This track is our first one. We didn't use much of extreme editing possibilites only a few to make the track more flowing and interesting. The textures are from SpaceMan's great Texture Pool, but we didn't used all for what he made them for. They set an atmosphere that can be described with words like dark, mysterious or sth like that. You only get the name when you would have a look on it from above. It is based on four circles of big round corners. The track has (IOO) a good layout with ok flow. It was built on the performance of PRO cars.

Problems/Issues: QUALITY(lol)! The blue track editor walls. Maybe we will think about glue on our next track. We tried it once but it only made the track worce (IOO), so this has to wait.

Tips: When you come to the JUMP, you should keep attention that you don't fall out of the track cuz you will be resetted right into the chicane. If driven very right with a car of about 42 - 45 mph then you should be able to get lap times of about 1 minute. You'll be quite fast then. Average lap times should be about 1:05 - 1:30, depending on you and your car.
(At least these are time we got... Hehe): BestTime: 0:57 (with Shelia S 5000); BestTime: 1:12 (with Toyeca)

Additional Credits to:
You for downloading this track; Acclaim for producing this game; RHQ for supporting all those crazy Re-Volt fans;  Racerspoint for the best Re-Volt forum; Re-Volt Archive for giving cool comments on cars and tracks; all ppl from the mIRC-chatroom; Silverlode for telling us to release this track and mainly SpaceMan for the great textures from his Texture Pool where we cut&pasted ours from.


* Copyright / Permissions *

You MAY distribute this TRACK, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this TRACK *

Website  : http://www.revolthq.com/
Website  : http://www.racerspoint.com/revolt/
Website  : http://www.rvarchive.com/

