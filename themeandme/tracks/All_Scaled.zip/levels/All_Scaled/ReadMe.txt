Track Name: All Scaled
Folder Name: ...\levels\All_Scaled
Track Type: LEGO EXTREME
Author/s: The Me and Me
  Email: saver@gmx.li
  homepage: http://www.themeandme.com/
Length: 386 meters

Install: Unzip with file names on to the main ReVolt folder

Tools used: PSP 7.0; Glue4 by ali; WScale 4 by srmalloy

================================================================
Description
================================================================
The first lego track released that features scaling on all 3
axis. This adds a new challenge to the way of yer driving and
you definetly have to learn how to take the corners the right
way if you drive this one for the first time. The shortness of
the track is cool bcuz of this, cuz you might get frustrated
if it was longer. AI does quite cool and we're pretty proud of
that as we had to do it from scratch. Same for POS Nodes and
Track Zones. If you think this track lacks of atmosphere, then
keep thinking about it as an experiment of the power of wscale4.
And please use the Super Nova skymap with this one, it was built
using it. Have fun!

================================================================
Tips
================================================================
This track was designed with/for Pro cars, so we recommend to
race the track with these. Especially the Race Debate pack cars
seem to be a good choice to take.
Lap times should come to an average of about 0.25 - 0.35 with
Pro/SuperPro cars. The best times we got were 0.21 with Lambo
Evelica SP and 0.24 with Shelia S 5000.

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this track, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #re-volt chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this track would not have been possible.

================================================================
Individual Thanks On This Track
================================================================
srmalloy:
For modifying his wscale proggy in about 5 minutes so that we
can scale X and Z as well. Get this one release to public, srm.
It will add a new level to Re-Volt. Thanks!

scloink:
For creating this wonderful skymap for Super Nova. Without it,
it would not look as good. Thanks!

unknown Acclaim Artists:
For creating the textures for Rooftops, which we used as a base
for the textures here. Thanks!

Santa Claus:
For importing Rooftops from Dreamcast to PC, cuz without it, we
wouldnt have had these textures. Thanks!

================================================================
Copyright / Permissions
================================================================ 
You MAY distribute this TRACK, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this TRACK
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/

