Track Name: El Dorado
Folder Name: El_Dorado
Track Type: LEGO with EXTREME editing techniques
Author/s: The Me and Me
  Email: saver@gmx.li
  Homepage: http://members.tripod.de/saver83/revolt
Length: 1087 meters

Install: Unzip with file names on to the main ReVolt folder

Tools used: PSP 7.0; Glue4 by ali; RV-Remap by chaos

================================================================
Story
================================================================
Back in the days of the Aztec and Maya people, there was built a
track in the jungle to have awesome races with their Llamas. Today,
this totally changed and you wont ever get to use Llamas again.
Instead of them, there are now RC cars, which are faster, better
controllable and another advantage of RC cars is, that they don't
spit. Instead of spitting, you're now able to use fireworks, bombs,
oil slicks, water balloons etc. That's not much better or fairer,
but at least it's more hygienic. Your task is now to beat all the
other Llamas (erm... RC cars) to be allowed to continue with the
"real" tracks.

================================================================
Description
================================================================
Our third track and again a lego with Spaceman's textures. But
this time they have been modified to fit the theme of old buildings
in the area, where once El Dorado was said to be. It is rather long
for a Lego track, but there are not many parts of the track that get
repeated, so it doesn't get really boring. There are much more
instances in the track as well to add to the jungle and Aztec feel.

================================================================
Tips
================================================================
Tips: If you want to get some of the pickups/stars, then you have
to go away from the best racing line in some places.
This track was designed with/for Pro cars, so we recommend to
race the track with these. You will make even better with SuperPro
cars, but not the AI drivers, they seem to get of the racing line
in some places and never finish a lap.
Lap times should come to an average of about 1: 30 - 1: 45 with
Pro/SuperPro cars. The best times we got were 1: 23 with Lambo
Evelica SP and 1:27 with Shelia S 5000.


================================================================
Thanks and Accolades
================================================================

First off we would like to thank the entire community for hanging
around through all that has happened. we think we can compare 
ourselves to some of those Quake clans out there. We are the true 
fanatics of Re-Volt. 

We would also like to thank Wayne Lemonds for the great forum and 
website. He has helped bring some people together as aquaintances
as well as some friends. If you havn't visited his website please
do so, you won't regret it. www.racerspoint.com.

Then we want to thank the staff of RVA for their great site. As it
is the perfect addition to Racerspoint with all the tracks, cars,
tutorials and stuff. If you don't know it yet, go here and you
won't regret it: www.rvarchive.com.

We would also like to thank ALL the peeps at #re-volt chat on the
IRC austnet servers for their support and help without forgetting
anyone of them. Thanks dudes!

Then we want to thank the creators of the tools we used. Without
them, this track wouldn't be like it is.


Now for the individual thanks, they go to

scloink:
Well, he didn't help us that much on this track, but he would have helped
and he did some serious testing, so he is not wrong at all here.
Also for his ReadMe of Catacombs that we used for this as a template.

Silverlode:
He has been testing it and mentioning some serious errors with the AI
nodes and some flying objects. So without him, probably all AI cars
couldn't ever finish a lap. (yeah, that meant you'd win all the time,
but it's not good anyway)

SlowJustice:
He did some testing on this track in both first and latest versions, as well
and made a coupla suggestions about instances.

Antimorph:
He didn't only test this track, but also made these great pyramids that are
all over the track. They are what makes this track aztec. And he did them in
a coupla minutes... Hehe... If you'd imagine what we'd produce in a coupla
minutes of maxing... :)

kv:
He was in the chat and we forced him to test this track, too... So he gets
credited in here :)

Spaceman:
Last, but surely NOT least, we want to thank Spaceman for the textures
from his texture pool. Although we altered the colorization, he was the
man who made these textures that make this track golden.


If I have left anyone out I am sorry and feel free to reprimand me 
for it on the forum. 


* Copyright / Permissions *

You MAY distribute this TRACK, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this TRACK *

Website  : http://www.revolthq.com/
Website  : http://www.racerspoint.com/revolt/
Website  : http://www.rvarchive.com/

