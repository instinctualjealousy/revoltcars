Track Name: Dirt Valley
Folder Name: ...\levels\Dirt_Valley
Track Type: EXTREME - based on DirtKit by Jimk
Author/s: The Me and Me
  Email: saver@gmx.li
  Homepage: http://www.themeandme.com/
Length: 1221 meters

Install: Unzip with file names on to the main ReVolt folder

Tools used: PSP 7.0; Glue4 by ali; DirtKit by Jimk;

================================================================
Description
================================================================
Ladies and Gentlemen, here it is, our first Xtreme track:
Another one of the Dirt Kit tracks. After The Gorge, this more
or less a typical Dirt Kit track. Flat layout and some wisely
placed jumps and obstacles to keep flow goin. The fog settings
should help gettin acceptable FPS. If you drive w/o customs, FPS
is great. It quite long at 1221 metres, but I dont think its
boring while being long. You can not cut the jumps or corners,
due to narrow track zones and replace triggers. AI doesnt do
too bad IOO, we are quite proud of how good it runs now. Though
you can easily beat AI if you are trained on this track.

================================================================
Issues
================================================================
In anybody can fiddle out how to use VISIBOXes better on this
track or has an idea of how to make the AIs drive better/faster,
just drop us an email, or do it and then send the file. :)

================================================================
Tips
================================================================
This track was designed with/for Pro cars, so we recommend to
race the track with these. You will need a Pro/SuperPro car to
reach one of the two stars. You need a weird racing line to get
the other one. Same for some of the pickups.
Lap times should come to an average of about 1.25 - 1.40 with
Pro/SuperPro cars. It really depends on the car you take, thats
why the average range is that big. I think I can remember to be
driven a 1.18 with Lambo Evelica SP and a 1.17  with Shelia.
Though you may be able to make it better with those cool offroad
trucks that came out l8ly. Be sure to check those out.

================================================================
Thanks And Accolades
================================================================
We want to thank u, for downloading this track, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #re-volt chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this track would not have been possible.

================================================================
Individual Thanks On This Track
================================================================
SlowJustice; triple6s; roseladi; DSL_Tile; BurnRubr; Revlo:
We want to thank these lovely ppl for testing Dirt Valley in its
different states of development. They made some useful
suggestions and came up with some good ideas of how to make the
track better and better and better. Thanks!

scloink:
We want to thank Grandmaster scloink for all the effort he puts
into this game, and if it hadnt been for him, the AI cars would
prolly still go around the corners like turtles. Thanks!

LaserBeams:
For testing the track and basically for setting up RV-Lights at
the mountains, which really adds to the feel and looks of it.
What was best about it, he wanted to do it. Thanks!

Jimk:
For creating that great Dirt Kit Kit, which is the most used kit
AFAWK, and for good reasons. Its easy to install, and once you
know how to switch between camera and world in MakeItGood, easy
to use as well. It was such a breeze to create this track that
we maybe will do another one. Thanks!

If we left anyone out, feel free to yell at us in the chat or
at the forum. Would be good to see some comments as well.

================================================================
Copyright / Permissions
================================================================ 
You MAY distribute this TRACK, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================

Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/

