================================================================
Car Information
================================================================
Car Name  : Re-Volt Airplane
Car Type  : Original from Re-Volt Airport
Folder	  : ...\cars\rvairplane
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 49 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Freestyler & SuPeRTaRD & The Me and Me
Free-EMail  : FRENZAL_RHOMB@gmx.co.uk
ST-EMail    : brgpug@ev1.net
TMaM-EMail  : saver@gmx.li
TMaM-page   : http://www.themeandme.de/

================================================================
Car Description
================================================================
Yet another airplane. This time the mesh was entirely created
and intended for Re-Volt. Freestyler created the base mesh and
SuPeRTaRD heavily modded it to look as good as it is. He also
altered the mesh for looking best for the driveable version.
What we basically did, was sizing it right and making up the
params. You'll see no skidmarks, as it is flying. Well, not
really, but if you're dumb enuff, you'll think it is. :) We love
it. So there, have some serious fun, all!

================================================================
Special Notes
================================================================
The zip includes an UFO version. To make it work in your RV, you
have to open the \ufo\ folder in your \cars\ folder. Once you're
in there, rename the Parameters.txt to sth else, for example
ufoParameters.txt and then rename rvairParameters.txt to
Parameters.txt. Start Re-Volt and go flying. The UFO version has
highly unrealistic params. A huge jet would never turn in that
fast on the ground, but we tried to make it turn at all when
in the air.

================================================================
Construction
================================================================
Base           : Track instance for Re-Volt Airport made by
	       : Freestyler and modified by SuPeRTaRD
Poly Count     : 693 polies for the body
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap;
	       : 3D Studio MAX; Hullsize 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
Gabor Varga (bootes):
For Venice, his third track, which is another masterpiece. So
we decided to take the screenie on there. Thanks!

Freestyler:
For creating RVAirport and the basic mesh this plane is built
from. Also for allowing us to make a car from it. Thanks!

SuPeRTaRD:
For making the mesh look better and better and better, as well
as for encouraging us to release the UFO version and giving
advice on what to change on the params. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/

