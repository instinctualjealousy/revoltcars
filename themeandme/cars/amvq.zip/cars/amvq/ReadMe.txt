================================================================
Car Information
================================================================
Car Name  : Aston Martin V12 Vanquish
Car Type  : Conversion
Folder	  : ...\cars\amvq
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 47 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me
EMail       : saver@gmx.li
Homepage    : http://www.themeandme.de/

================================================================
Car Description
================================================================
The 2002 James Bond car in Re-Volt. Without the rockets and all
the fancy stuff 007 got in his, but by no means a loser. Pretty
damn quick round corners. Has some Shelia DNS in the params,
flipping round from an upside down position most of the times.
Lots of joy involved in this car. Have fun!

================================================================
Construction
================================================================
Base           : NFS4 custom model by Ryuji Kainoh
Poly Count     : 996 polies for the body
               : 160 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! And even tho the site
has closed down, we're all still able to visit the backup site,
hosted on RVA.
http://rvd.rvarchive.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/
or http://www.sportplanet.com/rva/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
RST & hilaire9:
For Floating Temples, which is, while being a tuff cookie to win
on quite fun and really challenging. And also pleasing to the
eye. Which is why we took the screenshot on it. Thanks!

Ryuji Kainoh:
For the fine looking mesh of the Vanquish for NFS4. In our
humble opinion, its one of the best meshes he ever released. And
he lets us use it, just as his other meshes. Thanks a lot!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars,
provided you give proper credit to the creators of the parts
from this car that were used to built the new car. E.g. if
you use the wheel models give credit to the creators and/or
converters. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.rvarchive.com/ or www.sportplanet.com/rva 
       	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/

