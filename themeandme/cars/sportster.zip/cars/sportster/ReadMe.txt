================================================================
Car name                : Sportster   
Install in folder       : ...\cars\sportster
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is a street-eatin' low-ridin' Adeon
named Sportster: very cool rims, very cool handling, very cool cooler
and overall, a very cool car!

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans, Racerspoint for the best Re-Volt forum and our genius brains...
================================================================

* Play Information *

Top speed (observed)    : 50 mph
Rating                  : Pro

* Construction *

Base                    : Adeon
Editor(s) used          : PSP 5.1 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	   http://www.racerspoint.com/revolt/
	   http://members.tripod.de/saver83/revolt/
