---Lancia Stratos Rally Version for NFS:HS----

Name of Designer: 	Beniamino Calchera
E-Mail: 		beni910@hotmail.com
Name of Car: 		Lancia Stratos Rally
Based on: 		Lancia Stratos by Funkyalex (axf1@gmx.net)
Date of release: 	30.01.2000
Version: 		V 1.1

-------------------------------------

Hi folks, 
 thanks for downloading the Lancia Stratos Rally Version, based on the Lancia Stratos by Funkyalex. The car is painted in the original rally-colors with main sponsor Alitalia, an italian airline. I edited the textures and the mesh, the handling is the same as before.
 I was inspired by some screenshots of the new Sega Rally Championship 2, which shows the Lancia on the cover of it's box.
 The car has a dash but no upgrades.

-------------------------------------

This ZIP contains:
	-Readme.txt
	-car.viv
	-strr.qfs
--------------------------------------

Installation:

 -First search for your NFS:HS directory.
 -In your NFS:HS directory go to the directory "\data\cars", there you'll find the directories of all cars. 
 -Extract the car.viv files in this directory. 

--------------------------------------

Credits and thanks to: 
	-Funkyalex for his great car
	-Denis Auroux for the Track Editor
	-Jesper Juul-Mortensen for the NFS/VIV Wizard
	-EA for the game

--------------------------------------

The Lancia Stratos is copyright by Funkyalex, the Rally Version is built under license by Beniamino Calchera.
If you want to use this car as a base for your work, you have to ask Funkyalex an me before.

--------------------------------------

If you have any comments, critics, ideas or if you're able to fix a bug, mail me at:
 beni910@hotmail.com
