================================================================
Car name                : Poison 
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Misc. Author Info       : 

Description             :This car is based on RiffRaff's "68ss". It comes with two totally different Paintjobs, one is greenyellow like "Poison" and the other one has got coins on it like "Money"! There are batch files to switch between them...
Hope you like o poison, too!

Additional Credits to   : You for downloading this car, Acclaim for producing this great game, RHQ for supporting all those crazy Re-Volt fans and last but not least RiffRaff for making the models!
			 
================================================================

* Play Information *

Top speed (observed)    : 52 mph
Rating                  : Pro

* Construction *

Base                    : 68ss by RiffRaff
Editor(s) used          : PaintShopPro 5.1
Known Bugs              : NONE


* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Website  : http://www.revolthq.com/