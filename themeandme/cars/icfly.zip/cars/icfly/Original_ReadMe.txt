Greetings !

The Super Fly aeroplane was created by Cheeto  cheeto@teambattlezone for the enjoyment of the 1nsane community.

YOU DO NOT HAVE PERMISSION TO MODIFY, RENAME, EXCLUDE FILES, OR HOST THIS VEHICLE ON ANY WEBSITE.  VIOLATION OF THIS WILL BE PROSECUTED TO THE FULL EXTENT OF THE LAW!


CopyRight � Team BattleZone 2002, All rights reserved, no un-authorized reproduction