================================================================
Car name                : Mercedes Maybach  
Install in folder       : ...\cars\mayb
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is the Maybach project car. It is a large
luxury limosine. The original has a V24 motor which produces over 500 hp.
Believe us: the model has the right proportions (ca.) the original is
5.74 metres long! Our Re-Volt interpretation is not too fast, but not too
slow either. The handling maybe a little too direct for a car of this size,
but we couldn't stand to give this beautiful body a crappy handling.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and Kv12supercharged for the original
Need For Speed 4 model. Thanks!
================================================================

* Play Information *

Top speed (observed)    : 42 mph
Rating                  : Pro

* Construction *

Base                    : NFS 4 custom model by Kv12supercharged 
Poly Count              : 613 polies for the body
			: 40 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
