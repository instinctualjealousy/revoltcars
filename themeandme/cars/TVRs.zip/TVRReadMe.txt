================================================================
Car name                : TVR Cerbera Speed 12
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me & Cybinary
Email Address           : saver@gmx.li, cybinary@yahoo.com
Homepage	        : http://members.tripod.de/saver83/revolt/
			: http://www.rvarchive.com/ 

Description             : An english race car again. This RV
interpretation is a joint effort between The Me and Me & Cybinary.
There are two cars included in this zip, which will install in its
own folder each.
This the more realistic Cerbera from The Me and Me. Skin by Cyb,
params by The Me and Me. It has good handling and speed.


Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and Ryuji Kainoh for the original models.
================================================================

Top speed (observed)    : 45 mph
Rating                  : Pro

* Construction *

Base                    : NFS
Poly Count              : 686 polies for the body
			: 80 polies for each wheel
Editor(s) used          : PS 4.0; PSP 5.1; ZMod; RVShade; RVSizer
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
