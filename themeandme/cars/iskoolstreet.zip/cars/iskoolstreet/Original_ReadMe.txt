4x4 Bus for 1nsane (Solid_Granite) (Final)

Credits:
Mesh, tuning, fogey hell and "1nsane" skins: Solid_Granite
school wasted and IRC touring bus skins: Arppa83
Features:
Damagable model:                   yes
Dirt / damage texture:             yes
full interior model & texture:     yes
additional skins:                  yes
fall off parts:                    yes
tail-lights:                       yes
headlights:                        yes
reverse lights                     no
brake lights:                      yes
mirrors:                           yes
new sounds:                        yes
exterior steering wheel:           yes
interior dials:                    yes
class oponnents:                   yes

Many thanks to Arppa83 for his awesome skins. (The school bus, the IRC touring bus and
the old rusted skins.)
The original 4x4 skool bus was the 3rd car I made. It was converted from silverwolf's
mm2 one. When I decided to finish it, I wasn't happy with the model and textures, so
I rebuilt the whole thing from scratch.

NOTE:          
DO NOT MODIFY/CONVERT/USE ANY PARTS OF THIS CAR WITHOUT MY PERMISSION
Solidg8@hotmail.com
INSTALLATION:           Unzip to C:\Codemasters\Insane\Data\Vehicles

PROGRAMS USED:          Zmodeler, ICE, Notepad

Thanks to: Arppa83 (beta tester and skins)
	   Toxicfritz, Trw, Boogaloo, DuZ, B-Fat (Beta testers)
	   