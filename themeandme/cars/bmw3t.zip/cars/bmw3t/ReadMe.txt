================================================================
Car name                : BMW M3 TUNED  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : A sorta unrealistic tuned version of a BMW
M3 comes to RV. Quite dark skin but looks cool. Included driver
and neat wings on the rear window. Handling aint as quick as on
most of our cars, but you can get it to slide as well. Average
Pro-topspeed.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; scloink for the wheels and BeRzErK
for the original body model.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by BeRzErK
Poly Count              : 1298 polies for the body
			: 411 polies for each wheel
Editor(s) used          : PSP 7; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
