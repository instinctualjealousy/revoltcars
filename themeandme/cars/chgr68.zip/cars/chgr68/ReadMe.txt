================================================================
Car name                : 1968 Dodge Charger  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is one of the american muscle cars.
It has sidepipes, cool wheels and a driver. It handles rather good
with fair speed.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Santa Claus for Rooftops where we took
the screenshots on and xtonyx for the original models.
================================================================

* Play Information *

Top speed (observed)    : 42 mph
Rating                  : Pro

* Construction *

Base                    : NFS custom model by xtonyx
			: (we couldn't reach you via email, if you see
			: this car and want it taken off, we will)
Poly Count              : 1009 polies for the body
			: 192 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
