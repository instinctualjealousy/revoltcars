================================================================
Car Information
================================================================
Car Name  : Bentley Arnage Red Label
Car Type  : Conversion
Folder	  : ...\cars\arng
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 49 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name   : The Me and Me & Greenflag
TM&M-EMail    : saver@gmx.li
GF-EMail      : gregory_cathalina@yahoo.com
TM&M-Homepage : http://www.themeandme.com/

================================================================
Car Description
================================================================
The real Bentley Arnage Red Label is the newest model by Bentley
and has the most powerful (if it comes for torque) engine of all
street cars. Our RV version displays this fact. It is really
fast, accelerate good and handles great. All those realism will
moan again "Oh, why did they make it handle like this" but hey,
don't forget that this is virtual RC-racing, not trying to get
the highest state of realism (though realism aint bad). We hope
that the lot of you will like it anyways. And if you dont like
the params, just make you sum new ones.

================================================================
Construction
================================================================
Base           : NFS4 custom model by Ryuji Kainoh
Poly Count     : 870 polies for the body
               : 80 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/revolt/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
Greenflag:
For making the kick-ass set of parameters which makes this
Bentley handle like a dream. He wanted to team up with us, which
is cool, too. We will team up for more than this one. Thanks!

Ryuji Kainoh:
For again outdoing himself with the great body model and the
very authentic textures on the car. It looks nearly like the
real one what means that it looks cool. And of course for lettin
us convert his cars. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.themeandme.com/

