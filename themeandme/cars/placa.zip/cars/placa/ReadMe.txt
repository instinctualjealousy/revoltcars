================================================================
Car Information
================================================================
Car Name  : Placeholder A
Car Type  : Conversion
Folder	  : ...\cars\placa
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 47 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me
EMail       : saver@gmx.li
Homepage    : http://www.themeandme.de/

================================================================
Car Description
================================================================
A very good looking (kudos to Ryuji and Morph) car with a set
of very good params. Not for the fans of "realism", but ppl, RV
is a fun-racer! Never forget about that. And be sure, these
params are fun. So, have fun!

================================================================
Construction
================================================================
Base           : NFS4 placeholder car by EA
	       : rearwing by Ryuji Kainoh (Mosler GT900)
	       : exhaust pipes by Ryuji Kainoh (Cordoba WRC)
	       : texture more or less custom by us
Poly Count     : 798 polies for the body
               : 150 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
Skitch2:
For creating his best track yet IOO, Fools Mate 2, where we took
the screenshot on. We highly recommend this to everyone. Get it
now! Thanks!

Ryuji Kainoh:
For the rearwing and exhaust pipes to have the car looking a bit
better and sportier. Thanks dude!

Antimorph:
For taking the mesh in 3dsMAX and polishing it "a bit" using
vertex colors and all the good stuff. Looks crappy without that.
Thanks!

Electronic Arts:
For creating the original model. At least we guess they did it.
We ran over it in our NFS4 folder... Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.themeandme.de/

