================================================================
Car name                : Lister Storm  
Install in folder       : ...\cars\lissto
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : The Lister Storm is one of the few british
racing cars that are racing today. Our interpretation comes with
four different colorskins. It's just not too fast for the Pro-class,
but believe us, it's not slow at all... Direct handling and fair
cornering make the Lister Storm a cool car. The AI will also give
you a great challenge.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and the unknown EA artists for the model.
================================================================

* Play Information *

Top speed (observed)    : 49 mph
Rating                  : Pro

* Construction *

Base                    : NFS3 official add-on car
Poly Count              : 536 polies for the body
			: 40 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
