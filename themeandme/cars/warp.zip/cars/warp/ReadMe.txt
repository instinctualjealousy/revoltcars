================================================================
Car name                : Warp  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This dark and cool car is really based on stock
Humma! We modified its shape with ZMod to a more agressive look and style.
We also flattened it with RVSizer, that adds to this style. We used
RiffRaffs wheels from his Pronto Cruiser. Although the car is named Warp,
it is NOT an overtuned warp car. The handling and speed is fair but
not as extreme as the look is. 

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; RiffRaff for the wheels and Oleg M for ZMod.
================================================================

* Play Information *

Top speed (observed)    : 45 mph
Rating                  : Pro

* Construction *

Base                    : Humma; with RiffRaffs wheels
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
