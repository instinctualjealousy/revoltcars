================================================================
Car name                : Bentley Continental SC  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This car is a 350.000 $ luxury cruiser...
As a cruiser ain't a car to break speed records, our RV-interpretation
goes only 41 mph. The handling is cruiser fitting as well. The car
has 2 paintjobs, if you want to change them, you have to rename "car.bmp"
to any other name and the rename "car1.bmp" to "car.bmp". We converted
the model from NFS to Re-Volt.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Travis Crews for the original NFS model;
SuperTard for his great Battle-Tag arena SK8][ that we took our
screenshots on and Silverlode for pushing us into the work on this car
and beta-testing.
================================================================

* Play Information *

Top speed (observed)    : 41 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Travis Crews
Poly Count              : 772 polies for the body
			: 40 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
