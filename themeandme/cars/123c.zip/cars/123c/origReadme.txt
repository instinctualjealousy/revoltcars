Mercedes-Benz 280 CE 6.9 (W 123) V 1.0
			
Wow, I nearly can't believe myself that it's finally done! This is definetely the car I spent the most time for, but therefore it turned out into something good I'd say. J The car itsself is a very elegant coup� of the late 70s. Its design finds its roots in the 60s, no attention was paid on aerodynamical tricks (the back end is on the same level of height as the front end) and many chromed parts were used. 
I think I did my best job on this car because it comes with a lot of innovative features: Its damagemodel is much more realistic than those of any other car I've created so far, but you'll see yourself. There are scratches, breaking headlights and a simply-awesome new feature: The doors and hoods open when there's an accident and you can even see the car's engine! Beside tons of detail were added: All chromeparts are 3D-modeled, the car comes with an antenna, the Mercedes-star on the front or a 3D-exhaust. You simply have to check out the car on your own, because I haven't wrote down all details of it.
I have even created a small showcase which lets you view some of the car's stats.
But let's get started now:

How to install:
Unzip all files into your NFS4 main-directory. That's the one which contains the nfshs.exe. Then run  the *.bat-file. It moves the car and it videowall into the right directory. 
If you want to install the car manually, then do the following:

1. Create a new subdirectory called "123c" in your nfs4\data\cars-folder. Then move the car.viv-file into it (That's the car).
2. Create another directory with the same name within the savedata\cars-folder. Move the car.fec-file into it (That's the customized color).
3. Move the 123c.qfs file into the data\feart\vidwall-folder (That is the videowall-image).

Used tools:
-Viv Wizard 0.8 with NFSHS-support
-NFS Wizard
-CarCAD V 1.5b and FCE Tweak
-Corel Photopaint 7.0

Thanks to:

- Cpt. Botter and Sloan for betatesting,
- The authors of all used tools except the Corel guys (No tga-support!!!!) ;-) ,
- All users of this software,
- Daimler-Benz AG for creating such wonderful cars. I hope you will continiue creating such beautiful cars without Bruno Sacco...

Creditz:

This program and all files within this zip-file are copyright 2000 by the author, Felixx, Felixx@Felixx-Autobahn.de . You do not have permission to put it on any CD-ROM or other media (including magazine cover cd�s, and compilations) that is to be retailed without the authors prior written conscent.
The file itself, in its ORIGINAL STATE, may be distributed at no cost to anyone!  
Please feel free to send it to your friends.
You can use it as a base for your work, but you have to credit me for this and notify me before you release it.
You do NOT have the permission to put this car onto your homepages without the author's written permission. I have to write this because some dudes messed up with the files of my other cars and made me responsible for their mistakes.

Mercedes, Mercedes-Benz, W123 and 230 CE are trademarks of Daimler-Benz AG Germany

Electronic Arts is Copyright 1999
All Need For Speed Titles are Copyright of Electronic Arts
Need For Speed 4 "High Stakes" is Copyright of Electronic Arts 1999

Annotations? Trouble?
Send an e-mail to Felixx@Felixx-Autobahn.de
Or visit my homepage: http://www.Felixx-Autobahn.de
