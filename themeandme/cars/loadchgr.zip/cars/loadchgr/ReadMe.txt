================================================================
Car Information
================================================================
Car Name  : 1969 Loaded Dodge Charger
	  : (inspired by the movie "The Fast And The Furious")
Car Type  : Conversion with additions
Folder	  : ...\cars\loadchgr
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 42 mph (Wacky's go 43 mph on a very long straight)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Wacky_Ink & The Me and Me
Wacky-EMail : xxpuertorican_thugxx@hotmail.com
TMaM-EMail  : saver@gmx.li
TMaM-Page   : http://www.themeandme.de/

================================================================
Car Description
================================================================
This is a cooperation between Wacky_Ink and The Me and Me. While
Wacky_Ink had the brilliant idea to take the already released
Charger and put a huuge loader engine on the hood, he asked TMaM
to do it. And we did. So here we go now, it's a Loaded Charger,
quite like in "The Fast And The Furious".
It's surely one of the american muscle cars. It has some phat 'n
cool sidepipes pumped up wheels and (whee!) a driver.
Handling is different with the two set of params, both are
handling rather good with fair speed. The engine on top of the
hood is meant to be a V12 5.6 liter with 900 hp. Have fun!

================================================================
Special Notes
================================================================
To change between the two sets of params, just click the
included parameters.bat. You'll be asked which set you wanna
race then. If you press 1, you'll get the RWD set that Wacky_Ink
made, it tops out at  mph. If you press 2, you'll get the 4WD
set made by The Me and Me, which is easier to control, but tops
out at  mph as well. Wacky_Ink's set is the stock set.

The zip includes custom wavs by Gel. If you dont want them,
just dont extract them. But they are worth it, so please check
em out at least. If you want to backup them, just make a copy
of these files in your \wavs\ folder. moto.wav; skid_normal.wav;
skid_rough.wav and honka.wav.

================================================================
Construction
================================================================
Base           : NFS4 custom models by xtonyx
	       : engine model by Beniamino Calchera
 	       : (we couldn't reach you via email, if you see
	       : this car and want it taken off, we will)
Poly Count     : 1151 polies for the body
               : 192 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
Crew of "The Fast And The Furious":
For creating such a lovely movie with great cars in it. And the
story aint that bad either. Thanks!

Wacky_Ink:
For having the great idea to start this project. It was him who
had the idea and him who created that lovely set of rwd params.
Surely a pity that he couldn't be into this project as much as
he wanted to due to grade reasons. Good luck and thanks!

Gel:
For collecting/creating this wonderful set of wavs you can dld
at www.rvarchive.com. We included some of these wavs in here
to make the Charger sound more real. Thanks!

xtonyx:
For creating the body and wheelmodels and the main part of the
cars texture. Without him, we never would have had the
possibility to see this car in Re-Volt. Thanks!

Beniamino Calchera:
For creating that engine model for his Caprice Interceptor. We
needed a big block for this car to look a bit like in the movie.
He made a great looking one, so here we go. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.themeandme.de/

