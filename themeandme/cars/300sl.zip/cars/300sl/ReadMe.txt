================================================================
Car name                : Mercedes 300 SL  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : A very detailed german oldtimer. It may have
a bit too much of polygons, but it looks that great that that is takeable.
The mesh has modelled airintakes and cooling. Our RV interpretation
ain't that fast as the original when it was build. But don't
worry, you won't feel like a snail in this car.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Spaceman for Re-Ville where we took
the screenshots on and Thomas Egelkraut for the original models.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : NFS custom model by Thomas Egelkraut
			: (we couldn't reach you via email, if you see
			: this car and want it taken off, we will)
Poly Count              : 1279 polies for the body
			: 70 polies for each wheel
Editor(s) used          : PSP 7; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
