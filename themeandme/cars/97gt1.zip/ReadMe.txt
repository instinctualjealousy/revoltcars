================================================================
Car name                : Porsche 911 GT1 EVO  
Install in folder       : ...\cars\97gt1
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This great and realistic model was made for
Need For Speed 4 by C-959. We converted it into Re-Volt and what we got,
is what we expected: A fast and beautiful racer! It will fit
perfectly to RiffRaff's Porsche-GT1 or RVCC's Porsche 908 Longtail.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Oleg M for ZModeler;
ali for the rvminis; all guys who helped us with ZModeler and
especially C-959 for his great Need For Speed 4 model/textures.
================================================================

* Play Information *

Top speed (observed)    : 55 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 model "Porsche 911 GT1 EVO Champion"
			: by C-959 - Thanks again!
Editor(s) used          : PSP 5.1; ZModeler; RVShade
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars, as long as they credit C-959 for the models in their ReadMes.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	   http://www.racerspoint.com/revolt/
	   http://www.rvarchive.com/
	   http://members.tripod.de/saver83/revolt/
