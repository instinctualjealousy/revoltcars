================================================================
Car name                : radium  
Install in folder       : ...\cars\radium
Author                  : The Me and Me
Email Address           : saver@gmx.li
Misc. Author Info       : 

Description             : Big-wheeled and tuned-up version of the "famous" "Sprinter XL", but it drives completely different!

Additional Credits to   : You for downloading this car; Acclaim for producing this game; RHQ for supporting all those crazy Re-Volt fans and Jimk for making the wheels in his "Mdogde"!
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : Sprinter XL with wheels from Jimk's "Mdogde"
Editor(s) used          : PSP 5.1
Known Bugs              : NONE


* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Website  : http://www.revolthq.com/
