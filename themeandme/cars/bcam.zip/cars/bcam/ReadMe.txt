================================================================
Car name                : Chevrolet Camaro Bonus  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is the bonus Camaro from NFS4.
It looks cool and has some great wheels. Its not a rocket car for
sure, but it has some very fitting handling with a tendency to 
rear slide out in a good way. So you'll need at least a bit of
skills to drive this car properly.
If you dont like the black skin at all, we included a second, more
neutral silver paintjob. To change between these two, just rename
car.bmp to car2.bmp and then rename car1.bmp to car.bmp. Do it the
other way round to change it back.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; scloink for the 3d wheels; BK for
YABBA DABBA DOO where to took the screenshots on and the EA artists
for the original body model.
================================================================

* Play Information *

Top speed (observed)    : 41 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 stock bonus car
Poly Count              : 723 polies for the body
			: 411 polies for each wheel
Editor(s) used          : PSP 7; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
