================================================================
Car name                : Mercedes SLR  
Install in folder       : ...\cars\mslr
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is the Mercedes SLR project car. It was
converted by us from NFS:HS to Re-Volt. Cuz we didn't got much time,
Nickki1 made Params for this car, we only had to optimize the way we like
it.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans, Racerspoint for the best Re-Volt forum, Nickki1 for the 
Params ours are based on and the unknown author of the NFS model.
================================================================

* Play Information *

Top speed (observed)    : 48 mph
Rating                  : Pro

* Construction *

Base                    : Need For Speed:High Stakes Custom mesh
Editor(s) used          : PSP 5.1; ZModeler; RVShade 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	   http://www.racerspoint.com/revolt/
	   http://members.tripod.de/saver83/revolt/
