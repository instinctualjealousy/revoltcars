================================================================
Car name                : Honda NSX-T  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : A cool looking cruiser with fitting params.
It ain't too fast for its style but still fast enough. The handling is
very direct. Overall, it's just a cool car to cruise around Re-Volt!
We converted it from NFS to Re-Volt

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; m-design team for the NFS model and
SuperTard for his great Battle-Tag arena SKATE][ that we took our
screenshots on.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : NFS 4 custom model by ms-design team
Poly Count              : 1054 polies for the body
			: 42 polies for each front wheel
			: 40 polies for each back wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
