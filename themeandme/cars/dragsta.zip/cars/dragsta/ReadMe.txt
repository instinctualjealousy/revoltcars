================================================================
Car name                : Dragsta
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : It's not a normal Dragster. That wild thing
is really based on good ol' Phat Slug! But there's not a lot left from
Sluggie, everything is changed! The driving (which is quite ok), the
looks, and the model! 

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans, Racerspoint for the best Re-Volt forum and us, again!
================================================================

* Play Information *

Top speed (observed)    : 47 mph
Rating                  : Pro

* Construction *

Base                    : Phat Slug
Editor(s) used          : PSP 5.1; RV-Sizer; ZModeler; RV-Shade
Known Bugs              : Wheels are clipping when they are far away;
stucks on walls

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	   http://www.racerspoint.com/revolt/
	   http://members.tripod.de/saver83/revolt/
