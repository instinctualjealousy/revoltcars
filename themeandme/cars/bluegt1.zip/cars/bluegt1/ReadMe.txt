================================================================
Car name                : Blue GT1  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : After all the Super-Pro repaints of RiffRaffs
GT1, here is finally a car with the oldschool style of tuning... We made two
parameter sheets. One which is great if you like to slide around corners, the
other one is a bit tighter and a bit slower.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and RiffRaff for his great Porsche-GT1.
================================================================

* Play Information *

Top speed (observed)    : 43 mph(Tight)/ 45 mph(Loose)
Rating                  : Pro

* Construction *

Base                    : Porsche-GT1 by RiffRaff
Editor(s) used          : PSP 5.1
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
