================================================================
Car name                : stealth   
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li 
Misc. Author Info       : 

Description             :This is not another pure-black loser-stealth cars, this is really invisible! Only a little red dot is still there to make driving possible! Its params are from our famous car "QUICK".

Additional Credits to   : You for downloading this car; Acclaim for producing this game and RHQ for supporting all those crazy Re-Volt fans.
================================================================

* Play Information *

Top speed (observed)    : 51 mph
Rating                  : Pro


* Construction *

Base                    : nothing in particular
Editor(s) used          : PaintShopPro 5.1; RV-Sizer
Known Bugs              : NONE


* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars. 

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Website  : http://www.revolthq.com