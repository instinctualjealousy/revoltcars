IG Rail Buggy
=====================

Copyright 2002 David Cardito

Body made by: Deja_Wolf, Davulia (David Cardito)
Interior made by: Davulia (David Cardito)
Converted into Insane by: Davulia (David Cardito)


Description: One of my most detailed vehicles yet. An offroad modified buggy that really kicks ass. Complete with working gauges, lights, interior views, and 16 falloff parts. This thing can really come apart when you roll it! Have fun and email me with any problems/suggestions!

NOTE: The frame body I used was made by Deja_Wolf, however it has been extensively modified by me. Everything else contained in this vehicle was made from scratch by me, Davulia. 
------------
GETTING PERMISSION FROM DEJA_WOLF TO USE HIS FRAME BODY DOES NOT ALLOW YOU TO USE THIS BODY VERSION.
------------

INSTALATION: unzip rail.idf into your Insane\Data\Vehicles  folder

-----Features-------------

Damagable model:                   yes
Dirt / damage texture:             no
Full interior model & texture:     yes
Aditional skins:                   yes
Fall off parts:                    yes
Tail-ligts:                        yes
Headlights:                        yes
Reverse lights                     yes
Brake lights:                      yes
Mirrors:                           no
New sounds:                        yes
Exterior steering wheel:           yes
Interior dials:                    yes

---------------------------

Do Not Modify or use any of these files in another vehicle without permission from me first!

This file is exclusive property of David Cardito and may only be posted for download at http://WWW.INSANEGARAGE.COM

If you want to repost or modify this file email me first at Davulia@insanegarage.com