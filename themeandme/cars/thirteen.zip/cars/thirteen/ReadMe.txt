================================================================
Car name                : Thirteen  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is a provocation for your eyes, it'll
attract them with different highlight colors on the parts of the car.
It's a lot fun to drive with, but that doesn't mean that it is easy to
drive, you'll need skillz in some corners to control it properly.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans, Racerspoint for the best Re-Volt forum and RiffRaff for the original
model, the Porsche-GT1.
================================================================

* Play Information *

Top speed (observed)    : 55 mph
Rating                  : Pro

* Construction *

Base                    : Porsche-GT1 by RiffRaff
Editor(s) used          : PSP 5.1 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	   http://www.racerspoint.com/revolt/
	   http://members.tripod.de/saver83/revolt/
