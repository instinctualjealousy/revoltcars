================================================================
Car Information
================================================================
Car Name  : Balloon
Car Type  : Original
Folder	  : ...\cars\balloon
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 42 mph / 45 mph for the UFO version
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me & SuPeRTaRD
TMaM-EMail  : saver@gmx.li
ST-EMail    : brgpug@ev1.net
Homepage    : http://www.themeandme.de/

================================================================
Car Description
================================================================
TM&M and ST hit RV again with novelty and pure, great novelty at
that. It's a hot-air balloon with a great looking balloon and an
even better looking basket. The mesh looks so fantastically it's
close to bein unbelievable. Look at it before you race it so you
know what you just knocked against the wall if you hit a wall. U
shouldn't do that to this cutie. Definetely not!! The params are
made for fun and not for realism. 'cuz a realistic balloon would
not move at all. :) So they're pretty funny and we hope you will
have as much fun as we did. Surely a keeper and even if only for
having fun everytime you overtake it or get overtaken. Have fun!

================================================================
Special Notes
================================================================
1.
The zip includes an UFO version. To make it work in your RV, you
have to open the \ufo\ folder in your \cars\ folder. Once you're
in there, rename the Parameters.txt to sth else, for example
ufoParameters.txt and then rename BalloonParameters.txt to
Parameters.txt. Start Re-Volt and go flying. The UFO version has
highly unrealistic params when on the ground, but they are very
fun once air-borne.
2.
The parameters feature a twist that we discovered when messing
around with the spinner on Aeroplane from 1nsane. Look at the
balloon for a while and you'll see it grows. Doesn't need to be
too long... Race a 3 lapper on Toys in the Hood 1 and you'll
have the screen full of balloon.

================================================================
Construction
================================================================
Base           : Custom mesh & texture for Re-Volt by SuPeRTaRD
Poly Count     : 2066 polies for the basket
               : 456 polies for the balloon
Editor(s) used : PSP 7; 3DSMAX; Notepad; SuPeRTaRD ;) 
Known Bugs     : Great looking mesh distract from driving

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
SuPeRTaRD:
For taking the time to put so much work into the basket and
balloon meshes that they now look pretty close to reality. The
basket is probably one of the most detailed meshes ever made for
Re-Volt. Thanks!

SuPeRTaRD:
For creating the Multiplayer Battle Tag Level Sk8][ where we
took the screenshot on. Even if the screenshot doesn't do the
balloon or the level real justice, it's as great fun and you
should get it. Thanks!

SuPeRTaRD:
For being in the #revolt-chat nearly 24/7 and therefore being a
very good person to work with. Adding to this, he's very funny
most of the time and an all-around good guy. Fank you, fank you
very much! 

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars,
provided you give proper credit to the creators of the parts
from this car that were used to built the new car. E.g. if
you use the wheel models give credit to the creators and/or
converters. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/