================================================================
Car name                : Mini Cooper S  
Install in folder       : ...\cars\coopers
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is the original english race car. It's
a Mini Cooper S, which means that it's the "more-sports" version with
widened fenders, bigger wheels, roof spoiler and huge exhaust pipes.
This tiny little car will drive circles around all the others, although
it's not THAT fast. It has good acceleration and excellent handling.
Another cool skill of this thing is that always flips back on its wheels
if you do some turnings and spinnings. It now has an additional skin
by Nickki1, just switch the bat-file to get the one you want.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars, the unknown author of the NFS model
and Nickki1 for the cool skin.
================================================================

* Play Information *

Top speed (observed)    : 46 mph
Rating                  : Pro

* Construction *

Base                    : Need For Speed 4 custom model
Poly Count              : 943 polies for the body
			: 40 polies for each front wheel
			: 40 polies for each back wheel
Editor(s) used          : PSP 5.1 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
