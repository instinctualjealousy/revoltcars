2002 Alfa Romeo Tipo 33 GT1
------------------------------------------------------------------------------
* Car Information *   

Car name                : Alfa Romeo Tipo 33 GT1  
Orig mesh by		: Alan Guerzoni
Email Address           : alanguer@tin.it
Misc. Author Info       : -
Description             : In the late 60s and in the early 70s, Alfa Romeo created a lot of glorious
			  sportscar to race Le Mans 24h. They were called "Tipo 33", and they appeared
			  both with and without the roof. So I decided to create a new high performance 			  road coupe inspirated to those racecars, triying to join aerodynamic lines 			  with elegant italian style. This is the result!  
------------------------------------------------------------------------------
* Construction *

Car Base                : Original Z3D mesh by Alan Guerzoni
			  Polycount : 2276 faces for the body
			              208 faces for each wheel
Texture By              : Alan Guerzoni
Editor(s) used          : ZModeler for entire mesh creation
			  Jasc Paint Shop Pro 7.04 for the textures 

------------------------------------------------------------------------------
* Misc Information *

Thanks to               : My mother Magnavacca Silvana (B. 24/11/1952 - D. 31/08/2002). Thanks Mummy, 			  	  I'll never miss you! You'll be alwais in my heart!

			  The Me and Me, who created this car Re-Volt setup. They're always kind 
			  with me and always ready to help me when I need advice about car converting.
			  Thanks Guys!

			  Waine for his fantastic Re-Volt Racerspoint forum!

------------------------------------------------------------------------------
* Copyright / Permissions *

You MAY use this car as base to build additional cars, but first contact me, please.
This readme file must be included with your car version.

------------------------------------------------------------------------------
Alan Guerzoni                                              Date: 11/11/2002
