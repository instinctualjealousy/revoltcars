================================================================
Car Information
================================================================
Car Name  : VeilSide RX-7
Car Type  : Conversion
Folder	  : ...\cars\vsrx7
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 49 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me
EMail       : saver@gmx.li
Homepage    : http://www.themeandme.com/

================================================================
Car Description
================================================================
A tuned version of the Mazda RX-7, made by Veilside. It has a
huge front and rear wing and some great looking rims. Our RV
version is quite fast as you would except it to be.

================================================================
Construction
================================================================
Base           : NFS4 custom model by Ryuji Kainoh
Poly Count     : 821 polies for the body
               : 150 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
Us:
For Dirt Valley, where we took the screenshots on. Its our first
Extreme track and we'd recommend to get it now. :) Thanks!

scloink:
Guess what, we used again the great wheels he made for his
Integra GT. And guess what, they still look great as they did on
all the cars we used em on. Thanks!

Ryuji Kainoh:
Heyho, we seem to be thanking the same ppl all the time. So we
have to thank Ryuji Kainoh again. He produces the cars we
convert to Re-Volt. They look all great and this is no
difference. The model looks very cool and realistic. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.themeandme.com/

