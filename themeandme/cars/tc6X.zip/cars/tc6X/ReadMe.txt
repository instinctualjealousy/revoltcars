================================================================
Car name                : Sprinter Xtreme  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is the first car which makes use of our
RACE CAR KIT. It is a mod of the often repainted Sprinter XL. It has 
these huge wings on both front and rear and two air intakes on the roof.
Due to the race car shape of the body, we felt that we had to fit the
skin to that. It's now a driving advertisement for CATERPILLAR.
The handling is not as extreme as the name or the looks suggest.
But it's cool and tight enuff to win. Hehe.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Major Clod for the awesome wheels
from his "Dodge Viper GTS-R" and SuperTard & scloink for "Ye Olde
Fun Shoppe" where we took the screenshots on.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : Sprinter XL (tc6) and wheels from Major Clod's
			: "Dodge Viper GTS-R"
Poly Count              : 368 polies for the body
			: 417 polies for each front wheel
			: 417 polies for each back wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
