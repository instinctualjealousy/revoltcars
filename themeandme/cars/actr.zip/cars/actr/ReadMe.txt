================================================================
Car name                : Mercedes Actros  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : Another fat truck. Very high poly (we are
sorry for loading approx 3900 polies with all models) and good looks in
general. Handling is kinda trucklike just maybe a bit too quick
responding. Feels quite heavy, too.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; srmalloy for his hulscale tool;
Volt General for Miami where we took the screenshots and Marcel
Hennersdorf for the original models.
================================================================

* Play Information *

Top speed (observed)    : 43 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Marcel Hennersdorf
Poly Count              : 2656 polies for the body
			: 224 polies for each front wheel
			: 368 polies for each back wheel
Editor(s) used          : PSP 7; ZMod; RVShade; RVSizer; hulscale 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
