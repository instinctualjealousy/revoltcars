================================================================
Car name                : Mad Viper  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This Viper is mad if it comes to the handling.
It handles very directly and quick, has a good acceleration and very
good top-speed. We did not add too much on the gfx part. It is mainly
Major Clod's bitmap changed to a darker and more mysterious style.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Major Clod for making the original
model, the "Dodge Viper GTS-R Concept" and SuperTard for his great
Battle-Tag arena SKATE][ that we took our screenshots on.
================================================================

* Play Information *

Top speed (observed)    : 54 mph
Rating                  : Pro

* Construction *

Base                    : "Dodge Viper GTS-R Concept" by Major Clod 

Editor(s) used          : PSP 5.1
Known Bugs              : none

* Copyright / Permissions *

This car is copyright (c)1999 Major Clod. You may not distribute any modifications
to this product without obtaining his permission.  All you have to do is email him
Major Clod's E-Mail address: veen01@powerup.com.au.

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
