Bugatti Atlantique LmGTS  
------------------------------------------------------------------------------
* Car Information *   

Car name                : Bugatti Atlantique LmGTS   
Orig mesh by		: Alan Guerzoni
Email Address           : alanguer@tin.it
Misc. Author Info       : -
Description             : This is the race version of my previous Bugatti Atlantique 2002.
			  Enjoy it!

------------------------------------------------------------------------------
* Construction *

Car Base                : Original D3D mesh by Alan Guerzoni
			  Polycount : 3342 faces for the body
			              208 faces for each wheel
Texture By              : Alan Guerzoni
Editor(s) used          : CorelDream3D 7 (original mesh)
			  Autodesk 3D Studio Viz R3 (conversion and poly optimization)
			  ZModeler, Rv-sizer, Rvshade
			  Jasc Paint Shop Pro 7.04 for the textures 

------------------------------------------------------------------------------
* Misc Information *

Thanks to               : My mother Magnavacca Silvana (B. 24/11/1952 - D. 31/08/2002). Thanks Mummy, 			  	  I'll never miss you! You'll be alwais in my heart!

			  My father Guerzoni Raffaele (B. 29/05/1948 - D. 08/12/2002). Thanks Daddy,
			  Now you'll be 4ever happy with your wife! Thanks to learn me to be a Man!

              		  The Me and Me. They're alwais kind with me and alwais ready to 
			  help me when I need advice about car converting.
			  Thanks Guys!

			  Waine for his fantastic Re-Volt Racerspoint forum!

------------------------------------------------------------------------------
* Copyright / Permissions *

You MAY use this car as base to build additional cars, but first contact me, please.
This readme file must be included with your car version.

------------------------------------------------------------------------------
Alan Guerzoni                                              Date: 28/01/2003
