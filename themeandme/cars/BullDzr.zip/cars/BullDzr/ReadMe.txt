================================================================
Car name                : Bull Dozer  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : BurnRubr & The Me and Me
Email Addresses         : burnrubr@email.com ; saver@gmx.li
Homepages	        : http://members.nbci.com/BurnRubr/
			: http://members.tripod.de/saver83/revolt/ 

Description             : This is what you could call a Bull Dozer.
This truck is a joint effort between BurnRubr and The Me and Me.
BurnRubr had the word with converting and adjusting the wheels etc.
and The Me and Me were the ones who made the params for this truck,
which turned out to be a good, semi-fast offroader.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and Terminal Reality for the original
MTM2 models and textures.
================================================================

* Play Information *

Top speed (observed)    : 42 mph
Rating                  : Pro

* Construction *

Base                    : Bull Dozer from Monster Truck Madness 2 by Terminal Reality
Poly Count              : 629 polies for the body
			: 192 polies for each wheel
Editor(s) used          : PSP; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.nbci.com/BurnRubr/
	 : http://members.tripod.de/saver83/revolt/
