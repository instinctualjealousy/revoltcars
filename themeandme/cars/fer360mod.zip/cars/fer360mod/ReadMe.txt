================================================================
Car name                : Ferrari 360 Modena  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is a Ferrari! And this time one that
exists in reality. It's the Coupe version of the V8 400 PS Ferrari 360.
Our RV interpretation has 3 different color jobs. They are compatible with
our Ferrari 360 Spyder. The handling is tight, fast and very raceable.
To change the paintjobs, you'll have to rename "car.bmp" to sth else and
then rename another .bmp to car.bmp.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and Porschenut for his NFS model.
================================================================

* Play Information *

Top speed (observed)    : 47 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Porschenut
Poly Count              : 721 polies for the body
			: 40 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
