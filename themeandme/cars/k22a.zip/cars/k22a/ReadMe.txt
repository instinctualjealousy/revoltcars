================================================================
Car name                : K. Motors K22a Virus  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : A funny trike with sorta good handling and
great looks. Only minor on the handling is, that its a little tippy
in sharp corner and when you're one of the wallbangers. So its a PRO
rated car not only for speed reasons.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; SuperTard for making the windows look
like they do and for doing some improvements on the mesh; SpaceMan
for Garden2 where we took the screenshots on and Kamal "666sin" Nsouli
for the original models.
================================================================

* Play Information *

Top speed (observed)    : 45 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Kamal "666sin" Nsouli
			: (we couldn't reach you via email, if you see
			: this car and want it taken off, we will)
Poly Count              : 938 polies for the body
			: 46 polies for each front wheel
			: 83 polies for each back wheel
Editor(s) used          : PSP 7; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
