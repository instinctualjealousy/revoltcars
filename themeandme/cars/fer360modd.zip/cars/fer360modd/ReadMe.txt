================================================================
Car Information
================================================================
Car Name  : Ferrari 360 Modded
Car Type  : Conversion Repaint with modifications
Folder	  : ...\cars\fer360modd
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 56 mph (SP4); 68 mph (SPR); 70 mph (WP4)
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me
EMail       : saver@gmx.li
Homepage    : http://www.themeandme.de/

================================================================
Car Description
================================================================
This is a repaint of a conversion of ours. Not actually the
a re-paint, as the paint is more or less the same. *lol* But we
added phat wheels and a huge rear wing to gain a sporty look.
In creation of this car, three different sets of params were
made. There's one which is good to drive and fast. Then there
is one that's faster and harder to drive, and last there's one
that's far from being driveable but still a lot of fun on
tracks faster the Toys in the Hood 1. Have fun! And read below
for instructions.

================================================================
Special Notes
================================================================
There are three different sets of Parameters included with this
car. There's a .bat to change between them. Click on it and you
will have the choice between 1. SuperPro Parameters, which are
fast and furious; 2. RWDSuperPro Parameters, which have been
inspired by the GT cars scloink released and 3. WarpSuperPro
Parameters, which are so fast, that it's hard to win on curvy
tracks. We recommend to use 1. or 2., 3. is included just for
fun.

================================================================
Construction
================================================================
Base           : NFS4 custom model by Porschenut
	       : converted to Re-Volt by us
	       : rearwing taken from NFS4 custom model by Ryuji
	       : Kainoh, added to the model by us
	       : wheels from our CTR2, made by scloink
Poly Count     : 763 polies for the body
               : 394 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
scloink:
For creating these beautiful looking wheels for our Porsche
CTR-2. We used them on a couple of other cars and they always
turn out to look great. Thanks!

scloink:
For creating that fast racing track Hockenheim. This is the
place to use the params, and the place where we took the
screenshot on. Thanks!

scloink/DSL_Tile:
For creating these RWD GT cars, which inspired the RWD params.
We're not sure if we've gotten any close to this role model, but
we reckon that the RWD are fun. Thanks!

revlo:
For creating the original .bat file we used here. We prolly would
never have been able to produce a .bat file. Thanks!

Ryuji Kainoh:
For the rearwing from his Mosler MT900, which really adds to the
sportscar look of this one. Tho it looks even better on the
original car. Thanks!

Porschenut:
For creating the body model for NFS4. It's the second time we
use it now, and it's looking very good. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.themeandme.de/

