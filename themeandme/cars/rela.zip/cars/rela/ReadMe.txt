================================================================
Car name                : Renault Laguna BTCC  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : A great looking Touring car, which raced
in the BritishTouringCarChampionship in 1997. Our RV version is
maybe a bit too slidy for a touring car, but this is what's fun
in this car. This should be great to repaint as well.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Skitch2 for Garden3, where we took
our screenshots on and Rico Bonitz for the original models.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Rico Bonitz
Poly Count              : 1133 polies for the body
			: 428 polies for each wheel
Editor(s) used          : PSP 7; ZMod; RVShade; RVSizer 
Known Bugs              : Minor optical/visual glitches

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
