================================================================
Car name                : Lotus Super 7  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : An english open sportscar. Drives quite stable
quite fast with quick handling/responding. Great model which makes great
looks form this car into what it is: a winner car. :)

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; ali for At Home where we took the
screenshots on scloink for the wheels and Justin W. Martin for the
original model.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Justin W. Martin
Poly Count              : 1176 polies for the body
			: 150 polies for each wheel
Editor(s) used          : PSP 7; ZMod; RVShade; RVSizer; RV-ReTex 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
