================================================================
Car Information
================================================================
Car Name  : Bentley Hunaudieres
Car Type  : Original
Folder	  : ...\cars\BentHunau
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 48 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Alan Guerzoni & The Me and Me
Alan-Email  : alanguer@tin.it
TM&M-EMail  : saver@gmx.li
TM&M-Page   : http://www.themeandme.de/

================================================================
Car Description
================================================================
Alan modelled this car and created the texture for it. It ended
up just lovely and perfectly accurate. Great stuff. And that at
under 900 polies for the body. We hope we got the params to live
up to that standard. We think they've gotten quite well. They
are pretty fast, just as the real thing is. Have fun!

================================================================
Construction
================================================================
Base           : Re-Volt custom mesh made by Alan Guerzoni
Poly Count     : 896 polies for the body
               : 180 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
scloink:
For creating that fast racing track Hockenheim. This Bentley
sure feels good on this track. Thanks!

Alan Guerzoni:
For creating this car as a kind of present for us. Well, if we
could model like this and texture like this. Wow... We'd do
presents for us all day long. It's so lovely. And so generous
to give this GREAT mesh to us for making the parameters. We feel
really honoured, Alan. Thanks!

================================================================
Copyright / Permissions
================================================================
You MAY use this car as base to build additional cars, but first
contact Alan, please. His ReadMe file (Original_ReadMe.txt) must
be included with your car version.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/

