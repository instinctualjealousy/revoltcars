Bentley Hunaudieres
------------------------------------------------------------------------------
* Car Information *   

Car name                : Bentley Hunaudieres     
Orig mesh by		: Alan Guerzoni
Email Address           : alanguer@tin.it
Misc. Author Info       : -
Description             : A great british Supercar that "TM&M" asked me to create: this mesh is my
			  personal present to one of better Re-Volt car converter of the world!

------------------------------------------------------------------------------
* Construction *

Car Base                : Original Z3D mesh by Alan Guerzoni
			  Polycount : 896 faces for the body
			              180 faces for each wheel
Texture By              : Alan Guerzoni
Editor(s) used          : ZModeler for entire mesh creation
			  Jasc Paint Shop Pro 7.04 for the textures 

------------------------------------------------------------------------------
* Misc Information *

Thanks to               : The Me and Me, who gave me the idea to make this car. They're always kind 
			  with me and always ready to help me when I need advice about car converting.
			  Thanks Guys!

------------------------------------------------------------------------------
* Copyright / Permissions *

You MAY use this car as base to build additional cars, but first contact me, please.
This readme file must be included with your car version.

------------------------------------------------------------------------------
Alan Guerzoni                                              Date: 05/06/2002