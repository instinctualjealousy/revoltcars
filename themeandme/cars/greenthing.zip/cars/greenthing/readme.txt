Car Name                : Green Thing

installation directory  : Unzip all files to your main Re-Volt folder

Author                  : The Me and Me

Class			: Pro

Engine			: Glow
	
Transmission		: 4WD
	
-------------------------------------------------------------

 How to use this car 

Unzip all files to your main Re-Volt folder

