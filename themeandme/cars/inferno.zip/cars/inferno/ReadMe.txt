================================================================
Car name                : Inferno  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage		: http://members.tripod.de/saver83/revolt/

Description             : This is the right car for the Higway to Hell!
Fast, hot and good looking... You'll burn your enemies with this car, but
if you race against it, you'll have a hard time beating it! 

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans and RiffRaff for making the original model, Bolink!
================================================================

* Play Information *

Top speed (observed)    : 56 mph
Rating                  : Pro

* Construction *

Base                    : Bolink by RiffRaff
Editor(s) used          : PSP 5.1 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	   http://www.racerspoint.com/revolt/
	   http://members.tripod.de/saver83/revolt/
