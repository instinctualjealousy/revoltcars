================================================================
Car Information
================================================================
Car Name  : BMW M3 Convertible
Car Type  : Conversion
Folder	  : ...\cars\bm3c
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 44 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me
EMail       : saver@gmx.li
Homepage    : http://www.themeandme.com/

================================================================
Car Description
================================================================
One of those cars everybody wants to have in real life. We hope
our RV version is no different. :) We think that it looks great
as the real one does and it really handles good as well. Maybe
we should have made somewhat more slideable but that way it's
really stable and very fun, too.

================================================================
Construction
================================================================
Base           : NFS4 custom model by Ryuji Kainoh
Poly Count     : 673 polies for the body
               : 150 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #re-volt chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
scloink:
For these fabulous wheel models he made once upon a time for his
Integra GT. They are very cool mapped and we used them on like
a hundred of our cars lately. Thanks!

Ryuji Kainoh:
Man, what can we say? The cars he produces are that stunning you
nearly won't believe it. This one is no difference and looks
just so cool. Great and detailed textures a very accurate sized
and modelled body model are what makes this car great. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================

Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.themeandme.com/

