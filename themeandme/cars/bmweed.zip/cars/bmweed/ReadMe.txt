================================================================
Car name                : BMWeed  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : Our second car finally got an update. The
old files are included to keep the original style. The new ones look
better and drive better. Just click the .bat of the ones you wanna have.

Original release        : back in the days... 08/25/2000

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and scloink for the wheels in the
NEW BMWeed.
================================================================

* Play Information *

Top speed (observed)    : 44 mph (NEW) / about 75 (sorry) mph (OLD)
Rating                  : Pro

* Construction *

Base                    : AMW
Editor(s) used          : PSP 5.1
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
