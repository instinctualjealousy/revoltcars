================================================================
Car name                : Italdesign Scighera  
Install in folder       : ...\cars\scig
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is the Alfa Romeo project car, Scighera.
It was designed by Italdesign. The model was converted by us from NFS3
to Re-Volt. It's not that fast, but it's still fast enuff to beat
all stock cars. We included three different paintjobs (or better:
colorjobs) cuz we couldn't decide which one we like best. There are
batch-files to make changing between 'em easier.


Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and
================================================================

* Play Information *

Top speed (observed)    : 46 mph
Rating                  : Pro

* Construction *

Base                    : Need For Speed 3 stock car
Editor(s) used          : PSP 5.1; ZMod; RVShade; VIVWizard; CARCad 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	   http://www.racerspoint.com/revolt/
	   http://www.rvarchive.com/
	   http://members.tripod.de/saver83/revolt/
