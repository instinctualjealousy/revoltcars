================================================================
Car Information
================================================================
Car Name  : Mercedes-Benz CLK F1 Pacecar
Car Type  : Conversion
Folder	  : ...\cars\clkf1pace
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 41 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me
EMail       : saver@gmx.li
Homepage    : http://www.themeandme.com/

================================================================
Car Description
================================================================
This is the car that brakes these crazy F1 drivers down when
there is some danger around the track. But this car doesnt brake
down anything. Fast enuff to win if you know how to drive.
It looks cool as well. Have fun!

================================================================
Construction
================================================================
Base           : NFS4 custom mesh by Felixx scale(at)wtal.de
Poly Count     : 817 polies for the body
               : 150 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
Gabor Varga:
For PetroVolt, which is fantastic for taking screenshots on.
And even better for racing. And having fun. Thanks!

Michael Schumacher:
For winning the Formula 1 World Championship. Oh yeah. He's cool
and german. :p Something that doesnt meet too often. Thanks!

scloink:
For these wheels models. Oh yeah, they look cool. :) Thanks!

Felixx:
For creating this wonderful looking body model for NeedForSpeed
and for giving us the permission to convert it. It was good fun
to convert this. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.themeandme.com/

