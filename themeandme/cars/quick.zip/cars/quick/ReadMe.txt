================================================================
Car name                : QUICK   
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li 
Misc. Author Info       : 

Description             : It may not look too spectacular, but we think that its driving  			  abilities are excellent.

Additional Credits to   : You for downloading this car; Acclaim for producing this game and 			  RHQ for supporting all those crazy Re-Volt fans.
================================================================

* Play Information *

Top speed (observed)    : 51 mph
Rating                  : Pro


* Construction *

Base                    : Modified car Cougar
Editor(s) used          : PaintShopPro 5.1
Known Bugs              : none


* Copyright / Permissions *

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Website  : http://www.revolthq.com