================================================================
Car name                : Tanker  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : The tiny track-model from ToyWorld 1 finally
kickz da streets, and it kickz 'em with wheelz from BurnRubr's LamCountach.
Do never forget that this is a toy and not a realistic car reproduction.
 
Additional Credits to   : You for downloading this car; Acclaim for
producing this game and the original model; RHQ for supporting all
those crazy Re-Volt fans; Racerspoint for the best Re-Volt forum and
BurnRubr for the wheel models.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : 
Editor(s) used          : PSP 5.1; ZModeler; RV-Shade; RV-Sizer
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	   http://www.racerspoint.com/revolt/
	   http://members.tripod.de/saver83/revolt/
