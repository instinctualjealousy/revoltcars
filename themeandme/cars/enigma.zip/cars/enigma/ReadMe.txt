================================================================
Car Information
================================================================
Car Name  : Enigma
Car Type  : Original, but originally made for another game.
Folder	  : ...\cars\enigma
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 50 mph
Rating    : Pro / SuperPro

================================================================
Author Information
================================================================
Author Name : SuPeRTaRD & The Me and Me
ST-EMail    : brgpug@ev1.net
TMaM-EMail  : saver@gmx.li
Homepage    : http://www.themeandme.de/

================================================================
Car Description
================================================================
Made for the Tron-ish game Armagetron by praised 3D-author
SuPeRTaRD, it finally made its way into Re-Volt. We tried to 
make the params raily enough for its looks but slidy enough for
the game. Have fun!

================================================================
Construction
================================================================
Base           : Custom mesh for Armagetron by SuPeRTaRD
Poly Count     : 280 polies for the body
               : 120 polies for each wheel
Editor(s) used : PSP 7; 3dsmax; ase2prm tools of rv-glue #7
Known Bugs     : It's too awesome!

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! 

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/
or http://www.sportplanet.com/rva/

We want to thank arto for being the ever faithful host of 
Re-Volt Zone Tracks which turned out to be the main hosting site
for cars and tracks these days. Check it out here:
http://revolt.speedweek.net/

We want to thank all the moderators and especially our Admin
Manmountain, for keeping an eye on our forum during the time we 
have none. Please do us a favor and visit the Pub here:
http://s3.invisionfree.com/Our_ReVolt_Pub/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
Skitch2:
For his fabulous Hull Breach 3 track, on which the screenshot of
the Enigma was taken on. All of his tracks are true pieces of
art, and this one's no different. Thanks!

SuPeRTaRD:
For another superb, even though simple, mesh. And also for being
an all-around good guy and yeah all that he did for Re-Volt in
his active years. Sorry for keeping this under the shelf for so 
long mate. Thank you!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars,
provided you give proper credit to the creators of the parts
from this car that were used to built the new car. E.g. if
you use the wheel models give credit to the creators and/or
converters. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://revolt.speedweek.net/
	 : http://www.themeandme.de/