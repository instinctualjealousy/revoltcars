================================================================
Car Information
================================================================
Car Name  : Toyota Corolla Trueno [AE86]
Car Type  : Conversion
Folder	  : ...\cars\ae86trueno
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 44 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me
EMail       : saver@gmx.li
Homepage    : http://www.themeandme.de/

================================================================
Car Description
================================================================
K, "sometime" is today, only one day after the release of it's
AE86 Levin brother. Pretty much the same params, lil bit faster
(really lil) and a lil bit driftier (if such a word is anywhere
near existing). Have fun!

================================================================
Construction
================================================================
Base           : NFS4 custom model by Ryuji Kainoh
Poly Count     : 715 polies for the body
               : 40 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
Incogbla:
For Small Circuit 2, which is a very fun yet challenging track
set at night. Great to take screenies on too. Thanks!

Ryuji Kainoh:
For creating these loads of cars for Need For Speed 4. And for
doing them in this quality. And for allowing us to convert them
to Re-Volt. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars,
provided you give proper credit to the creators of the parts
from this car that were used to built the new car. E.g. if
you use the wheel models give credit to the creators and/or
converters. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.revoltdownloads.com/
         : http://www.sportplanet.com/rva/
	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/

