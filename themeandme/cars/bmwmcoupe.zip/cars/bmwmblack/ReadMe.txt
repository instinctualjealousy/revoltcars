================================================================
Car name                : BMW M Coupe  
Install in folder       : Extract ALL files to your Re-Volt root
			: directory. 
Author                  : The Me and Me & Nairb
Email Address           : saver@gmx.li  & nairb5@bigfoot.com
Homepage	        : http://members.tripod.de/saver83/revolt/

Description             : Once upon a time, we showed up with an early
version of this thing at Racerspoint. We knew that Nairb likes this
car so we said: "This one's for you, Nairb!" and he asked if we wanted
to make that car in teamwork. We wanted. What you just downloaded, is the
amazing result of this international cooperation: Four cars in their own
folders. This pack features four different paintjobs (3 (Black, Blue,
Yellow) by Nairb and 1 (Rod) by us) and two different sets of parameters.
Nairb made the realistic one (Black, Blue, Yellow), we made the params
for the Rod the way we usually do our params.
You've got the choice! 

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Killerbee for sending us the original
BMW M Coupe paintjob; the unknown EA artists for the original model;
Oleg M for ZModeler; various people at Racerspoint for helping us
with ZMod and some paramizing problems and Nairb for starting
this successful and intercontinental cooperation.
Thank y'all!
================================================================

* Play Information *

Top speed (observed)    : 45 mph (with both sets of parameters)
Rating                  : Pro

* Construction *

Base                    : Need For Speed 4 - official add-on car
Editor(s) used          : PSP 5.1; ZModeler; RVShade; RV-Sizer;
			: VIVWizard
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
