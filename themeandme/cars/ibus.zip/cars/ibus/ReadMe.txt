================================================================
Car Information
================================================================
Car Name  : Bus
Car Type  : Conversion
Folder	  : ...\cars\ibus
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 41 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : The Me and Me
EMail       : saver@gmx.li
Homepage    : http://www.themeandme.de/

================================================================
Car Description
================================================================
A huuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuge
F1-Bus from 1nsane for Re-Volt. Very slow reaction and accel,
but kinda good fighting abilities. If you ever reach one of the
other cars. Have fun!

================================================================
Construction
================================================================
Base           : 1nsane (by Invictus and Codemasters) add-on car
Poly Count     : 699 polies for the body
               : 100 polies for each front wheel
               : 140 polies for each back wheel
               : 280 polies for the back axle
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap 
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
scloink:
For converting Hockenheim, which is a great addition to any
Re-Volt track selection. As this is F1-Bus, we took the screeny
here. Thanks!

Codemasters/Invictus and Gabriel Kovacs & Peter Veres:
For creating 1nsane, prolly the most fun off road racing game.
This add-on car is not any worse then the stock cars. Very high
quality mesh and texture, not that many polies. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars,
provided you give proper credit to the creators of the parts
from this car that were used to built the new car. E.g. if
you use the wheel models give credit to the creators and/or
converters. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/

