================================================================
Car name                : El Nino  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Special Note            : This is our tutorial car. We used this car
to describe how to convert a car from NeedForSpeed4 to Re-Volt.
Read the tutorial on The Re-Volt Archive (www.rvarchive.com).

Description             : A sorta unrealistic car with driver and
cockpit. Handles good and has some nice speed. It is quite stable,
too. Should fit well to all the future tracks like HullBreach2 or
The Force.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; srmalloy for The Force where we took
the screenshots on and the unknown EA artists for the models.
================================================================

* Play Information *

Top speed (observed)    : 47 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 stock car
Poly Count              : 650 polies for the body
			: 40 polies for each wheel
Editor(s) used          : PSP 7; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
