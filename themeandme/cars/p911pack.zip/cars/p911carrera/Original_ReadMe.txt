Porsche 911 Carrera(996) for Need for speed IV

Title          : Porsche 911 Carrera(996)
Car            : Porsche 911 Carrera `02 (SN:21)
File           : p96c.zip
Version        : 1.0 (Upgrade Feature : NO)
Date           : JUN 2002

Author         : Ryuji KAINOH
Email          : ryuji_k@pop13.odn.ne.jp
Homepage       : http://www1.odn.ne.jp/ryuji_k/nfs3.htm

Used Editor(s) : Mrc(cartool.zip) by EA
               : NFS Wizard v0.5.0.79 by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 297) by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 299) by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : NFS Car CAD v1.5b by Chris Barnard
               : CAR3TO4 by J�rg Billeter
               : NFS FCEConverter by Addict&Rocket
               : PaintShop Pro 5J

* CM_500 made 996 Carrera's "CARP.TXT" for my car.

Thanks.
___________________________________________________________

Installation : Put the "car.viv" in "Data\Cars\p96c".
               and  the "p96c.qfs" in "Data\FeArt\VidWall".

Have a fun !!


...Formula1(1987to2002) Carset for ICR2(IndycarRacing2)...
http://www1.odn.ne.jp/ryuji_k/