================================================================
Car name                : 1976 Cadillac Eldorado - South Edition  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : Another American oldschool car comes to RV.
More or less funny looks and slideable parameters make this car
great. Notice that we dont support smoking in anyway, but without
that cigar it just would not have been right. I hope no one feels
offended by this car. It's a joke... And in a game... Dont take it
too serious.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; DSL_Tile for Aztec Gold where we took
the screenshots on and Smokey! for the original models.
================================================================

* Play Information *

Top speed (observed)    : 43 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Smokey!
Poly Count              : 1658 polies for the body
			: 40 polies for each wheel
Editor(s) used          : PSP 7; ZMod; RVShade; RVSizer; HulScale 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
