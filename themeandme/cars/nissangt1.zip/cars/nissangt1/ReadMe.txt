================================================================
Car name                : Nissan R390 GT1  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is the japanese sports car. It is the
street version of the Nissan Le Mans racer. Like a real sports car,
it is very fast and handles very good. It has 3 three different paintjobs,
if you want to change them, you have to rename "car.bmp" to any other
name and the rename the bmp of your choice to "car.bmp". We converted
it from NFS to Re-Volt.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Killuncle for his great NFS model and
SuperTard for his great Battle-Tag arena SK8][ where we took our
screenshots.
================================================================

* Play Information *

Top speed (observed)    : 54 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Killuncle
Poly Count              : 458 polies for the body
			: 40 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
