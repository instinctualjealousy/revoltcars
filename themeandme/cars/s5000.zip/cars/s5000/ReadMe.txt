================================================================
Car name                : Shelia S 5000  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : The skin of this car is a cut&paste masterpiece
from several NFS3 cars. The body model is a modified Jaguar XJR by DaVe.
It looks very extreme but frienly, too... (ah, she is smiling at me).
We didnt won't to make yer handling as extreme as her looks. So it goes
up easy to 44 mph with tight handling and good acceleration.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; scloink for making the wheels
for us in 3dsMAX and DaVe for the original model.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom car by DaVe
Poly Count              : 478 polies for the body
			: 232 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer; 3dsMAX 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
