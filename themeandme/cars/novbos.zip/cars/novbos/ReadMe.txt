================================================================
Car name                : Nova Bosch  
Install in folder       : Unzip all files to your Main Re-Volt folder.
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This is the touringcar version of RVCC's "Go-Va".
It is much lower, has bigger frontwheels and a handling that fits the touring
car look better. Although it has the "normal" style of tuning a car
it really steers good. It now has an updated set of parameters with
even better steering.
If you want the old parameters, rename "parameters.txt" to sth else
and then rename "OLD-parameters.txt" to "parameters.txt". 

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; RVCC for their great original
model, the "Go-Va"; SuperTard for his great Battle-Tag arena
SKATE][ that we took our screenshots on and scloink for giving sum
hints on the updated params.
================================================================

* Play Information *

Top speed (observed)    : 45 mph
Rating                  : Pro

* Construction *

Base                    : "Go-Va" ("1970 Nova HotRod") by RVCC
Editor(s) used          : PSP 5.1
Known Bugs              : The frontwheels go through the fenders when turned. 

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
