1943 Supermarine Spitfire Mk IX
------------------------------------------------------------------------------
* Car Information *   

Plane name              : Supermarine Spitfire Mk IX
Orig mesh by		: Alan Guerzoni
Email Address           : alanguer@tin.it
Misc. Author Info       : -
Description             : If someone was planning an unofficial Re-Volt flight simulator, here you
			  are an interesting example. This is a Supermarine Spitfire, a fighter which 
			  flew during the World War II and fight the Battle of Britain for the Royal 
			  Air Force. This model particullary is a plane piloted by a polish allied 
                          pilot in 1943. It has realistic RAF camouflage. Original fighter was 
                          propelled by a Rolls Royce Merlin 61 (V12, 1565 Cv, max speed 655 Km/h)
 
------------------------------------------------------------------------------
* Construction *

Car Base                : Original Z3D mesh by Alan Guerzoni
			  Polycount : 851 faces for the entire mesh			            
Texture By              : Alan Guerzoni
Editor(s) used          : ZModeler for entire mesh creation
			  Jasc Paint Shop Pro 7.04 for the textures 

------------------------------------------------------------------------------
* Misc Information *

Thanks to               : The Me and Me. They're alwais kind with me and fantastic in Re-Volt car 
			  converting! Thanks Guys!
			  The entire Re-Volt community
			  Waine LeMonds for his fantastic Racerspoint Forum!

------------------------------------------------------------------------------
* Copyright / Permissions *

You MAY use this car as base to build additional cars, but first contact me, please.
This readme file must be included with your car version.

------------------------------------------------------------------------------
Alan Guerzoni                                              Date: 08/08/2002
