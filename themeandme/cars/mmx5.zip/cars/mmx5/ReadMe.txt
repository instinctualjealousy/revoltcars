================================================================
Car name                : Mazda MX-5  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : The japanese Roadster comes to RV in quite
a low version with cool, huge rims and great handling. Its a bit
unstable, when you dont know the racing line of a track. You also
have to watch the rear cuz it sorta slides out easily.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; scloink for the wheels; RiffRaff for
Magnet where we took the screenshots on and Ryuji Kainoh for the
original body model.
================================================================

* Play Information *

Top speed (observed)    : 43 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Ryuji Kainoh 
Poly Count              : 730 polies for the body
			: 150 polies for each wheel
Editor(s) used          : PSP 7; ZMod; RVSizer; 3dsMaX 3.1;
			: ase2prm; RVDBlsd 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
