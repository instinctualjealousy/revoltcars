================================================================
Car name                : Caprice Interceptor  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : A big fat car with a huuge blower engine and
some cool flames. It has a custom sized hull which sorta fits the car
proportions. Its like the Mad Max cars with all that stuff on the car.
Handling isnt too good but (you may have guessed it) not too bad either.
Quite stable car overall, if you are not a wallbanger too much.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; scloink for cutting the wells into
the body.prm; srmalloy for the hull resize tool and Beniamino
Calchera for the original models and textures.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom car by Beniamino Calchera
			: (we couldn't reach you via email, if you see
			: this car and want it taken off, we will)
Poly Count              : 1189 polies for the body
			: 80 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
