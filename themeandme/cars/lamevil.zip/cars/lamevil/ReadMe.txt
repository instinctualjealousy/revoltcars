================================================================
Car name                : Lambo Evileca  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : This car uses our RACE CAR KIT, as well.
It has the rear wing on its back. It looks some kinda evilish.
The car has three different sets of parameters. One very fast (SP)
set and two slower sets with tighter (TP) and looser (LP) handling.
Just click the .bat of the ones you wanna drive.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and BurnRubr & Nairb & RiffRaff for
the Lamborghini Countach.
================================================================

* Play Information *

Top speed (observed)    : 43 mph(LoosePro)/ 46 mph(TightPro)/ 56 mph(SuperPro)
Rating                  : Pro

* Construction *

Base                    : Lamborghini Countach by BurnRubr, Nairb and RiffRaff
Poly Count              : 467 polies for the body
			: 373 polies for each wheel
			: 16 polies for the rear wing
Editor(s) used          : PSP 5.1; ZMod; RVShade
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
