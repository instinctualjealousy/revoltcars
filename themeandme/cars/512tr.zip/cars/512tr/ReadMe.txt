 ================================================================
Car name                : Ferrari 512 TR  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : A highpoly Ferrari with three cool different colored
skins. Its really a blast to drive on lego tracks, especially when there
are surface properties that make you slide around even more. Tho its very easy
to let this car slide anyways.
To change the paintjobs, you'll have to rename "car.bmp" to sth else and
then rename another .bmp to car.bmp.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Skitch2 for Fools Mate where we took
the screenshots on; scloink for the wheels and Thomas Egelkraut for
the original body model.
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Thomas Egelkraut
			: (we couldn't reach you via email, if you see
			: this car and want it taken off, we will)
Poly Count              : 1271 polies for the body
			: 150 polies for each wheel
Editor(s) used          : PSP 7; ZMod; RVRetex; RVSizer; 3dsMAX 3.1 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
