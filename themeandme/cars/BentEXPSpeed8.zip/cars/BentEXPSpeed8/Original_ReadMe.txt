2002 Bentley Exp Speed 8
------------------------------------------------------------------------------
* Car Information *   

Car name                : 2002 Bentley Exp Speed 8     
Orig mesh by		: Alan Guerzoni
Email Address           : alanguer@tin.it
Misc. Author Info       : -
Description             : The only GTP (with the roof) car present at 2002 Le Mans 24h. It was
			  longtime I wanted to model this fantastic prototype, and this is the
			  result! It has original sponsors of 2002 Team Bentley 

------------------------------------------------------------------------------
* Construction *

Car Base                : Original Z3D mesh by Alan Guerzoni
			  Polycount : 2032 faces for the body
			              208 faces for each wheel
Texture By              : Alan Guerzoni
Editor(s) used          : ZModeler for entire mesh creation
			  Jasc Paint Shop Pro 7.04 for the textures 

------------------------------------------------------------------------------
* Misc Information *

Thanks to               : The Me and Me, who created this car Re-Volt setup. They're always kind 
			  with me and always ready to help me when I need advice about car converting.
			  Thanks Guys!

			  Scloink: I know I loves Le Mans prototypes, so this car had been studied for
			  his fast Hockenheimring track!

------------------------------------------------------------------------------
* Copyright / Permissions *

You MAY use this car as base to build additional cars, but first contact me, please.
This readme file must be included with your car version.

------------------------------------------------------------------------------
Alan Guerzoni                                              Date: 10/07/2002
