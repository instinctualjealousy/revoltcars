================================================================
Car Information
================================================================
Car Name  : Bentley EXP Speed 8
Car Type  : Original
Folder	  : ...\cars\BentEXPSpeed8
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 54mph 4WD | 69mph RWD
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : Alan Guerzoni & The Me and Me
Alan-Email  : alanguer@tin.it
TM&M-EMail  : saver@gmx.li
TM&M-Page   : http://www.themeandme.de/

================================================================
Car Description
================================================================
The only roofed Prototype at LeMans2002, and now Alan took it to
RV. And in what an amazing way he did. Look at the model in RV
and you'll find small details over and over the mesh. It looks
so real. Alan gave his never-enough-praised-mesh to us to make
up some good parameters for it. And we tried and came up with
two sets. The first is great to get going on nearly all kind of
tracks, while the second one is for sure suited for faster
tracks like Hockenheim only, due to its speed. Have fun!

================================================================
Special Notes
================================================================
There are two different sets of Parameters included with this
car. There's a .bat to change between them. Click on it and you
will have the choice between 1. 4WD SuperPro Parameters, which
are fast but not as furious as most of our other SuperPro cars.
It's a bit easier handling-wise and not as hard to control as
the other SuperPro cars and 2. RWDSuperPro Parameters, which
are meant to compare against DSL's and scloink's GT car pack,
so they are really fast and don't like being taken on grass or
ice.

================================================================
Construction
================================================================
Base           : Re-Volt custom mesh made by Alan Guerzoni
Poly Count     : 2032 polies for the body
               : 208 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
revlo:
For writing up the original version of the batch used in here.
We had never been so smart, dude! Thanks!

scloink:
For Hockenheim, which is still the only real racetrack for
Re-Volt and still so much fun with fast cars like this one. Thx!

Alan Guerzoni:
For putting most of his time and surely a lot of his energy in
creating these wonderful looking models and textures that are
so close to the real car it's nearly unbelieveable. Also, for
allowing us to create the params for his car. Thanks!

================================================================
Copyright / Permissions
================================================================
You MAY use this car as base to build additional cars, but first
contact Alan, please. His ReadMe file (Original_ReadMe.txt) must
be included with your car version.
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/

