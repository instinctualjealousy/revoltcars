======================================MICROBUS.IDF===============================================


Car name:  1956. Volkswagen Microbus

Author: 
         Eleanor (Sven Franic)  - eleanorvixen@hotmail.com 
                                  http://1nsanecheckers.tk

Description:
Created first in 1949 and produced all the way untill 1980. This car was very popular with 
hippies, campers, used for ice cream vans and today being a colectors item. Its powered by the
very same 4 cylinder boxer engine that was put in the beetle, they even share the identical
94.5 inch wheelbase. this version is from 1957 as thats the year the new model with extra 
windows was launched. In 1968. a whole new body was introduced which you still might even find 
on the road today. (or in ''back to the future'' driven by the terrorists)

INSTALATION: unzip microbus.idf into your Inasane/Data/Vehicles  folder

-----Menu spec's---------------
Class:         Custom
Stability:     Avrage
Top Speed:     Avrage
Accelleration: Avrage
Mass:          1200kg
Drive:         RWD
Handling:      Excellent
Damage:        Insane

-----Tested on special test course--------

Top speed:                not tested
0-100 km/h or 0-60 mp/h:  not tested
0-top speed               not tested

-----Features-------------

Damagable model:                   yes
Dirt / damage texture:             no
full interior model & texture:     yes
aditional skins:                   yes
fall off parts:                    yes
tail-ligts:                        yes
headlights:                        yes
reverse lights                     no
brake lights:                      yes
mirrors:                           yes
new sounds:                        yes
exterior steering wheel:           yes
interior dials:                    yes
class oponnents:                   no

-----Bugs------------------------
1. could cause fps dropping on slower machines.


COPYRIGHT---------------------------------------------------------------------------
THE FILE MICROBUS.IDF AND ALL OF ITS CONTENTS ARE PROPERTY OF SVEN FRANIC. ANY EDITING,
CONVERTING, MODING, RE-PUBLISHING OR SIMILLAR IMPROPER USE OF THIS FILE IS FORBIDEN!
THE FILE WAS CREATED EXCLUSIVLY FOR THE GAME ''1NSANE''
-CONTACT ME AT 	eleanorvixen@hotmail.com FOR ANY QUESTIONS CONCERNING THIS.
------------------------------------------------------------------------------------


Happy racing!  
             Sven 
                
