================================================================
Car name                : Jeep Wrangler  
Install in folder       : ...\cars\jeepw
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : The Jeep Wrangler is one of the most popular
cross-country vehicle. We converted it from Need For Speed 4 to Re-Volt.
It has soft springs, good handling and fair speed. It has a softtop which
is not switched on standardly.
If you want to have the softtop, you have to go into the parameters.txt
file, go to the bottom and look for "Car Spinner details". There is a
section named "ModelNum". Just change the number from "-1" to "5".
To deselect the softtop, just change the "5" back to "-1".

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars and Rocket and Addict for the original NFS
car. Thank you, guys!
================================================================

* Play Information *

Top speed (observed)    : 44 mph
Rating                  : Pro

* Construction *

Base                    : Need For Speed custom model by Rocket and Addict
Poly Count              : 935 polies for the body
			: 50 polies for the softtop
			: 80 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
