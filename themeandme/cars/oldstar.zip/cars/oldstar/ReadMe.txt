================================================================
Car name                : 1957 Oldsmobile Starfire  
Install in folder       : Unzip all files to your main Re-Volt folder
Author                  : The Me and Me
Email Address           : saver@gmx.li
Homepage	        : http://members.tripod.de/saver83/revolt/ 

Description             : A very high poly US oldtimer. As this is a
Oldtimer, it is not very fast and doesnt handle extreme. Three
paintjobs included.To change the paintjobs, you'll have to rename
"car.bmp" to sth else and then rename another .bmp to car.bmp.

Additional Credits to   : You for downloading this car; Acclaim for
producing this game; RHQ for supporting all those crazy Re-Volt
fans; Racerspoint for the best Re-Volt forum; Re-Volt Archive for
giving cool comments on cars; Skitch2 for HullBreach2 where we took
our screenshot on and Justin Martin for the original models.
================================================================

* Play Information *

Top speed (observed)    : 42 mph
Rating                  : Pro

* Construction *

Base                    : NFS4 custom model by Justin Martin
			: (we couldn't reach you via mail, but
			: if you come across this car and want it
			: taken off, we will)
Poly Count              : 2712 polies for the body
			: 40 polies for each wheel
Editor(s) used          : PSP 5.1; ZMod; RVShade; RVSizer 
Known Bugs              : none

* Copyright / Permissions *

Authors MAY use this Car as a base to build additional
cars.  

You MAY distribute this CAR, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

* Where to get this CAR *

Websites : http://www.revolthq.com/
	 : http://www.racerspoint.com/revolt/
	 : http://www.rvarchive.com/
	 : http://members.tripod.de/saver83/revolt/
