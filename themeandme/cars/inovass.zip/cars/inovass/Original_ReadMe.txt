IDT Edition Chevy Nova
=====================

Copyright 2002 David Cardito

IDF made by: David Cardito (Davulia)
Body made by: Rykar31
Interior made by: Invictus
Skins by: Arppa83, TheMeandMe, Popper
Converted into Insane by: David Cardito (Davulia)


Description: 

This vehicle originally hit Insane as the 4x4 Nova by Rykar31. During the inception of the IDT clan, the idea came up to make this car into a wrecker for demolition derby games. However, although some work was done to create the vehicle in this new light, it never came to fruition. IDT requested for me to make this car into a real demolition derby vehicle, which it now has become.

What was already done: 

Rykar did a good job creating the mesh and texturing it, and props go to him and the above mentioned skinners for their excellent skins.

What I did: 

I basically took this car to the shop and performed a complete overhaul. I threw out the old interior and added a new one. I fixed all the holes in the vehicle mesh and sealed any holes between the interior and the body. I also tweaked the body and suspension swing arms and axles. I threw out the old blocky wheels and added new ones I made and retextured them. I rebuilt the VHD from scratch. I added totally new sounds. I added a CRK for the dirt textures. I added all the interior dials and tachometer as well as adjusting all the camera views. The engine power and handling were adjusted to match a real demolition derby Nova. The physics model was made to incorporate a damage model that crumples in stages, and in a way that is similar to the real derby cars.



INSTALLATION: unzip novass.idf into your Insane\Data\Vehicles  folder

-----Features-------------

Damagable model:                   yes
Dirt / damage texture:             yes
Full interior model:               yes
Aditional skins:                   yes
Fall off parts:                    no
Tail-ligts:                        no
Headlights:                        no
Reverse lights                     no
Brake lights:                      no
Mirrors:                           no
New sounds:                        yes
Exterior steering wheel:           yes
Interior dials:                    yes




Do Not Modify or Repost any of these files without permission from Davulia first!
Thank you!

Contact Davulia at dcardito@rcn.com

Have Fun!