================================================================
Car Information
================================================================
Car Name  : Choco Box Van
Car Type  : Original
Folder	  : ...\cars\chocoboxvan
Install   : Unzip with folder names on to the main ReVolt folder
Top speed : 41 mph
Rating    : Pro

================================================================
Author Information
================================================================
Author Name : revlo & The Me and Me
Revlo-EMail : revlo@firemail.de
TMaM-EMail  : saver@gmx.li
Homepage    : http://www.themeandme.de/

================================================================
Car Description
================================================================
Another very basic custom mesh we create. This time it's a Van.
A Choco Box Van, actually. :) Well, the looks are quite simple,
but nice. :) Handling is slow, slow, slow as it should be on
a Van like this one. Hard to win with, but sure fun. Have fun!

================================================================
Construction
================================================================
Base           : Custom mesh/wheel for Re-Volt by revlo & TMaM
Poly Count     : 72 polies for the body
               : 96 polies for each wheel
Editor(s) used : PSP 7; ZModeler; RVShade; RVSizer; RVTexmap;
	       : 3dsmax
Known Bugs     : None

================================================================
Thanks And Accolades
================================================================
We want to thank you, for downloading this car, and supporting
the Re-Volt community with dlding it. Then we gotta thank the
whole RV community, too. Its probably the best community on a
racing game all around the web, and it's hard work to get there.
Now we all have to work even harder to keep it there! Thanks
and: Keep it up!

We want to thank Wayne LeMonds, for his great site and forum. If
it Wayne would not have been here, you would possibly not read
this, cuz we never would have gone so deep into Re-Volt without
the forum. Thanks a whole bunch, Wayne! If you havn't visited
his website please do so, you won't regret it.
http://www.racerspoint.com/

We want to thank the whole staff of RVA for their great site. It
is the perfect addition to Racerspoint and will be (or probably
is already) the completest Re-Volt site on the web, with all the
cars, tracks, tutorial, tools etc. If you don't know it yet, you
really have to hurry to get there: http://www.rvarchive.com/

We would also like to thank ALL the peeps at #revolt-chat on
the IRC austnet servers for their support and help without
forgetting anyone of them. Thanks dudes!

Then we want to thank all the creators of the tools we used.
Without their hard work, this car would not have been possible.

================================================================
Individual Thanks On This Car
================================================================
Antimorph:
For being so kind and do some workovers on this mesh, as there
were some flaws on it. And he did it really fast. So, it can now
finally be released. Thanks!

revlo:
For creating this mesh and giving some helpful advice and
thoughts about the usage of ZMod. Without him, this car wouldn't
even exist, as he created the body mesh. Thanks!

================================================================
Copyright / Permissions
================================================================
Authors MAY use this Car as a base to build additional cars,
provided you give proper credit to the creators of the parts
from this car that were used to built the new car. E.g. if
you use the wheel models give credit to the creators and/or
converters. 
 
You MAY distribute this CAR, provided you include this file,
with no modifications.  You may distribute this file in any
electronic format (BBS, Diskette, CD, etc) as long as you
include this file intact.

================================================================
Where to get this CAR
================================================================
Websites : http://www.racerspoint.com/revolt/
         : http://www.rvarchive.com/
	 : http://www.revoltunlimited.co.uk/
	 : http://www.themeandme.de/

