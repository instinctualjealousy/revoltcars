1999 Suzuki Escudo Pikes Peak by: Cobra911

-----::: Installation :::-----

Create a "escd" folder in your NFS HS Data/Cars directory then Extract the
car.viv to that then Extract the escd.qfs to the Data/Feart/Vidwall directory
You now have the Escudo available for play.

-----::: Info :::-----

Thanks for downloading, This is totaly Scratch - Inspired by the awesome
Monster Tajima, SPEEDvision and GT-2 for PSone.  I did everything you see
Wheels, Artand Scratch made body - total Build time was 78 hours
PLEASE ask if you Wish to modify or use anything from this Vehicle.

-----::: Contact me :::-----

c77bronco@hotmail.com
AIM: CGZcustoms
MSN: c77bronco@hotmail.com or "Cobra911"
ICQ: 60525242 (rarley Use it anymore)

-----::: Thanks :::-----

Programs used:

Carcad v1.5b
Zmodeler 1.0 (i like the layout more)
3d Studio Max 
Adobe photoshop 7.0
FCEtweak
FCE Center
FSH tool

ANything else...i forget.

Thanks...
-Cobra911


