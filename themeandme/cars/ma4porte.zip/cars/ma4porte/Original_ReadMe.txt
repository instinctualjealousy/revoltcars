Maserati Quattroporte V8 Evoluzione by CPD

Contacts info:
--------------
CPD: cpd@netspace.net.au
http://nfs4ideas.totalnfs.net/


Created with:
--------------
- Carcad 1.5 Beta by Chris Barnard
- Z Modeller 0.79/0.93 by Zanoza Software
- Paint Shop Pro 4.01 and 6.0
- NFS Wizard 0.4.0.77

Introduction:
-------------
Thank you for downloading this car. This setup program will install all files to "C:\Program Files\Electronic Arts\Need For Speed High Stakes". If this is not your NFS High Stakes directory, then browse for the correct directory when prompted.

IMPORTANT: This directory MUST contain NFSHS.EXE or the installation will fail!

You will be prompted when the installation process is complete.

About the car:
--------------
The Quattroporte V8 Evoluzione is the latest evolution of the high profile Quattroporte series of luxury saloons, starting back in 1962, when the Quattroporte debuted along with the Maserati Mistral, and both instantly became the highest performing luxury saloons of the day.

The new Quattroporte Evoluzione, the first of the new generations Maserati developed under the control of new Maserati president Paolo Marinsek, features a fine blend of opulent luxury, with performance and driving abilities that can only come from a Maserati. Like it's predecessors, it is also the highest performing luxury saloon.

The cabin is a tasteful fusion of leather and burr walnut, as practical as it is luxurious, with plentiful room for four people to travel in luxury.

The power comes from a choice of engines and gearboxes. The most powerful of these is the 3.2 litre, biturbo 32 valve alloy V8, a spectacular engine with 335hp at 6400u/min and 450Nm at 4400rpm. A 2.8 litre Biturbo V6 is also available. This engine features 280hp at 6000 u/min, and 422Nm at 3500u/min. 

Transmission choices are the Getrag 266 manual gearbox, with 6 finely stepped forward ratios for exhilerating performance potential, and the 4 speed BTR automatic gearbox, for easy cruising. This transmission also features winter and sports modes, the former allowing easier starts in slippery conditions.

Another feature of the Quattroporte Evoluzione is the adjustable suspension, with 4 settings from soft to firm, allowing limousine like ride quality or alternatively, supercar handling abilities.

Technical Specifications:
-------------------------
ENGINE:
V8 Biturbo
Layout: Longitudinal 32 Valve V8, biturbo.
Capacity: 3201cm�
Max. Power: 247kW / 335cv @ 6400 u/min
Max Torque: 450Nm @ 4400 u/min

V6 Biturbo:
Layout: Longitudinal 24 Valve V6, Biturbo
Capacity: 2.8 litres
Max. Power: 209kw / 280cv @ 6000 u/min
Max. Torque: 422Nm @ 3500 u/min

ACCELERATION:
Quattroporte V8 Evoluzione:
0-100km/hr: 5.2 seconds 
Top Speed: 280km/hr

Quattroporte V6 Evoluzione:
0-100km/h: 6.5 secs (est.)
Top Speed: 260km/hr

DIMENSIONS:
Weight: 1556kg (V6) / 1647kg (V8)
Length: 4550mm
Width: 1810mm
Height: 1380mm

TRANSMISSIONS:
-Getrag 266 6 Speed manual
-BTR 4 speed automatic.